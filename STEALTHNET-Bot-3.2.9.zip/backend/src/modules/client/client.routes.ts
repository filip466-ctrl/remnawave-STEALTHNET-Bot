import { randomBytes, createHmac } from "crypto";
import { randomUUID } from "crypto";
import { generateSecret, generateURI, verify } from "otplib";
import { env } from "../../config/index.js";
import { Router } from "express";
import { z } from "zod";
import { prisma } from "../../db.js";
import {
  hashPassword,
  verifyPassword,
  signClientToken,
  signClient2FAPendingToken,
  verifyClient2FAPendingToken,
  generateReferralCode,
  getSystemConfig,
  getPublicConfig,
  type SellOptionTrafficProduct,
  type SellOptionDeviceProduct,
  type SellOptionServerProduct,
} from "./client.service.js";
import {
  notifyAdminsAboutClientTicketMessage,
  notifyAdminsAboutNewClient,
  notifyAdminsAboutNewTicket,
} from "../notification/telegram-notify.service.js";
import { requireClientAuth } from "./client.middleware.js";
import { remnaCreateUser, remnaUpdateUser, isRemnaConfigured, remnaGetUser, remnaGetUserByUsername, remnaGetUserByEmail, remnaGetUserByTelegramId, extractRemnaUuid, remnaUsernameFromClient, remnaGetUserHwidDevices, remnaDeleteUserHwidDevice } from "../remna/remna.client.js";
import { sendVerificationEmail, sendLinkEmailVerification, isSmtpConfigured } from "../mail/mail.service.js";
import { createPlategaTransaction, isPlategaConfigured } from "../platega/platega.service.js";
import { activateTariffForClient, activateTariffByPaymentId } from "../tariff/tariff-activation.service.js";
import { createProxySlotsByPaymentId } from "../proxy/proxy-slots-activation.service.js";
import { createSingboxSlotsByPaymentId } from "../singbox/singbox-slots-activation.service.js";
import { buildSingboxSlotSubscriptionLink } from "../singbox/singbox-link.js";
import { applyExtraOptionByPaymentId } from "../extra-options/extra-options.service.js";
import { getAuthUrl, exchangeCodeForToken, requestPayment, processPayment } from "../yoomoney/yoomoney.service.js";
import { createYookassaPayment } from "../yookassa/yookassa.service.js";
import { createCryptopayInvoice, isCryptopayConfigured } from "../cryptopay/cryptopay.service.js";
import { createHeleketInvoice, isHeleketConfigured } from "../heleket/heleket.service.js";

/** Извлекает текущий expireAt из ответа Remna. Возвращает Date если в будущем, иначе null. */
function extractCurrentExpireAt(data: unknown): Date | null {
  if (!data || typeof data !== "object") return null;
  const o = data as Record<string, unknown>;
  const resp = (o.response ?? o.data ?? o) as Record<string, unknown>;
  const raw = resp?.expireAt;
  if (typeof raw !== "string") return null;
  try {
    const d = new Date(raw);
    if (Number.isNaN(d.getTime())) return null;
    return d.getTime() > Date.now() ? d : null;
  } catch {
    return null;
  }
}

/** Считает expireAt: если текущая подписка активна — добавляет дни к ней, иначе от now. */
function calculateExpireAt(currentExpireAt: Date | null, durationDays: number): string {
  const base = currentExpireAt ?? new Date();
  return new Date(base.getTime() + durationDays * 24 * 60 * 60 * 1000).toISOString();
}

export const clientAuthRouter = Router();

const utmSchema = {
  utm_source: z.string().max(255).optional(),
  utm_medium: z.string().max(255).optional(),
  utm_campaign: z.string().max(255).optional(),
  utm_content: z.string().max(255).optional(),
  utm_term: z.string().max(255).optional(),
};

const registerSchema = z.object({
  email: z.string().email().optional(),
  password: z.string().min(8).optional(),
  telegramId: z.string().optional(),
  telegramUsername: z.string().optional(),
  preferredLang: z.string().max(5).default("ru"),
  preferredCurrency: z.string().max(5).default("usd"),
  referralCode: z.string().optional(),
  ...utmSchema,
});

clientAuthRouter.post("/register", async (req, res) => {
  const body = registerSchema.safeParse(req.body);
  if (!body.success) {
    return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });
  }

  const data = body.data;
  const hasEmail = data.email && data.password;
  const hasTelegram = data.telegramId;

  if (!hasEmail && !hasTelegram) {
    return res.status(400).json({ message: "Provide email+password or telegramId" });
  }

  // Регистрация по email: создаём ожидание и отправляем письмо с ссылкой
  if (hasEmail) {
    const existing = await prisma.client.findUnique({ where: { email: data.email! } });
    if (existing) return res.status(400).json({ message: "Email already registered" });

    const config = await getSystemConfig();

    // Режим без подтверждения почты — создаём клиента сразу
    if (config.skipEmailVerification) {
      const referralCode = generateReferralCode();
      let referrerId: string | null = null;
      if (data.referralCode) {
        const referrer = await prisma.client.findFirst({ where: { referralCode: data.referralCode } });
        if (referrer) referrerId = referrer.id;
      }
      const passwordHash = await hashPassword(data.password!);
      const client = await prisma.client.create({
        data: {
          email: data.email!,
          passwordHash,
          remnawaveUuid: null,
          referralCode,
          referrerId,
          preferredLang: data.preferredLang,
          preferredCurrency: data.preferredCurrency,
          telegramId: null,
          telegramUsername: null,
          utmSource: data.utm_source ?? null,
          utmMedium: data.utm_medium ?? null,
          utmCampaign: data.utm_campaign ?? null,
          utmContent: data.utm_content ?? null,
          utmTerm: data.utm_term ?? null,
          autoRenewEnabled: config.defaultAutoRenewEnabled ?? false,
          onboardingCompleted: false,
        },
      });
      notifyAdminsAboutNewClient(client.id).catch(() => {});
      const token = signClientToken(client.id);
      return res.status(201).json({ token, client: toClientShape(client) });
    }

    const smtpConfig = {
      host: config.smtpHost || "",
      port: config.smtpPort,
      secure: config.smtpSecure,
      user: config.smtpUser,
      password: config.smtpPassword,
      fromEmail: config.smtpFromEmail,
      fromName: config.smtpFromName,
    };
    if (!isSmtpConfigured(smtpConfig)) {
      return res.status(503).json({ message: "Email registration is not configured. Contact administrator." });
    }

    const appUrl = (config.publicAppUrl || "").replace(/\/$/, "");
    if (!appUrl) {
      return res.status(503).json({ message: "Public app URL is not set in settings." });
    }

    const verificationToken = randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 ч

    const referralCode = generateReferralCode();
    let referrerId: string | null = null;
    if (data.referralCode) {
      const referrer = await prisma.client.findFirst({ where: { referralCode: data.referralCode } });
      if (referrer) referrerId = referrer.id;
    }
    const passwordHash = await hashPassword(data.password!);

    await prisma.pendingEmailRegistration.create({
      data: {
        email: data.email!,
        passwordHash,
        preferredLang: data.preferredLang,
        preferredCurrency: data.preferredCurrency,
        referralCode: data.referralCode || null,
        utmSource: data.utm_source ?? null,
        utmMedium: data.utm_medium ?? null,
        utmCampaign: data.utm_campaign ?? null,
        utmContent: data.utm_content ?? null,
        utmTerm: data.utm_term ?? null,
        verificationToken,
        expiresAt,
      },
    });

    const verificationLink = `${appUrl}/cabinet/verify-email?token=${verificationToken}`;
    const sendResult = await sendVerificationEmail(
      smtpConfig,
      data.email!,
      verificationLink,
      config.serviceName
    );
    console.log(`[register] Email send result to ${data.email}:`, sendResult);
    if (!sendResult.ok) {
      await prisma.pendingEmailRegistration.deleteMany({ where: { verificationToken } }).catch(() => {});
      return res.status(500).json({ message: "Failed to send verification email. Try again later." });
    }

    return res.status(201).json({ message: "Check your email to complete registration", requiresVerification: true });
  }

  // Регистрация / вход по Telegram (используется ботом). 2FA не требуем — только для входа на сайте.
  if (hasTelegram) {
    const existing = await prisma.client.findUnique({
      where: { telegramId: data.telegramId! },
      select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, onboardingCompleted: true },
    });
    if (existing) {
      if (!existing.isBlocked) {
        const blConfig = await getSystemConfig();
        if (blConfig.blacklistEnabled) {
          const { checkAndBlockIfBlacklisted } = await import("../blacklist/blacklist.service.js");
          const blocked = await checkAndBlockIfBlacklisted(data.telegramId!);
          if (blocked) return res.status(403).json({ message: "Account is blocked" });
        }
      }
      if (existing.isBlocked) return res.status(403).json({ message: "Account is blocked" });
      return res.json({ token: signClientToken(existing.id), client: toClientShape(existing) });
    }
  }

  // Не создаём пользователя в Remna при регистрации — клиент неактивен до триала или оплаты тарифа.
  const referralCode = generateReferralCode();
  let referrerId: string | null = null;
  if (data.referralCode) {
    const referrer = await prisma.client.findFirst({ where: { referralCode: data.referralCode } });
    if (referrer) referrerId = referrer.id;
  }

  const passwordHash = data.password ? await hashPassword(data.password) : null;
  const configForAutoRenew = await getSystemConfig();
  const client = await prisma.client.create({
    data: {
      email: data.email ?? null,
      passwordHash,
      remnawaveUuid: null,
      referralCode,
      referrerId,
      preferredLang: data.preferredLang,
      preferredCurrency: data.preferredCurrency,
      telegramId: data.telegramId ?? null,
      telegramUsername: data.telegramUsername ?? null,
      utmSource: data.utm_source ?? null,
      utmMedium: data.utm_medium ?? null,
      utmCampaign: data.utm_campaign ?? null,
      utmContent: data.utm_content ?? null,
      utmTerm: data.utm_term ?? null,
      autoRenewEnabled: configForAutoRenew.defaultAutoRenewEnabled ?? false,
    },
  });
  notifyAdminsAboutNewClient(client.id).catch(() => {});

  if (data.telegramId) {
    const blConfig2 = await getSystemConfig();
    if (blConfig2.blacklistEnabled) {
      const { checkAndBlockIfBlacklisted } = await import("../blacklist/blacklist.service.js");
      const blocked = await checkAndBlockIfBlacklisted(data.telegramId);
      if (blocked) return res.status(403).json({ message: "Account is blocked" });
    }
  }

  const token = signClientToken(client.id);
  return res.status(201).json({ token, client: toClientShape(client) });
});

const verifyLinkEmailSchema = z.object({ token: z.string().min(1) });
clientAuthRouter.post("/verify-link-email", async (req, res) => {
  const parse = verifyLinkEmailSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ message: "Invalid input" });
  const { token } = parse.data;
  const pending = await prisma.pendingEmailLink.findUnique({ where: { verificationToken: token } });
  if (!pending) return res.status(400).json({ message: "Недействительная или просроченная ссылка" });
  if (new Date() > pending.expiresAt) {
    await prisma.pendingEmailLink.deleteMany({ where: { id: pending.id } }).catch(() => {});
    return res.status(400).json({ message: "Ссылка просрочена. Запросите привязку почты снова." });
  }
  const existingByEmail = await prisma.client.findUnique({ where: { email: pending.email } });
  if (existingByEmail && existingByEmail.id !== pending.clientId) {
    await prisma.pendingEmailLink.deleteMany({ where: { id: pending.id } }).catch(() => {});
    return res.status(400).json({ message: "Эта почта уже привязана к другому аккаунту." });
  }
  const client = await prisma.client.update({
    where: { id: pending.clientId },
    data: { email: pending.email },
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, onboardingCompleted: true },
  });
  await prisma.pendingEmailLink.deleteMany({ where: { id: pending.id } }).catch(() => {});
  const auth = buildAuthResponse(client);
  return res.json(auth);
});

const verifyEmailSchema = z.object({ token: z.string().min(1) });
clientAuthRouter.post("/verify-email", async (req, res) => {
  const parse = verifyEmailSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ message: "Invalid input" });
  const { token } = parse.data;

  const pending = await prisma.pendingEmailRegistration.findUnique({
    where: { verificationToken: token },
  });
  if (!pending) return res.status(400).json({ message: "Invalid or expired link" });
  if (new Date() > pending.expiresAt) {
    await prisma.pendingEmailRegistration.delete({ where: { id: pending.id } }).catch(() => {});
    return res.status(400).json({ message: "Link expired. Please register again." });
  }

  const existingClient = await prisma.client.findUnique({
    where: { email: pending.email },
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, onboardingCompleted: true },
  });
  if (existingClient) {
    await prisma.pendingEmailRegistration.delete({ where: { id: pending.id } }).catch(() => {});
    const auth = buildAuthResponse(existingClient);
    return res.json(auth);
  }

  // Не создаём пользователя в Remna при регистрации — клиент неактивен до триала или оплаты тарифа.
  const referralCode = generateReferralCode();
  let referrerId: string | null = null;
  if (pending.referralCode) {
    const referrer = await prisma.client.findFirst({ where: { referralCode: pending.referralCode } });
    if (referrer) referrerId = referrer.id;
  }

  const configForAutoRenew = await getSystemConfig();
  const client = await prisma.client.create({
    data: {
      email: pending.email,
      passwordHash: pending.passwordHash,
      remnawaveUuid: null,
      referralCode,
      referrerId,
      preferredLang: pending.preferredLang,
      preferredCurrency: pending.preferredCurrency,
      telegramId: null,
      telegramUsername: null,
      utmSource: pending.utmSource,
      utmMedium: pending.utmMedium,
      utmCampaign: pending.utmCampaign,
      utmContent: pending.utmContent,
      utmTerm: pending.utmTerm,
      autoRenewEnabled: configForAutoRenew.defaultAutoRenewEnabled ?? false,
      onboardingCompleted: false,
    },
  });

  await prisma.pendingEmailRegistration.delete({ where: { id: pending.id } }).catch(() => {});

  const signToken = signClientToken(client.id);
  return res.status(201).json({ token: signToken, client: toClientShape(client) });
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

clientAuthRouter.post("/login", async (req, res) => {
  const body = loginSchema.safeParse(req.body);
  if (!body.success) {
    return res.status(400).json({ message: "Invalid input" });
  }

  const client = await prisma.client.findUnique({ where: { email: body.data.email } });
  if (!client || !client.passwordHash || client.isBlocked) {
    return res.status(401).json({ message: "Invalid email or password" });
  }

  const valid = await verifyPassword(body.data.password, client.passwordHash);
  if (!valid) return res.status(401).json({ message: "Invalid email or password" });

  const full = await prisma.client.findUnique({
    where: { id: client.id },
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, onboardingCompleted: true },
  });
  if (!full) return res.status(401).json({ message: "Invalid email or password" });
  const auth = buildAuthResponse(full);
  return res.json(auth);
});

/** Валидация initData из Telegram Web App (Mini App). https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app */
function validateTelegramInitData(initData: string, botToken: string): boolean {
  if (!initData?.trim() || !botToken?.trim()) return false;
  const params = new URLSearchParams(initData.trim());
  const hash = params.get("hash");
  if (!hash) return false;
  params.delete("hash");
  const authDate = params.get("auth_date");
  if (!authDate) return false;
  const authTimestamp = parseInt(authDate, 10);
  if (!Number.isFinite(authTimestamp) || Date.now() / 1000 - authTimestamp > 3600) return false; // не старше 1 часа
  const sorted = [...params.entries()].sort(([a], [b]) => a.localeCompare(b));
  const dataCheckString = sorted.map(([k, v]) => `${k}=${v}`).join("\n");
  const secretKey = createHmac("sha256", "WebAppData").update(botToken).digest();
  const computedHash = createHmac("sha256", secretKey).update(dataCheckString).digest("hex");
  return computedHash === hash;
}

/** Парсинг user из initData (JSON в параметре user) */
function parseTelegramUser(initData: string): { id: number; username?: string } | null {
  const params = new URLSearchParams(initData.trim());
  const userStr = params.get("user");
  if (!userStr) return null;
  try {
    const user = JSON.parse(userStr) as Record<string, unknown>;
    const id = typeof user.id === "number" ? user.id : Number(user.id);
    if (!Number.isFinite(id)) return null;
    const username = typeof user.username === "string" ? user.username : undefined;
    return { id, username };
  } catch {
    return null;
  }
}

const telegramMiniappSchema = z.object({ initData: z.string().min(1) });

clientAuthRouter.post("/telegram-miniapp", async (req, res) => {
  const body = telegramMiniappSchema.safeParse(req.body);
  if (!body.success) {
    return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });
  }
  const config = await getSystemConfig();
  const botToken = config.telegramBotToken ?? "";
  if (!validateTelegramInitData(body.data.initData, botToken)) {
    return res.status(401).json({ message: "Invalid or expired Telegram data" });
  }
  const tgUser = parseTelegramUser(body.data.initData);
  if (!tgUser) return res.status(400).json({ message: "Missing user in init data" });

  const telegramId = String(tgUser.id);
  const telegramUsername = tgUser.username?.trim() ?? null;
  const existing = await prisma.client.findUnique({
    where: { telegramId },
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, onboardingCompleted: true },
  });
  if (existing) {
    if (existing.isBlocked) return res.status(403).json({ message: "Account is blocked" });
    const auth = buildAuthResponse(existing);
    return res.json(auth);
  }

  const configForDefaults = await getSystemConfig();
  let remnawaveUuid: string | null = null;
  if (isRemnaConfigured()) {
    // Сначала проверяем — может юзер уже есть в Remna (создан ботом или предыдущей попыткой)
    const byTgRes = await remnaGetUserByTelegramId(telegramId);
    remnawaveUuid = extractRemnaUuid(byTgRes.data);

    if (!remnawaveUuid) {
      const username = remnaUsernameFromClient({
        telegramUsername: telegramUsername ?? undefined,
        telegramId,
      });
      // Без активной подписки — как при регистрации по email; доступ после триала или оплаты
      const remnaRes = await remnaCreateUser({
        username,
        trafficLimitBytes: 0,
        trafficLimitStrategy: "NO_RESET",
        expireAt: new Date(Date.now() - 1000).toISOString(),
        telegramId: tgUser.id,
      });
      remnawaveUuid = extractRemnaUuid(remnaRes.data);
      if (remnaRes.error || remnawaveUuid == null) {
        console.error("[Remna] create user (telegram initData) failed:", { error: remnaRes.error, status: remnaRes.status, data: remnaRes.data });
        return res.status(503).json({ message: "Сервис временно недоступен. Не удалось создать учётную запись VPN. Попробуйте позже." });
      }
    }
  }
  const referralCode = generateReferralCode();
  const client = await prisma.client.create({
    data: {
      email: null,
      passwordHash: null,
      remnawaveUuid,
      referralCode,
      referrerId: null,
      preferredLang: configForDefaults.defaultLanguage ?? "ru",
      preferredCurrency: configForDefaults.defaultCurrency ?? "usd",
      telegramId,
      telegramUsername,
      autoRenewEnabled: configForDefaults.defaultAutoRenewEnabled ?? false,
    },
  });
  const token = signClientToken(client.id);
  return res.status(201).json({ token, client: toClientShape(client) });
});

const twoFaLoginSchema = z.object({ tempToken: z.string().min(1), code: z.string().length(6, "Код 6 цифр").regex(/^\d+$/) });
clientAuthRouter.post("/2fa-login", async (req, res) => {
  const body = twoFaLoginSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Введите 6-значный код", errors: body.error.flatten() });
  const payload = verifyClient2FAPendingToken(body.data.tempToken);
  if (!payload) return res.status(401).json({ message: "Сессия истекла. Войдите снова." });
  const client = await prisma.client.findUnique({
    where: { id: payload.clientId },
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpSecret: true, totpEnabled: true, createdAt: true, onboardingCompleted: true },
  });
  if (!client?.totpEnabled || !client.totpSecret) return res.status(401).json({ message: "2FA не включена. Войдите снова." });
  const result = await verify({ secret: client.totpSecret, token: body.data.code });
  if (!result.valid) return res.status(401).json({ message: "Неверный код" });
  const token = signClientToken(client.id);
  return res.json({ token, client: toClientShape(client) });
});

clientAuthRouter.get("/me", requireClientAuth, async (req, res) => {
  const client = (req as unknown as { client: { id: string } }).client;
  const full = await prisma.client.findUnique({
    where: { id: client.id },
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, yookassaPaymentMethodTitle: true, onboardingCompleted: true },
  });
  if (!full) return res.status(401).json({ message: "Unauthorized" });
  return res.json(toClientShape(full));
});

function toClientShape(c: {
  id: string;
  email: string | null;
  telegramId?: string | null;
  telegramUsername?: string | null;
  preferredLang: string;
  preferredCurrency: string;
  balance: number;
  referralCode: string | null;
  referralPercent?: number | null;
  remnawaveUuid: string | null;
  trialUsed?: boolean;
  isBlocked?: boolean;
  yoomoneyAccessToken?: string | null;
  totpEnabled?: boolean;
  createdAt?: Date;
  autoRenewEnabled?: boolean;
  autoRenewTariffId?: string | null;
  yookassaPaymentMethodTitle?: string | null;
  onboardingCompleted?: boolean;
}) {
  return {
    id: c.id,
    email: c.email,
    telegramId: c.telegramId ?? null,
    telegramUsername: c.telegramUsername ?? null,
    preferredLang: c.preferredLang,
    preferredCurrency: c.preferredCurrency,
    balance: c.balance,
    referralCode: c.referralCode,
    referralPercent: c.referralPercent ?? null,
    remnawaveUuid: c.remnawaveUuid,
    trialUsed: c.trialUsed ?? false,
    isBlocked: c.isBlocked ?? false,
    yoomoneyConnected: Boolean(c.yoomoneyAccessToken),
    totpEnabled: c.totpEnabled ?? false,
    createdAt: c.createdAt ? c.createdAt.toISOString() : undefined,
    autoRenewEnabled: c.autoRenewEnabled ?? false,
    autoRenewTariffId: c.autoRenewTariffId ?? null,
    yookassaPaymentMethodTitle: c.yookassaPaymentMethodTitle ?? null,
    onboardingCompleted: c.onboardingCompleted ?? true,
  };
}

/** Если у клиента включена 2FA — возвращаем tempToken для шага ввода кода; иначе — обычные token и client. */
function buildAuthResponse(c: { id: string; totpEnabled?: boolean } & Parameters<typeof toClientShape>[0]) {
  if (c.totpEnabled) {
    return { requires2FA: true as const, tempToken: signClient2FAPendingToken(c.id) };
  }
  return { token: signClientToken(c.id), client: toClientShape(c) };
}

// ——— Google OAuth: фронтенд отправляет id_token, полученный через Sign In With Google ———
const googleAuthSchema = z.object({ idToken: z.string().min(1) });
clientAuthRouter.post("/google", async (req, res) => {
  const parse = googleAuthSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ message: "Invalid input" });
  const config = await getSystemConfig();
  if (!config.googleLoginEnabled || !config.googleClientId) {
    return res.status(403).json({ message: "Google login is not enabled" });
  }
  let payload: { sub?: string; email?: string; email_verified?: boolean } | undefined;
  try {
    const { OAuth2Client } = await import("google-auth-library");
    const gClient = new OAuth2Client(config.googleClientId);
    const ticket = await gClient.verifyIdToken({
      idToken: parse.data.idToken,
      audience: config.googleClientId,
    });
    payload = ticket.getPayload();
  } catch (err) {
    console.error("[Google OAuth] verify error:", err);
    return res.status(401).json({ message: "Invalid Google token" });
  }
  if (!payload?.sub) return res.status(401).json({ message: "Invalid Google token" });
  const googleId = payload.sub;
  const googleEmail = payload.email ?? null;

  const existing = await prisma.client.findUnique({
    where: { googleId },
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, onboardingCompleted: true },
  });
  if (existing) {
    if (existing.isBlocked) return res.status(403).json({ message: "Account is blocked" });
    const auth = buildAuthResponse(existing);
    return res.json(auth);
  }

  if (googleEmail) {
    const byEmail = await prisma.client.findUnique({
      where: { email: googleEmail },
      select: { id: true, email: true, googleId: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, onboardingCompleted: true },
    });
    if (byEmail) {
      if (byEmail.isBlocked) return res.status(403).json({ message: "Account is blocked" });
      await prisma.client.update({ where: { id: byEmail.id }, data: { googleId } });
      const auth = buildAuthResponse(byEmail);
      return res.json(auth);
    }
  }

  const configForDefaults = await getSystemConfig();
  let remnawaveUuid: string | null = null;
  if (isRemnaConfigured()) {
    const username = remnaUsernameFromClient({ email: googleEmail });
    const remnaRes = await remnaCreateUser({
      username,
      trafficLimitBytes: 0,
      trafficLimitStrategy: "NO_RESET",
      expireAt: new Date(Date.now() - 1000).toISOString(),
    });
    remnawaveUuid = extractRemnaUuid(remnaRes.data);
    if (remnaRes.error || remnawaveUuid == null) {
      console.error("[Remna] create user (google) failed:", { error: remnaRes.error, data: remnaRes.data });
      return res.status(503).json({ message: "Service temporarily unavailable" });
    }
  }
  const referralCode = generateReferralCode();
  const client = await prisma.client.create({
    data: {
      email: googleEmail,
      passwordHash: null,
      remnawaveUuid,
      referralCode,
      referrerId: null,
      preferredLang: configForDefaults.defaultLanguage ?? "ru",
      preferredCurrency: configForDefaults.defaultCurrency ?? "usd",
      telegramId: null,
      telegramUsername: null,
      googleId,
      autoRenewEnabled: configForDefaults.defaultAutoRenewEnabled ?? false,
    },
  });
  const token = signClientToken(client.id);
  return res.status(201).json({ token, client: toClientShape(client) });
});

// ——— Apple Sign In: фронтенд отправляет id_token (JWT от Apple) ———
const appleAuthSchema = z.object({ idToken: z.string().min(1) });
clientAuthRouter.post("/apple", async (req, res) => {
  const parse = appleAuthSchema.safeParse(req.body);
  if (!parse.success) return res.status(400).json({ message: "Invalid input" });
  const config = await getSystemConfig();
  if (!config.appleLoginEnabled || !config.appleClientId) {
    return res.status(403).json({ message: "Apple login is not enabled" });
  }

  let appleSub: string | null = null;
  let appleEmail: string | null = null;
  try {
    const { createRemoteJWKSet, jwtVerify } = await import("jose");
    const APPLE_JWKS = createRemoteJWKSet(new URL("https://appleid.apple.com/auth/keys"));
    const { payload: jwtPayload } = await jwtVerify(parse.data.idToken, APPLE_JWKS, {
      issuer: "https://appleid.apple.com",
      audience: config.appleClientId,
    });
    appleSub = (jwtPayload.sub as string) ?? null;
    appleEmail = (jwtPayload as { email?: string }).email ?? null;
  } catch (err) {
    console.error("[Apple OAuth] verify error:", err);
    return res.status(401).json({ message: "Invalid Apple token" });
  }
  if (!appleSub) return res.status(401).json({ message: "Invalid Apple token" });

  const existing = await prisma.client.findUnique({
    where: { appleId: appleSub },
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, onboardingCompleted: true },
  });
  if (existing) {
    if (existing.isBlocked) return res.status(403).json({ message: "Account is blocked" });
    const auth = buildAuthResponse(existing);
    return res.json(auth);
  }

  if (appleEmail) {
    const byEmail = await prisma.client.findUnique({
      where: { email: appleEmail },
      select: { id: true, email: true, appleId: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, onboardingCompleted: true },
    });
    if (byEmail) {
      if (byEmail.isBlocked) return res.status(403).json({ message: "Account is blocked" });
      await prisma.client.update({ where: { id: byEmail.id }, data: { appleId: appleSub } });
      const auth = buildAuthResponse(byEmail);
      return res.json(auth);
    }
  }

  const configForDefaults = await getSystemConfig();
  let remnawaveUuid: string | null = null;
  if (isRemnaConfigured()) {
    const username = remnaUsernameFromClient({ email: appleEmail });
    const remnaRes = await remnaCreateUser({
      username,
      trafficLimitBytes: 0,
      trafficLimitStrategy: "NO_RESET",
      expireAt: new Date(Date.now() - 1000).toISOString(),
    });
    remnawaveUuid = extractRemnaUuid(remnaRes.data);
    if (remnaRes.error || remnawaveUuid == null) {
      console.error("[Remna] create user (apple) failed:", { error: remnaRes.error, data: remnaRes.data });
      return res.status(503).json({ message: "Service temporarily unavailable" });
    }
  }
  const referralCode = generateReferralCode();
  const client = await prisma.client.create({
    data: {
      email: appleEmail,
      passwordHash: null,
      remnawaveUuid,
      referralCode,
      referrerId: null,
      preferredLang: configForDefaults.defaultLanguage ?? "ru",
      preferredCurrency: configForDefaults.defaultCurrency ?? "usd",
      telegramId: null,
      telegramUsername: null,
      appleId: appleSub,
      autoRenewEnabled: configForDefaults.defaultAutoRenewEnabled ?? false,
    },
  });
  const token = signClientToken(client.id);
  return res.status(201).json({ token, client: toClientShape(client) });
});

// ——— Deep-link Telegram авторизация (tg:// протокол, обходит блокировки) ———

// 1) Генерация одноразового токена для deep-link авторизации
clientAuthRouter.post("/telegram-login-token", async (_req, res) => {
  try {
    // Чистим просроченные токены
    await prisma.telegramAuthToken.deleteMany({
      where: { expiresAt: { lt: new Date() } },
    });

    const token = randomBytes(16).toString("hex"); // 32 hex chars — with "auth_" prefix = 37, well under Telegram's 64-char start param limit
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 минут

    const record = await prisma.telegramAuthToken.create({
      data: { token, expiresAt },
    });

    return res.json({ token: record.token, expiresAt: record.expiresAt.toISOString() });
  } catch (err) {
    console.error("[telegram-login-token] error:", err);
    return res.status(500).json({ message: "Failed to generate auth token" });
  }
});

// 2) Поллинг: проверяем, подтвердил ли пользователь токен через бота
clientAuthRouter.get("/telegram-login-check", async (req, res) => {
  const { token } = req.query;
  if (typeof token !== "string" || !token.trim()) {
    return res.status(400).json({ message: "Missing token" });
  }

  try {
    const record = await prisma.telegramAuthToken.findUnique({
      where: { token: token.trim() },
    });

    if (!record) {
      return res.status(404).json({ message: "Token not found or expired" });
    }

    if (record.expiresAt < new Date()) {
      await prisma.telegramAuthToken.delete({ where: { id: record.id } }).catch(() => {});
      return res.status(410).json({ message: "Token expired" });
    }

    if (!record.confirmedTelegramId) {
      return res.json({ confirmed: false });
    }

    // Токен подтверждён — ищем/создаём клиента
    const telegramId = record.confirmedTelegramId;
    const telegramUsername = record.confirmedUsername ?? null;

    // Удаляем использованный токен
    await prisma.telegramAuthToken.delete({ where: { id: record.id } }).catch(() => {});

    const clientSelect = { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true };

    const existing = await prisma.client.findUnique({
      where: { telegramId },
      select: clientSelect,
    });

    if (existing) {
      if (existing.isBlocked) return res.status(403).json({ message: "Account is blocked" });
      // Обновляем username если изменился
      if (telegramUsername && existing.telegramUsername !== telegramUsername) {
        await prisma.client.update({ where: { id: existing.id }, data: { telegramUsername } }).catch(() => {});
      }
      const auth = buildAuthResponse(existing);
      return res.json({ confirmed: true, ...auth });
    }

    // Новый клиент — регистрируем
    const configForDefaults = await getSystemConfig();
    let remnawaveUuid: string | null = null;
    if (isRemnaConfigured()) {
      // Сначала проверяем — может юзер уже есть в Remna (создан ботом или предыдущей попыткой)
      const byTgRes = await remnaGetUserByTelegramId(telegramId);
      remnawaveUuid = extractRemnaUuid(byTgRes.data);

      if (!remnawaveUuid) {
        const username = remnaUsernameFromClient({
          telegramUsername: telegramUsername ?? undefined,
          telegramId,
        });
        const remnaRes = await remnaCreateUser({
          username,
          trafficLimitBytes: 0,
          trafficLimitStrategy: "NO_RESET",
          expireAt: new Date(Date.now() - 1000).toISOString(),
          telegramId: Number(telegramId),
        });
        remnawaveUuid = extractRemnaUuid(remnaRes.data);
        if (remnaRes.error || remnawaveUuid == null) {
          console.error("[Remna] create user (telegram deeplink) failed:", { error: remnaRes.error, status: remnaRes.status, data: remnaRes.data });
          return res.status(503).json({ message: "Сервис временно недоступен. Попробуйте позже." });
        }
      }
    }

    const referralCode = generateReferralCode();
    const client = await prisma.client.create({
      data: {
        email: null,
        passwordHash: null,
        remnawaveUuid,
        referralCode,
        referrerId: null,
        preferredLang: configForDefaults.defaultLanguage ?? "ru",
        preferredCurrency: configForDefaults.defaultCurrency ?? "usd",
        telegramId,
        telegramUsername,
        autoRenewEnabled: configForDefaults.defaultAutoRenewEnabled ?? false,
      },
    });

    notifyAdminsAboutNewClient(client.id).catch(() => {});
    const jwt = signClientToken(client.id);
    return res.json({ confirmed: true, token: jwt, client: toClientShape(client), justCreated: true });
  } catch (err) {
    console.error("[telegram-login-check] error:", err);
    return res.status(500).json({ message: "Internal error" });
  }
});

// 3) Подтверждение токена ботом (бот вызывает этот эндпоинт, когда юзер отправляет /start auth_TOKEN)
clientAuthRouter.post("/telegram-login-confirm", async (req, res) => {
  // Проверяем что запрос от нашего бота
  const config = await getSystemConfig();
  const expectedBotToken = (config.telegramBotToken ?? "").trim();
  const receivedBotToken = (req.headers["x-telegram-bot-token"] as string ?? "").trim();

  if (!expectedBotToken || receivedBotToken !== expectedBotToken) {
    return res.status(403).json({ message: "Unauthorized" });
  }

  const { token, telegramId, telegramUsername } = req.body ?? {};
  if (typeof token !== "string" || !token.trim()) {
    return res.status(400).json({ message: "Missing token" });
  }
  if (telegramId == null) {
    return res.status(400).json({ message: "Missing telegramId" });
  }

  try {
    const record = await prisma.telegramAuthToken.findUnique({
      where: { token: token.trim() },
    });

    if (!record) {
      return res.status(404).json({ message: "Token not found" });
    }

    if (record.expiresAt < new Date()) {
      await prisma.telegramAuthToken.delete({ where: { id: record.id } }).catch(() => {});
      return res.status(410).json({ message: "Token expired" });
    }

    if (record.confirmedTelegramId) {
      return res.status(409).json({ message: "Token already confirmed" });
    }

    await prisma.telegramAuthToken.update({
      where: { id: record.id },
      data: {
        confirmedTelegramId: String(telegramId),
        confirmedUsername: telegramUsername ? String(telegramUsername) : null,
      },
    });

    return res.json({ ok: true });
  } catch (err) {
    console.error("[telegram-login-confirm] error:", err);
    return res.status(500).json({ message: "Internal error" });
  }
});

// Единый роутер /api/client: /auth (логин, регистрация, me) + кабинет (подписка, платежи)
export const clientRouter = Router();
clientRouter.use("/auth", clientAuthRouter);

// ЮMoney OAuth callback — без авторизации клиента (редирект с ЮMoney)
function yoomoneyStateSign(clientId: string): string {
  const payload = JSON.stringify({ clientId });
  const sig = createHmac("sha256", env.JWT_SECRET).update(payload).digest("base64url");
  return Buffer.from(payload, "utf8").toString("base64url") + "." + sig;
}
function yoomoneyStateVerify(state: string): string | null {
  const dot = state.indexOf(".");
  if (dot <= 0) return null;
  const payloadB64 = state.slice(0, dot);
  const sig = state.slice(dot + 1);
  try {
    const payload = JSON.parse(Buffer.from(payloadB64, "base64url").toString("utf8")) as { clientId?: string };
    if (!payload?.clientId) return null;
    const expected = createHmac("sha256", env.JWT_SECRET).update(JSON.stringify({ clientId: payload.clientId })).digest("base64url");
    if (sig !== expected) return null;
    return payload.clientId;
  } catch {
    return null;
  }
}

clientRouter.get("/yoomoney/callback", async (req, res) => {
  const code = typeof req.query.code === "string" ? req.query.code : null;
  const state = typeof req.query.state === "string" ? req.query.state : null;
  const config = await getSystemConfig();
  const appUrl = (config.publicAppUrl || "").replace(/\/$/, "");
  const redirectFail = appUrl ? `${appUrl}/cabinet?yoomoney=error` : "/";
  if (!code?.trim() || !state?.trim()) {
    return res.redirect(302, redirectFail);
  }
  const clientId = yoomoneyStateVerify(state);
  if (!clientId) {
    return res.redirect(302, redirectFail);
  }
  const redirectUri = appUrl ? `${appUrl}/api/client/yoomoney/callback` : "";
  if (!redirectUri) {
    return res.redirect(302, redirectFail);
  }
  const result = await exchangeCodeForToken({
    code: code.trim(),
    clientId: config.yoomoneyClientId || "",
    redirectUri,
    clientSecret: config.yoomoneyClientSecret,
  });
  if ("error" in result) {
    return res.redirect(302, appUrl ? `${appUrl}/cabinet?yoomoney=error&reason=${encodeURIComponent(result.error)}` : redirectFail);
  }
  await prisma.client.update({
    where: { id: clientId },
    data: { yoomoneyAccessToken: result.access_token },
  });
  const redirectOk = appUrl ? `${appUrl}/cabinet?yoomoney=connected` : redirectFail;
  return res.redirect(302, redirectOk);
});

// ——— Tour Steps (публичные, без авторизации — ПЕРЕД requireClientAuth!) ———
clientRouter.get("/tour-steps", async (_req, res) => {
  try {
    const steps = await prisma.tourStep.findMany({
      where: { isActive: true },
      include: { mascot: { include: { emotions: true } } },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    });
    return res.json({
      items: steps.map(s => ({
        id: s.id,
        target: s.target,
        targetLabel: s.targetLabel,
        title: s.title,
        content: s.content,
        videoUrl: s.videoUrl,
        placement: s.placement,
        route: s.route,
        mascotId: s.mascotId,
        mood: s.mood,
        sortOrder: s.sortOrder,
        mascot: s.mascot ? {
          id: s.mascot.id, name: s.mascot.name, imageUrl: s.mascot.imageUrl,
          emotions: (s.mascot.emotions ?? []).map((e: { id: string; mood: string; imageUrl: string }) => ({
            id: e.id, mood: e.mood, imageUrl: e.imageUrl,
          })),
        } : null,
      })),
    });
  } catch (e) {
    console.error("GET /tour-steps error:", e);
    return res.status(500).json({ message: "Ошибка загрузки шагов тура" });
  }
});

clientRouter.use(requireClientAuth);

// ——— 2FA (TOTP) ———
const twoFaConfirmSchema = z.object({ code: z.string().length(6, "Код должен быть 6 цифр").regex(/^\d+$/) });
clientRouter.post("/2fa/setup", async (req, res) => {
  const client = (req as unknown as { client: { id: string; email: string | null } }).client;
  const current = await prisma.client.findUnique({ where: { id: client.id }, select: { totpEnabled: true } });
  if (current?.totpEnabled) return res.status(400).json({ message: "2FA уже включена" });
  const secret = generateSecret();
  const label = client.email?.trim() || `client-${client.id}`;
  const otpauthUrl = generateURI({ issuer: "STEALTHNET", label, secret });
  await prisma.client.update({
    where: { id: client.id },
    data: { totpSecret: secret, totpEnabled: false },
  });
  return res.json({ secret, otpauthUrl });
});
clientRouter.post("/2fa/confirm", async (req, res) => {
  const client = (req as unknown as { client: { id: string } }).client;
  const body = twoFaConfirmSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Введите 6-значный код из приложения", errors: body.error.flatten() });
  const row = await prisma.client.findUnique({ where: { id: client.id }, select: { totpSecret: true, totpEnabled: true } });
  if (!row?.totpSecret) return res.status(400).json({ message: "Сначала запустите настройку 2FA" });
  if (row.totpEnabled) return res.status(400).json({ message: "2FA уже включена" });
  const result = await verify({ secret: row.totpSecret, token: body.data.code });
  if (!result.valid) return res.status(400).json({ message: "Неверный код. Проверьте время на устройстве." });
  await prisma.client.update({
    where: { id: client.id },
    data: { totpEnabled: true },
  });
  return res.json({ message: "Двухфакторная аутентификация включена" });
});
clientRouter.post("/2fa/disable", async (req, res) => {
  const client = (req as unknown as { client: { id: string } }).client;
  const body = twoFaConfirmSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Введите 6-значный код из приложения", errors: body.error.flatten() });
  const row = await prisma.client.findUnique({ where: { id: client.id }, select: { totpSecret: true, totpEnabled: true } });
  if (!row?.totpEnabled || !row.totpSecret) return res.status(400).json({ message: "2FA не включена" });
  const result = await verify({ secret: row.totpSecret, token: body.data.code });
  if (!result.valid) return res.status(400).json({ message: "Неверный код" });
  await prisma.client.update({
    where: { id: client.id },
    data: { totpSecret: null, totpEnabled: false },
  });
  return res.json({ message: "Двухфакторная аутентификация отключена" });
});

// ——— Change Password ———
const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, "Введите текущий пароль"),
  newPassword: z.string().min(6, "Минимум 6 символов"),
});

clientRouter.post("/change-password", requireClientAuth, async (req, res) => {
  const client = (req as unknown as { client: { id: string; passwordHash: string | null } }).client;
  const body = changePasswordSchema.safeParse(req.body);
  if (!body.success) {
    return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });
  }

  // Получаем актуальный passwordHash из базы
  const clientData = await prisma.client.findUnique({
    where: { id: client.id },
    select: { passwordHash: true },
  });

  if (!clientData?.passwordHash) {
    return res.status(400).json({ message: "У вас нет пароля. Используйте вход через Telegram или Email." });
  }

  const valid = await verifyPassword(body.data.currentPassword, clientData.passwordHash);
  if (!valid) {
    return res.status(400).json({ message: "Неверный текущий пароль" });
  }

  const newPasswordHash = await hashPassword(body.data.newPassword);
  await prisma.client.update({
    where: { id: client.id },
    data: { passwordHash: newPasswordHash },
  });

  return res.json({ message: "Пароль успешно изменён" });
});

const setPasswordSchema = z.object({
  newPassword: z.string().min(6, "Минимум 6 символов"),
});

clientRouter.post("/set-password", requireClientAuth, async (req, res) => {
  const client = (req as unknown as { client: { id: string; passwordHash: string | null } }).client;
  const body = setPasswordSchema.safeParse(req.body);
  if (!body.success) {
    return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });
  }

  const clientData = await prisma.client.findUnique({
    where: { id: client.id },
    select: { passwordHash: true, onboardingCompleted: true },
  });

  // Разрешаем установку пароля если: пароля нет ИЛИ онбоардинг не завершён (dummy-пароль от email-регистрации)
  if (clientData?.passwordHash && clientData.onboardingCompleted) {
    return res.status(400).json({ message: "Пароль уже установлен. Используйте смену пароля." });
  }

  const newPasswordHash = await hashPassword(body.data.newPassword);
  await prisma.client.update({
    where: { id: client.id },
    data: { passwordHash: newPasswordHash },
  });

  return res.json({ message: "Пароль установлен" });
});

clientRouter.post("/complete-onboarding", requireClientAuth, async (req, res) => {
  const client = (req as unknown as { client: { id: string } }).client;
  await prisma.client.update({
    where: { id: client.id },
    data: { onboardingCompleted: true },
  });
  return res.json({ message: "Onboarding завершён" });
});

const updateProfileSchema = z.object({
  preferredLang: z.string().max(10).optional(),
  preferredCurrency: z.string().max(10).optional(),
});

clientRouter.patch("/profile", async (req, res) => {
  const client = (req as unknown as { client: { id: string } }).client;
  const body = updateProfileSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });
  const updates: { preferredLang?: string; preferredCurrency?: string } = {};
  if (body.data.preferredLang !== undefined) updates.preferredLang = body.data.preferredLang;
  if (body.data.preferredCurrency !== undefined) updates.preferredCurrency = body.data.preferredCurrency;
  if (Object.keys(updates).length === 0) {
    const current = await prisma.client.findUnique({ where: { id: client.id }, select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, createdAt: true, onboardingCompleted: true } });
    return res.json(current ? toClientShape(current) : { message: "Not found" });
  }
  const updated = await prisma.client.update({
    where: { id: client.id },
    data: updates,
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, createdAt: true, onboardingCompleted: true },
  });
  return res.json(toClientShape(updated));
});

const updateAutoRenewSchema = z.object({
  enabled: z.boolean().optional(),
  tariffId: z.string().nullable().optional(),
});

clientRouter.patch("/auto-renew", async (req, res) => {
  const client = (req as unknown as { client: { id: string } }).client;
  const body = updateAutoRenewSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });

  const updates: { autoRenewEnabled?: boolean; autoRenewTariffId?: string | null } = {};
  if (body.data.enabled !== undefined) updates.autoRenewEnabled = body.data.enabled;
  if (body.data.tariffId !== undefined) updates.autoRenewTariffId = body.data.tariffId;

  if (Object.keys(updates).length === 0) {
    const current = await prisma.client.findUnique({ where: { id: client.id }, select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, createdAt: true, onboardingCompleted: true } });
    return res.json(current ? toClientShape(current) : { message: "Not found" });
  }

  const updated = await prisma.client.update({
    where: { id: client.id },
    data: updates,
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, createdAt: true, onboardingCompleted: true },
  });
  return res.json(toClientShape(updated));
});

/** Запросить код для привязки Telegram через бота (аккаунт без Telegram, залогинен по почте) */
clientRouter.post("/link-telegram-request", async (req, res) => {
  const client = (req as unknown as { client: { id: string; telegramId: string | null } }).client;
  if (client.telegramId) return res.status(400).json({ message: "Telegram уже привязан" });
  await prisma.pendingTelegramLink.deleteMany({ where: { clientId: client.id } });
  const code = String(Math.floor(100000 + Math.random() * 900000));
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);
  await prisma.pendingTelegramLink.create({
    data: { clientId: client.id, code, expiresAt },
  });
  const config = await getSystemConfig();
  const botUsername = (config.telegramBotUsername ?? "").replace(/^@/, "") || null;
  return res.json({ code, expiresAt: expiresAt.toISOString(), botUsername });
});

/** Привязать Telegram из Mini App (initData от Telegram WebApp) */
const linkTelegramSchema = z.object({ initData: z.string().min(1) });
clientRouter.post("/link-telegram", async (req, res) => {
  const client = (req as unknown as { client: { id: string; telegramId: string | null } }).client;
  if (client.telegramId) return res.status(400).json({ message: "Telegram уже привязан" });
  const body = linkTelegramSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });
  const config = await getSystemConfig();
  const botToken = config.telegramBotToken ?? "";
  if (!validateTelegramInitData(body.data.initData, botToken)) {
    return res.status(401).json({ message: "Недействительные или устаревшие данные Telegram" });
  }
  const tgUser = parseTelegramUser(body.data.initData);
  if (!tgUser) return res.status(400).json({ message: "Нет данных пользователя" });
  const telegramId = String(tgUser.id);
  const telegramUsername = tgUser.username?.trim() ?? null;
  const other = await prisma.client.findUnique({ where: { telegramId } });
  if (other && other.id !== client.id) {
    return res.status(409).json({ message: "Этот Telegram-аккаунт уже привязан к другому аккаунту. Сначала войдите в тот аккаунт и отвяжите Telegram, либо обратитесь в поддержку." });
  }
  const updated = await prisma.client.update({
    where: { id: client.id },
    data: { telegramId, telegramUsername },
    select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, createdAt: true, onboardingCompleted: true },
  });
  return res.json({ client: toClientShape(updated) });
});

/** Запросить привязку email (отправить письмо со ссылкой) */
const linkEmailRequestSchema = z.object({ email: z.string().email() });
clientRouter.post("/link-email-request", async (req, res) => {
  const client = (req as unknown as { client: { id: string; email: string | null } }).client;
  if (client.email?.trim()) return res.status(400).json({ message: "Почта уже привязана" });
  const body = linkEmailRequestSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Некорректный email", errors: body.error.flatten() });
  const email = body.data.email.trim().toLowerCase();
  const config = await getSystemConfig();
  const smtpConfig = {
    host: config.smtpHost || "",
    port: config.smtpPort ?? 587,
    secure: config.smtpSecure ?? false,
    user: config.smtpUser ?? null,
    password: config.smtpPassword ?? null,
    fromEmail: config.smtpFromEmail ?? null,
    fromName: config.smtpFromName ?? null,
  };
  if (!isSmtpConfigured(smtpConfig)) return res.status(503).json({ message: "Отправка писем не настроена. Обратитесь в поддержку." });
  const existing = await prisma.client.findUnique({ where: { email } });
  if (existing && existing.id !== client.id) return res.status(400).json({ message: "Эта почта уже используется другим аккаунтом" });
  await prisma.pendingEmailLink.deleteMany({ where: { clientId: client.id } });
  const verificationToken = randomUUID();
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
  await prisma.pendingEmailLink.create({
    data: { clientId: client.id, email, verificationToken, expiresAt },
  });
  const appUrl = (config.publicAppUrl || "").replace(/\/$/, "");
  const verificationLink = appUrl ? `${appUrl}/cabinet/verify-link-email?token=${verificationToken}` : "";
  if (!verificationLink) return res.status(500).json({ message: "Не задан URL приложения в настройках" });
  const sendResult = await sendLinkEmailVerification(smtpConfig, email, verificationLink, config.serviceName ?? "STEALTHNET");
  if (!sendResult.ok) {
    await prisma.pendingEmailLink.deleteMany({ where: { verificationToken } }).catch(() => {});
    return res.status(500).json({ message: "Не удалось отправить письмо. Попробуйте позже." });
  }
  return res.json({ message: "Письмо с ссылкой отправлено на указанный email" });
});

clientRouter.get("/referral-stats", async (req, res) => {
  const client = (req as unknown as { client: { id: string } }).client;
  const c = await prisma.client.findUnique({
    where: { id: client.id },
    select: {
      referralCode: true,
      referralPercent: true,
      _count: { select: { referrals: true } },
    },
  });
  if (!c) return res.status(404).json({ message: "Not found" });
  const config = await getSystemConfig();
  // Показываем фактический персональный процент клиента.
  // Если он не задан (null), используем дефолт из системных настроек.
  const referralPercent: number = c.referralPercent ?? (config.defaultReferralPercent ?? 0);
  const totalEarnings = await prisma.referralCredit.aggregate({
    where: { referrerId: client.id },
    _sum: { amount: true },
  });
  return res.json({
    referralCode: c.referralCode,
    referralPercent,
    referralPercentLevel2: config.referralPercentLevel2 ?? 0,
    referralPercentLevel3: config.referralPercentLevel3 ?? 0,
    referralCount: c._count.referrals,
    totalEarnings: totalEarnings._sum.amount ?? 0,
  });
});

clientRouter.post("/trial", async (req, res) => {
  const client = (req as unknown as { client: { id: string; remnawaveUuid: string | null; trialUsed: boolean; email: string | null; telegramId: string | null; telegramUsername?: string | null } }).client;
  if (client.trialUsed) {
    return res.status(400).json({ message: "Бесплатный тест уже использован" });
  }
  const config = await getSystemConfig();
  const trialDays = config.trialDays ?? 0;
  const trialSquadUuid = config.trialSquadUuid?.trim() || null;
  if (trialDays <= 0 || !trialSquadUuid) {
    return res.status(503).json({ message: "Бесплатный тест не настроен" });
  }
  if (!isRemnaConfigured()) {
    return res.status(503).json({ message: "Сервис временно недоступен" });
  }

  const trafficLimitBytes = config.trialTrafficLimitBytes ?? 0;
  const hwidDeviceLimit = config.trialDeviceLimit ?? null;

  let workingUuid = client.remnawaveUuid;

  if (workingUuid) {
    const checkRes = await remnaGetUser(workingUuid);
    if (checkRes.error || !checkRes.data) {
      console.warn(`[trial] Remna user ${workingUuid} not found (status ${checkRes.status}), will re-create`);
      workingUuid = null;
      await prisma.client.update({ where: { id: client.id }, data: { remnawaveUuid: null } });
    }
  }

  if (workingUuid) {
    const userRes = await remnaGetUser(workingUuid);
    const currentExpireAt = extractCurrentExpireAt(userRes.data);
    const expireAt = calculateExpireAt(currentExpireAt, trialDays);

    const updateRes = await remnaUpdateUser({
      uuid: workingUuid,
      expireAt,
      trafficLimitBytes,
      hwidDeviceLimit,
      activeInternalSquads: [trialSquadUuid],
    });
    if (updateRes.error) {
      return res.status(updateRes.status >= 400 ? updateRes.status : 500).json({ message: updateRes.error });
    }
  } else {
    let existingUuid: string | null = null;
    let currentExpireAt: Date | null = null;
    if (client.telegramId?.trim()) {
      const byTgRes = await remnaGetUserByTelegramId(client.telegramId.trim());
      existingUuid = extractRemnaUuid(byTgRes.data);
      if (existingUuid) currentExpireAt = extractCurrentExpireAt(byTgRes.data);
    }
    if (!existingUuid && client.email?.trim()) {
      const byEmailRes = await remnaGetUserByEmail(client.email.trim());
      existingUuid = extractRemnaUuid(byEmailRes.data);
      if (existingUuid) currentExpireAt = extractCurrentExpireAt(byEmailRes.data);
    }
    const displayUsername = remnaUsernameFromClient({
      telegramUsername: client.telegramUsername,
      telegramId: client.telegramId,
      email: client.email,
      clientIdFallback: client.id,
    });
    if (!existingUuid) {
      const byUsernameRes = await remnaGetUserByUsername(displayUsername);
      existingUuid = extractRemnaUuid(byUsernameRes.data);
      if (existingUuid) currentExpireAt = extractCurrentExpireAt(byUsernameRes.data);
    }

    const expireAt = calculateExpireAt(currentExpireAt, trialDays);

    if (!existingUuid) {
      const createRes = await remnaCreateUser({
        username: displayUsername,
        trafficLimitBytes,
        trafficLimitStrategy: "NO_RESET",
        expireAt,
        hwidDeviceLimit: hwidDeviceLimit ?? undefined,
        activeInternalSquads: [trialSquadUuid],
        ...(client.telegramId?.trim() && { telegramId: parseInt(client.telegramId, 10) }),
        ...(client.email?.trim() && { email: client.email.trim() }),
      });
      existingUuid = extractRemnaUuid(createRes.data);
    }

    if (!existingUuid) {
      return res.status(502).json({ message: "Ошибка создания пользователя" });
    }

    await remnaUpdateUser({
      uuid: existingUuid,
      expireAt,
      trafficLimitBytes,
      hwidDeviceLimit,
      activeInternalSquads: [trialSquadUuid],
    });
    workingUuid = existingUuid;
    await prisma.client.update({
      where: { id: client.id },
      data: { remnawaveUuid: existingUuid, trialUsed: true },
    });
    const updated = await prisma.client.findUnique({ where: { id: client.id }, select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, createdAt: true, onboardingCompleted: true } });
    return res.json({ message: "Бесплатный тест активирован", client: updated ? toClientShape(updated) : null });
  }

  await prisma.client.update({
    where: { id: client.id },
    data: { trialUsed: true },
  });
  const updated = await prisma.client.findUnique({ where: { id: client.id }, select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, createdAt: true, onboardingCompleted: true } });
  return res.json({ message: "Бесплатный тест активирован", client: updated ? toClientShape(updated) : null });
});

// ——— Активация промо-ссылки ———
clientRouter.post("/promo/activate", async (req, res) => {
  const client = (req as unknown as { client: { id: string; remnawaveUuid: string | null; email: string | null; telegramId: string | null; telegramUsername?: string | null } }).client;
  const { code } = req.body as { code?: string };
  if (!code?.trim()) return res.status(400).json({ message: "Промокод не указан" });

  const group = await prisma.promoGroup.findUnique({ where: { code: code.trim() } });
  if (!group || !group.isActive) return res.status(404).json({ message: "Промокод не найден или неактивен" });

  // Проверяем, не активировал ли уже этот клиент эту промо-группу
  const existing = await prisma.promoActivation.findUnique({
    where: { promoGroupId_clientId: { promoGroupId: group.id, clientId: client.id } },
  });
  if (existing) return res.status(400).json({ message: "Вы уже активировали этот промокод" });

  // Проверяем лимит активаций
  if (group.maxActivations > 0) {
    const count = await prisma.promoActivation.count({ where: { promoGroupId: group.id } });
    if (count >= group.maxActivations) return res.status(400).json({ message: "Лимит активаций промокода исчерпан" });
  }

  if (!isRemnaConfigured()) return res.status(503).json({ message: "Сервис временно недоступен" });

  const trafficLimitBytes = Number(group.trafficLimitBytes);
  const hwidDeviceLimit = group.deviceLimit ?? null;

  let promoWorkingUuid = client.remnawaveUuid;

  if (promoWorkingUuid) {
    const checkRes = await remnaGetUser(promoWorkingUuid);
    if (checkRes.error || !checkRes.data) {
      console.warn(`[promo] Remna user ${promoWorkingUuid} not found (status ${checkRes.status}), will re-create`);
      promoWorkingUuid = null;
      await prisma.client.update({ where: { id: client.id }, data: { remnawaveUuid: null } });
    }
  }

  if (promoWorkingUuid) {
    const userRes = await remnaGetUser(promoWorkingUuid);
    const currentExpireAt = extractCurrentExpireAt(userRes.data);
    const expireAt = calculateExpireAt(currentExpireAt, group.durationDays);

    const updateRes = await remnaUpdateUser({
      uuid: promoWorkingUuid,
      expireAt,
      trafficLimitBytes,
      hwidDeviceLimit,
      activeInternalSquads: [group.squadUuid],
    });
    if (updateRes.error) {
      return res.status(updateRes.status >= 400 ? updateRes.status : 500).json({ message: updateRes.error });
    }
  } else {
    let existingUuid: string | null = null;
    let currentExpireAt: Date | null = null;
    if (client.telegramId?.trim()) {
      const byTgRes = await remnaGetUserByTelegramId(client.telegramId.trim());
      existingUuid = extractRemnaUuid(byTgRes.data);
      if (existingUuid) currentExpireAt = extractCurrentExpireAt(byTgRes.data);
    }
    if (!existingUuid && client.email?.trim()) {
      const byEmailRes = await remnaGetUserByEmail(client.email.trim());
      existingUuid = extractRemnaUuid(byEmailRes.data);
      if (existingUuid) currentExpireAt = extractCurrentExpireAt(byEmailRes.data);
    }
    const displayUsername = remnaUsernameFromClient({
      telegramUsername: client.telegramUsername,
      telegramId: client.telegramId,
      email: client.email,
      clientIdFallback: client.id,
    });
    const expireAt = calculateExpireAt(currentExpireAt, group.durationDays);
    if (!existingUuid) {
      const createRes = await remnaCreateUser({
        username: displayUsername,
        trafficLimitBytes,
        trafficLimitStrategy: "NO_RESET",
        expireAt,
        hwidDeviceLimit: hwidDeviceLimit ?? undefined,
        activeInternalSquads: [group.squadUuid],
        ...(client.telegramId?.trim() && { telegramId: parseInt(client.telegramId, 10) }),
        ...(client.email?.trim() && { email: client.email.trim() }),
      });
      existingUuid = extractRemnaUuid(createRes.data);
    }
    if (!existingUuid) return res.status(502).json({ message: "Ошибка создания пользователя VPN" });

    await remnaUpdateUser({ uuid: existingUuid, expireAt, trafficLimitBytes, hwidDeviceLimit, activeInternalSquads: [group.squadUuid] });

    await prisma.client.update({
      where: { id: client.id },
      data: { remnawaveUuid: existingUuid },
    });
  }

  // Записываем активацию
  await prisma.promoActivation.create({
    data: { promoGroupId: group.id, clientId: client.id },
  });

  return res.json({ message: "Промокод активирован! Подписка подключена." });
});

// ——— Промокоды (скидки / бесплатные дни) ———

/** Общая валидация промокода — возвращает объект PromoCode или ошибку */
type PromoCodeRow = NonNullable<Awaited<ReturnType<typeof prisma.promoCode.findUnique>>>;
type ValidateResult = { ok: true; promo: PromoCodeRow } | { ok: false; error: string; status: number };

async function validatePromoCode(code: string, clientId: string): Promise<ValidateResult> {
  const promo = await prisma.promoCode.findUnique({ where: { code: code.trim() } });
  if (!promo || !promo.isActive) return { ok: false, error: "Промокод не найден или неактивен", status: 404 };
  if (promo.expiresAt && promo.expiresAt < new Date()) return { ok: false, error: "Срок действия промокода истёк", status: 400 };

  if (promo.maxUses > 0) {
    const totalUsages = await prisma.promoCodeUsage.count({ where: { promoCodeId: promo.id } });
    if (totalUsages >= promo.maxUses) return { ok: false, error: "Лимит использований промокода исчерпан", status: 400 };
  }

  const clientUsages = await prisma.promoCodeUsage.count({
    where: { promoCodeId: promo.id, clientId },
  });
  if (clientUsages >= promo.maxUsesPerClient) return { ok: false, error: "Вы уже использовали этот промокод", status: 400 };

  return { ok: true, promo };
}

/** Проверить промокод (для скидки — возвращает данные скидки; для FREE_DAYS — информацию) */
clientRouter.post("/promo-code/check", async (req, res) => {
  const client = (req as unknown as { client: { id: string } }).client;
  const { code } = req.body as { code?: string };
  if (!code?.trim()) return res.status(400).json({ message: "Промокод не указан" });

  const result = await validatePromoCode(code, client.id);
  if (!result.ok) return res.status(result.status).json({ message: result.error });

  const promo = result.promo;
  if (promo.type === "DISCOUNT") {
    return res.json({
      type: "DISCOUNT",
      discountPercent: promo.discountPercent,
      discountFixed: promo.discountFixed,
      name: promo.name,
    });
  }
  return res.json({
    type: "FREE_DAYS",
    durationDays: promo.durationDays,
    name: promo.name,
  });
});

/** Применить промокод FREE_DAYS — активирует подписку */
clientRouter.post("/promo-code/activate", async (req, res) => {
  const client = (req as unknown as { client: { id: string; remnawaveUuid: string | null; email: string | null; telegramId: string | null; telegramUsername?: string | null } }).client;
  const { code } = req.body as { code?: string };
  if (!code?.trim()) return res.status(400).json({ message: "Промокод не указан" });

  const result = await validatePromoCode(code, client.id);
  if (!result.ok) return res.status(result.status).json({ message: result.error });

  const promo = result.promo;

  if (promo.type === "DISCOUNT") {
    return res.status(400).json({ message: "Промокод на скидку применяется при оплате тарифа" });
  }

  // FREE_DAYS
  if (!promo.squadUuid || !promo.durationDays) {
    return res.status(400).json({ message: "Промокод не полностью настроен" });
  }

  if (!isRemnaConfigured()) return res.status(503).json({ message: "Сервис временно недоступен" });

  const trafficLimitBytes = Number(promo.trafficLimitBytes ?? 0);
  const hwidDeviceLimit = promo.deviceLimit ?? null;

  if (client.remnawaveUuid) {
    const userRes = await remnaGetUser(client.remnawaveUuid);
    const currentExpireAt = extractCurrentExpireAt(userRes.data);
    const expireAt = calculateExpireAt(currentExpireAt, promo.durationDays);

    const updateRes = await remnaUpdateUser({
      uuid: client.remnawaveUuid,
      expireAt,
      trafficLimitBytes,
      hwidDeviceLimit,
      activeInternalSquads: [promo.squadUuid],
    });
    if (updateRes.error) {
      return res.status(updateRes.status >= 400 ? updateRes.status : 500).json({ message: updateRes.error });
    }
    // Не вызываем add-users: по api-1.yaml эндпоинт добавляет ВСЕХ пользователей в сквад.
  } else {
    let existingUuid: string | null = null;
    let currentExpireAt: Date | null = null;
    if (client.telegramId?.trim()) {
      const byTgRes = await remnaGetUserByTelegramId(client.telegramId.trim());
      existingUuid = extractRemnaUuid(byTgRes.data);
      if (existingUuid) currentExpireAt = extractCurrentExpireAt(byTgRes.data);
    }
    if (!existingUuid && client.email) {
      const byEmailRes = await remnaGetUserByEmail(client.email.trim());
      existingUuid = extractRemnaUuid(byEmailRes.data);
      if (existingUuid) currentExpireAt = extractCurrentExpireAt(byEmailRes.data);
    }
    const displayUsername = remnaUsernameFromClient({
      telegramUsername: client.telegramUsername,
      telegramId: client.telegramId,
      email: client.email,
      clientIdFallback: client.id,
    });
    const expireAt = calculateExpireAt(currentExpireAt, promo.durationDays);
    if (!existingUuid) {
      const createRes = await remnaCreateUser({
        username: displayUsername,
        trafficLimitBytes,
        trafficLimitStrategy: "NO_RESET",
        expireAt,
        hwidDeviceLimit: hwidDeviceLimit ?? undefined,
        activeInternalSquads: [promo.squadUuid],
        ...(client.telegramId?.trim() && { telegramId: parseInt(client.telegramId, 10) }),
        ...(client.email?.trim() && { email: client.email.trim() }),
      });
      existingUuid = extractRemnaUuid(createRes.data);
    }
    if (!existingUuid) return res.status(502).json({ message: "Ошибка создания пользователя VPN" });

    await remnaUpdateUser({ uuid: existingUuid, expireAt, trafficLimitBytes, hwidDeviceLimit, activeInternalSquads: [promo.squadUuid] });
    // Не вызываем add-users: по api-1.yaml эндпоинт добавляет ВСЕХ пользователей в сквад.
    await prisma.client.update({ where: { id: client.id }, data: { remnawaveUuid: existingUuid } });
  }

  await prisma.promoCodeUsage.create({ data: { promoCodeId: promo.id, clientId: client.id } });
  return res.json({ message: `Промокод активирован! Подписка на ${promo.durationDays} дн. подключена.` });
});

/** Определить отображаемое имя тарифа: Триал, название с сайта или «Тариф не выбран».
 *  Поддерживает activeInternalSquads как массив строк (uuid) или объектов { uuid }.
 *  Приоритет: сначала ищем совпадение с оплаченным тарифом, затем — триал. */
async function resolveTariffDisplayName(remnaUserData: unknown): Promise<string> {
  const raw = remnaUserData as { response?: { activeInternalSquads?: unknown[] }; activeInternalSquads?: unknown[] };
  const user = raw?.response ?? raw;
  const ais = user?.activeInternalSquads;
  const squadUuids: string[] = [];
  if (Array.isArray(ais)) {
    for (const s of ais) {
      const u = s != null && typeof s === "object" && "uuid" in s ? (s as { uuid: unknown }).uuid : s;
      if (typeof u === "string") squadUuids.push(u);
    }
  }
  if (squadUuids.length === 0) return "Тариф не выбран";
  const config = await getSystemConfig();
  const trialUuid = config.trialSquadUuid?.trim() || null;
  const tariffs = await prisma.tariff.findMany({ select: { name: true, internalSquadUuids: true } });
  for (const squadUuid of squadUuids) {
    if (trialUuid === squadUuid) continue;
    const match = tariffs.find((t) => t.internalSquadUuids.includes(squadUuid));
    if (match?.name) return match.name;
  }
  if (trialUuid && squadUuids.includes(trialUuid)) return "Тест";
  return "Тариф не выбран";
}

clientRouter.get("/proxy-slots", async (req, res) => {
  const client = (req as unknown as { client: { id: string } }).client;
  const now = new Date();
  const slots = await prisma.proxySlot.findMany({
    where: { clientId: client.id, status: "ACTIVE", expiresAt: { gt: now } },
    select: {
      id: true,
      login: true,
      password: true,
      expiresAt: true,
      trafficLimitBytes: true,
      trafficUsedBytes: true,
      connectionLimit: true,
      node: { select: { publicHost: true, socksPort: true, httpPort: true } },
    },
    orderBy: { expiresAt: "asc" },
  });
  return res.json({
    slots: slots.map((s) => ({
      id: s.id,
      login: s.login,
      password: s.password,
      expiresAt: s.expiresAt.toISOString(),
      trafficLimitBytes: s.trafficLimitBytes?.toString() ?? null,
      trafficUsedBytes: s.trafficUsedBytes.toString(),
      connectionLimit: s.connectionLimit,
      host: s.node.publicHost ?? "host",
      socksPort: s.node.socksPort,
      httpPort: s.node.httpPort,
    })),
  });
});

clientRouter.get("/singbox-slots", async (req, res) => {
  const client = (req as unknown as { client: { id: string } }).client;
  const now = new Date();
  const slots = await prisma.singboxSlot.findMany({
    where: { clientId: client.id, status: "ACTIVE", expiresAt: { gt: now } },
    select: {
      id: true,
      userIdentifier: true,
      secret: true,
      expiresAt: true,
      trafficLimitBytes: true,
      trafficUsedBytes: true,
      node: { select: { publicHost: true, port: true, protocol: true, tlsEnabled: true } },
    },
    orderBy: { expiresAt: "asc" },
  });
  return res.json({
    slots: slots.map((s) => {
      const link = buildSingboxSlotSubscriptionLink(
        {
          publicHost: s.node.publicHost ?? "",
          port: s.node.port ?? 443,
          protocol: s.node.protocol ?? "VLESS",
          tlsEnabled: s.node.tlsEnabled,
        },
        { userIdentifier: s.userIdentifier, secret: s.secret },
        `slot-${s.id.slice(-8)}`
      );
      return {
        id: s.id,
        subscriptionLink: link,
        expiresAt: s.expiresAt.toISOString(),
        trafficLimitBytes: s.trafficLimitBytes?.toString() ?? null,
        trafficUsedBytes: s.trafficUsedBytes.toString(),
        protocol: s.node.protocol ?? "VLESS",
      };
    }),
  });
});

clientRouter.get("/subscription", async (req, res) => {
  const client = (req as unknown as { client: { id: string; remnawaveUuid: string | null } }).client;
  if (!client.remnawaveUuid) {
    return res.json({ subscription: null, tariffDisplayName: null, message: "Подписка не привязана" });
  }
  const result = await remnaGetUser(client.remnawaveUuid);
  if (result.error) {
    return res.json({ subscription: null, tariffDisplayName: null, message: result.error });
  }
  let tariffDisplayName = await resolveTariffDisplayName(result.data ?? null);
  // Если по Remna показывается «Триал» или «Тариф не выбран», но клиент оплачивал тариф — берём название из последней оплаты
  if (tariffDisplayName === "Тест" || tariffDisplayName === "Тариф не выбран") {
    const lastPaidTariff = await prisma.payment.findFirst({
      where: { clientId: client.id, status: "PAID", tariffId: { not: null } },
      orderBy: { paidAt: "desc" },
      select: { tariff: { select: { name: true } } },
    });
    const name = lastPaidTariff?.tariff?.name?.trim();
    if (name) tariffDisplayName = name;
  }
  return res.json({ subscription: result.data ?? null, tariffDisplayName });
});

/**
 * GET /api/client/subscription/by-uuid/:uuid — Подписка по Remnawave UUID.
 * Используется на /cabinet/subscribe?uuid=xxx для secondary подписок.
 */
clientRouter.get("/subscription/by-uuid/:uuid", async (req, res) => {
  const client = (req as unknown as { client: { id: string; remnawaveUuid: string | null } }).client;
  const clientId = (req as unknown as { clientId: string }).clientId;
  const { uuid } = req.params;
  if (!uuid || typeof uuid !== "string") {
    return res.status(400).json({ subscription: null, tariffDisplayName: null, message: "UUID не указан" });
  }

  // Проверяем принадлежность: root или secondary подписка
  const isRoot = client.remnawaveUuid === uuid;
  if (!isRoot) {
    const secondarySub = await prisma.secondarySubscription.findFirst({
      where: { ownerId: clientId, remnawaveUuid: uuid },
    });
    if (!secondarySub) {
      return res.status(404).json({ subscription: null, tariffDisplayName: null, message: "Подписка не найдена" });
    }
  }

  const result = await remnaGetUser(uuid);
  if (result.error) {
    return res.json({ subscription: null, tariffDisplayName: null, message: result.error });
  }
  const tariffDisplayName = await resolveTariffDisplayName(result.data ?? null);
  return res.json({ subscription: result.data ?? null, tariffDisplayName });
});

/**
 * GET /api/client/subscription/all — Все подписки клиента (root + secondary).
 * Возвращает массив с Remnawave-данными для каждой подписки.
 */
clientRouter.get("/subscription/all", async (req, res) => {
  const client = (req as unknown as { client: { id: string; remnawaveUuid: string | null } }).client;
  const clientId = (req as unknown as { clientId: string }).clientId;

  type SubInfo = {
    type: "root" | "secondary";
    id: string;
    subscriptionIndex: number | null;
    subscription: unknown;
    tariffDisplayName: string;
    remnawaveUuid: string | null;
  };

  const items: SubInfo[] = [];

  // 1. Root подписка
  if (client.remnawaveUuid) {
    const rootResult = await remnaGetUser(client.remnawaveUuid);
    let rootTariff = await resolveTariffDisplayName(rootResult.data ?? null);
    if (rootTariff === "Тест" || rootTariff === "Тариф не выбран") {
      const lastPaidTariff = await prisma.payment.findFirst({
        where: { clientId, status: "PAID", tariffId: { not: null } },
        orderBy: { paidAt: "desc" },
        select: { tariff: { select: { name: true } } },
      });
      const name = lastPaidTariff?.tariff?.name?.trim();
      if (name) rootTariff = name;
    }
    items.push({
      type: "root",
      id: clientId,
      subscriptionIndex: 0,
      subscription: rootResult.data ?? null,
      tariffDisplayName: rootTariff,
      remnawaveUuid: client.remnawaveUuid,
    });
  }

  // 2. Secondary подписки:
  // - свои обычные (ownerId + giftStatus null)
  // - активированные на себя (ownerId + giftStatus ACTIVATED_SELF)
  // - полученные в подарок (giftedToClientId + giftStatus GIFTED)
  const secondaries = await prisma.secondarySubscription.findMany({
    where: {
      OR: [
        { ownerId: clientId, giftStatus: null },
        { ownerId: clientId, giftStatus: "" },
        { ownerId: clientId, giftStatus: "ACTIVATED_SELF" },
        { giftedToClientId: clientId, giftStatus: "GIFTED" },
      ],
    },
    select: { id: true, remnawaveUuid: true, subscriptionIndex: true },
    orderBy: { subscriptionIndex: "asc" },
  });

  for (const sec of secondaries) {
    if (!sec.remnawaveUuid) continue;
    const secResult = await remnaGetUser(sec.remnawaveUuid);
    const secTariff = await resolveTariffDisplayName(secResult.data ?? null);
    items.push({
      type: "secondary",
      id: sec.id,
      subscriptionIndex: sec.subscriptionIndex,
      subscription: secResult.data ?? null,
      tariffDisplayName: secTariff,
      remnawaveUuid: sec.remnawaveUuid,
    });
  }

  return res.json({ items });
});

/** GET /api/client/devices — список устройств (HWID) пользователя в Remna */
clientRouter.get("/devices", async (req, res) => {
  const client = (req as unknown as { client: { id: string; remnawaveUuid: string | null } }).client;
  if (!client.remnawaveUuid) {
    return res.json({ total: 0, devices: [] });
  }
  const result = await remnaGetUserHwidDevices(client.remnawaveUuid);
  if (result.error) {
    return res.status(result.status >= 500 ? 503 : 400).json({ message: result.error });
  }
  const data = result.data as { response?: { total?: number; devices?: Array<{ hwid: string; platform?: string; deviceModel?: string; createdAt?: string }> } } | undefined;
  const resp = data?.response;
  const devices = Array.isArray(resp?.devices) ? resp.devices : [];
  const total = typeof resp?.total === "number" ? resp.total : devices.length;
  return res.json({ total, devices });
});

const deleteDeviceSchema = z.object({ hwid: z.string().min(1).max(500) });

/** POST /api/client/devices/delete — удалить устройство по HWID */
clientRouter.post("/devices/delete", async (req, res) => {
  const client = (req as unknown as { client: { id: string; remnawaveUuid: string | null } }).client;
  if (!client.remnawaveUuid) {
    return res.status(400).json({ message: "Подписка не привязана" });
  }
  const body = deleteDeviceSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });
  const result = await remnaDeleteUserHwidDevice(client.remnawaveUuid, body.data.hwid);
  if (result.error) {
    return res.status(result.status >= 500 ? 503 : 400).json({ message: result.error });
  }
  return res.json({ ok: true, message: "Устройство удалено" });
});

const createPlategaPaymentSchema = z.object({
  amount: z.number().positive().optional(),
  currency: z.string().min(1).max(10).optional(),
  paymentMethod: z.number().int().min(2).max(13),
  description: z.string().max(500).optional(),
  tariffId: z.string().min(1).optional(),
  proxyTariffId: z.string().min(1).optional(),
  singboxTariffId: z.string().min(1).optional(),
  promoCode: z.string().max(50).optional(),
  extraOption: z.object({ kind: z.enum(["traffic", "devices", "servers"]), productId: z.string().min(1) }).optional(),
  customBuild: z.object({ days: z.number().int().min(1).max(360), devices: z.number().int().min(1).max(20), trafficGb: z.number().min(0).nullable().optional() }).optional(),
});
clientRouter.post("/payments/platega", async (req, res) => {
  const clientId = (req as unknown as { clientId: string }).clientId;
  const parsed = createPlategaPaymentSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ message: "Invalid input", errors: parsed.error.flatten() });
  }
  const { amount: originalAmount, currency, paymentMethod, description, tariffId, proxyTariffId, singboxTariffId, promoCode: promoCodeStr, extraOption, customBuild: customBuildBody } = parsed.data;

  let tariffIdToStore: string | null = null;
  let proxyTariffIdToStore: string | null = null;
  let singboxTariffIdToStore: string | null = null;
  let finalAmount: number;
  let currencyToUse: string;
  let metadataExtra: Record<string, unknown> | null = null;

  if (customBuildBody) {
    const configForCb = await getSystemConfig();
    const cfg = getCustomBuildConfig(configForCb);
    if (!cfg) return res.status(400).json({ message: "Гибкий тариф отключён" });
    let { days, devices, trafficGb } = customBuildBody;
    if (days > cfg.maxDays || devices > cfg.maxDevices) {
      return res.status(400).json({ message: `Дни: 1–${cfg.maxDays}, устройств: 1–${cfg.maxDevices}` });
    }
    const trafficLimitBytes =
      cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb >= 0
        ? Math.round(trafficGb * 1024 ** 3)
        : null;
    finalAmount = days * cfg.pricePerDay + devices * cfg.pricePerDevice;
    if (cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb > 0) finalAmount += trafficGb * cfg.pricePerGb;
    finalAmount = Math.round(finalAmount * 100) / 100;
    currencyToUse = cfg.currency.toUpperCase();
    metadataExtra = {
      customBuild: {
        durationDays: days,
        deviceLimit: devices,
        trafficLimitBytes,
        internalSquadUuids: [cfg.squadUuid],
      },
    };
  } else if (extraOption) {
    const config = await getSystemConfig();
    if (!(config as { sellOptionsEnabled?: boolean }).sellOptionsEnabled) {
      return res.status(400).json({ message: "Продажа опций отключена" });
    }
    const cfg = config as {
      sellOptionsTrafficEnabled?: boolean; sellOptionsTrafficProducts?: SellOptionTrafficProduct[];
      sellOptionsDevicesEnabled?: boolean; sellOptionsDevicesProducts?: SellOptionDeviceProduct[];
      sellOptionsServersEnabled?: boolean; sellOptionsServersProducts?: SellOptionServerProduct[];
    };
    if (extraOption.kind === "traffic") {
      const product = cfg.sellOptionsTrafficEnabled && cfg.sellOptionsTrafficProducts?.find((p) => p.id === extraOption.productId);
      if (!product) return res.status(400).json({ message: "Опция не найдена" });
      finalAmount = product.price;
      currencyToUse = product.currency.toUpperCase();
      metadataExtra = { extraOption: { kind: "traffic", trafficBytes: Math.round(product.trafficGb * 1024 ** 3) } };
    } else if (extraOption.kind === "devices") {
      const product = cfg.sellOptionsDevicesEnabled && cfg.sellOptionsDevicesProducts?.find((p) => p.id === extraOption.productId);
      if (!product) return res.status(400).json({ message: "Опция не найдена" });
      finalAmount = product.price;
      currencyToUse = product.currency.toUpperCase();
      metadataExtra = { extraOption: { kind: "devices", deviceCount: product.deviceCount } };
    } else {
      const product = cfg.sellOptionsServersEnabled && cfg.sellOptionsServersProducts?.find((p) => p.id === extraOption.productId);
      if (!product) return res.status(400).json({ message: "Опция не найдена" });
      finalAmount = product.price;
      currencyToUse = product.currency.toUpperCase();
      metadataExtra = {
        extraOption: {
          kind: "servers",
          squadUuid: product.squadUuid,
          ...((product.trafficGb ?? 0) > 0 && { trafficBytes: Math.round((product.trafficGb ?? 0) * 1024 ** 3) }),
        },
      };
    }
  } else {
    if (originalAmount == null || !currency) return res.status(400).json({ message: "Укажите сумму и валюту" });
    finalAmount = originalAmount;
    currencyToUse = currency.toUpperCase();
    if (tariffId) {
      const tariff = await prisma.tariff.findUnique({ where: { id: tariffId } });
      if (!tariff) return res.status(400).json({ message: "Тариф не найден" });
      tariffIdToStore = tariffId;
    }
    if (proxyTariffId) {
      const proxyTariff = await prisma.proxyTariff.findUnique({ where: { id: proxyTariffId } });
      if (!proxyTariff || !proxyTariff.enabled) return res.status(400).json({ message: "Прокси-тариф не найден" });
      proxyTariffIdToStore = proxyTariffId;
      if (originalAmount == null) { finalAmount = proxyTariff.price; currencyToUse = proxyTariff.currency.toUpperCase(); }
    }
    if (singboxTariffId) {
      const singboxTariff = await prisma.singboxTariff.findUnique({ where: { id: singboxTariffId } });
      if (!singboxTariff || !singboxTariff.enabled) return res.status(400).json({ message: "Тариф Sing-box не найден" });
      singboxTariffIdToStore = singboxTariffId;
      if (originalAmount == null) { finalAmount = singboxTariff.price; currencyToUse = singboxTariff.currency.toUpperCase(); }
    }
  }

  if (finalAmount < 1) {
    return res.status(400).json({ message: "Минимальная сумма платежа — 1" });
  }

  // Применяем промокод на скидку (не для опций по умолчанию, можно разрешить — тогда скидка с опции)
  let promoCodeRecord: { id: string } | null = null;
  if (promoCodeStr?.trim() && !extraOption) {
    const result = await validatePromoCode(promoCodeStr.trim(), clientId);
    if (!result.ok) return res.status(result.status).json({ message: result.error });
    const promo = result.promo;
    if (promo.type !== "DISCOUNT") return res.status(400).json({ message: "Этот промокод не даёт скидку на оплату" });

    if (promo.discountPercent && promo.discountPercent > 0) {
      finalAmount = Math.max(0, finalAmount - finalAmount * promo.discountPercent / 100);
    }
    if (promo.discountFixed && promo.discountFixed > 0) {
      finalAmount = Math.max(0, finalAmount - promo.discountFixed);
    }
    finalAmount = Math.round(finalAmount * 100) / 100;
    if (finalAmount <= 0) return res.status(400).json({ message: "Итоговая сумма не может быть 0" });
    promoCodeRecord = promo;
  }

  const config = await getSystemConfig();
  const plategaConfig = {
    merchantId: config.plategaMerchantId || "",
    secret: config.plategaSecret || "",
  };
  if (!isPlategaConfigured(plategaConfig)) {
    return res.status(503).json({ message: "Platega не настроен" });
  }

  const methods = config.plategaMethods || [];
  const allowed = methods.find((m) => m.id === paymentMethod && m.enabled);
  if (!allowed) {
    return res.status(400).json({ message: "Метод оплаты недоступен" });
  }

  const serviceName = config.serviceName?.trim() || "STEALTHNET";
  const orderId = randomUUID();
  const paymentKind = tariffIdToStore ? "tariff" : proxyTariffIdToStore ? "proxy" : singboxTariffIdToStore ? "singbox" : metadataExtra ? "option" : "topup";
  const appUrl = (config.publicAppUrl || "").replace(/\/$/, "");
  const returnUrl = appUrl
    ? `${appUrl}/cabinet/dashboard?payment=success&payment_kind=${paymentKind}&oid=${orderId}`
    : "";
  const failedUrl = appUrl
    ? `${appUrl}/cabinet/dashboard?payment=failed&payment_kind=${paymentKind}&oid=${orderId}`
    : "";
  const plategaDescription = tariffIdToStore
    ? `Тариф ${serviceName} #${orderId}`
    : proxyTariffIdToStore
      ? `Прокси ${serviceName} #${orderId}`
      : singboxTariffIdToStore
        ? `Доступы ${serviceName} #${orderId}`
        : metadataExtra
      ? `Опция ${serviceName} #${orderId}`
      : `Пополнение баланса ${serviceName} #${orderId}`;

  const paymentMeta = metadataExtra
    ? { ...metadataExtra, ...(promoCodeRecord ? { promoCodeId: promoCodeRecord.id, originalAmount: finalAmount } : {}) }
    : (promoCodeRecord ? { promoCodeId: promoCodeRecord.id, originalAmount: originalAmount ?? finalAmount } : null);
  const payment = await prisma.payment.create({
    data: {
      clientId,
      orderId,
      amount: finalAmount,
      currency: currencyToUse,
      status: "PENDING",
      provider: "platega",
      tariffId: tariffIdToStore,
      proxyTariffId: proxyTariffIdToStore,
      singboxTariffId: singboxTariffIdToStore,
      metadata: paymentMeta ? JSON.stringify(paymentMeta) : null,
    },
  });

  const result = await createPlategaTransaction(plategaConfig, {
    amount: finalAmount,
    currency: currencyToUse,
    orderId,
    paymentMethod,
    returnUrl,
    failedUrl,
    description: plategaDescription,
  });

  if ("error" in result) {
    await prisma.payment.update({ where: { id: payment.id }, data: { status: "FAILED" } });
    return res.status(502).json({ message: result.error });
  }

  await prisma.payment.update({
    where: { id: payment.id },
    data: { externalId: result.transactionId },
  });

  // Записываем использование промокода
  if (promoCodeRecord) {
    await prisma.promoCodeUsage.create({ data: { promoCodeId: promoCodeRecord.id, clientId } });
  }

  return res.status(201).json({
    paymentUrl: result.paymentUrl,
    orderId,
    paymentId: payment.id,
    discountApplied: promoCodeRecord ? true : false,
    finalAmount,
  });
});

// ——— Оплата тарифа или прокси-тарифа балансом ———

const payByBalanceSchema = z.object({
  tariffId: z.string().min(1).optional(),
  proxyTariffId: z.string().min(1).optional(),
  singboxTariffId: z.string().min(1).optional(),
  promoCode: z.string().max(50).optional(),
}).refine((d) => (d.tariffId ? 1 : 0) + (d.proxyTariffId ? 1 : 0) + (d.singboxTariffId ? 1 : 0) === 1, { message: "Укажите tariffId, proxyTariffId или singboxTariffId" });

clientRouter.post("/payments/balance", async (req, res) => {
  const clientRaw = (req as unknown as { client: { id: string; remnawaveUuid: string | null; email: string | null; telegramId: string | null } }).client;
  const parsed = payByBalanceSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid input", errors: parsed.error.flatten() });

  const { tariffId, proxyTariffId, singboxTariffId, promoCode: promoCodeStr } = parsed.data;

  if (proxyTariffId) {
    const tariff = await prisma.proxyTariff.findUnique({ where: { id: proxyTariffId } });
    if (!tariff || !tariff.enabled) return res.status(400).json({ message: "Прокси-тариф не найден" });
    const clientDb = await prisma.client.findUnique({ where: { id: clientRaw.id } });
    if (!clientDb) return res.status(401).json({ message: "Unauthorized" });
    if (clientDb.balance < tariff.price) {
      return res.status(400).json({ message: `Недостаточно средств. Баланс: ${clientDb.balance.toFixed(2)}, нужно: ${tariff.price.toFixed(2)}` });
    }
    const payment = await prisma.payment.create({
      data: {
        clientId: clientRaw.id,
        orderId: randomUUID(),
        amount: tariff.price,
        currency: tariff.currency.toUpperCase(),
        status: "PAID",
        provider: "balance",
        proxyTariffId: tariff.id,
        paidAt: new Date(),
      },
    });
    const proxyResult = await createProxySlotsByPaymentId(payment.id);
    if (!proxyResult.ok) return res.status(proxyResult.status).json({ message: proxyResult.error });
    await prisma.client.update({
      where: { id: clientRaw.id },
      data: { balance: { decrement: tariff.price } },
    });
    const { distributeReferralRewards } = await import("../referral/referral.service.js");
    await distributeReferralRewards(payment.id).catch((e) => console.error("[referral] Error:", e));
    const { notifyProxySlotsCreated } = await import("../notification/telegram-notify.service.js");
    await notifyProxySlotsCreated(clientRaw.id, proxyResult.slotIds, tariff.name).catch(() => {});
    return res.json({
      message: `Прокси «${tariff.name}» оплачены! Списано ${tariff.price.toFixed(2)} ${tariff.currency.toUpperCase()} с баланса.`,
      newBalance: clientDb.balance - tariff.price,
    });
  }

  if (singboxTariffId) {
    const tariff = await prisma.singboxTariff.findUnique({ where: { id: singboxTariffId } });
    if (!tariff || !tariff.enabled) return res.status(400).json({ message: "Тариф Sing-box не найден" });
    const clientDb = await prisma.client.findUnique({ where: { id: clientRaw.id } });
    if (!clientDb) return res.status(401).json({ message: "Unauthorized" });
    if (clientDb.balance < tariff.price) {
      return res.status(400).json({ message: `Недостаточно средств. Баланс: ${clientDb.balance.toFixed(2)}, нужно: ${tariff.price.toFixed(2)}` });
    }
    const payment = await prisma.payment.create({
      data: {
        clientId: clientRaw.id,
        orderId: randomUUID(),
        amount: tariff.price,
        currency: tariff.currency.toUpperCase(),
        status: "PAID",
        provider: "balance",
        singboxTariffId: tariff.id,
        paidAt: new Date(),
      },
    });
    const singboxResult = await createSingboxSlotsByPaymentId(payment.id);
    if (!singboxResult.ok) return res.status(singboxResult.status).json({ message: singboxResult.error });
    await prisma.client.update({
      where: { id: clientRaw.id },
      data: { balance: { decrement: tariff.price } },
    });
    const { distributeReferralRewards } = await import("../referral/referral.service.js");
    await distributeReferralRewards(payment.id).catch((e) => console.error("[referral] Error:", e));
    const { notifySingboxSlotsCreated } = await import("../notification/telegram-notify.service.js");
    await notifySingboxSlotsCreated(clientRaw.id, singboxResult.slotIds, tariff.name).catch(() => {});
    return res.json({
      message: `Доступы «${tariff.name}» оплачены! Списано ${tariff.price.toFixed(2)} ${tariff.currency.toUpperCase()} с баланса.`,
      newBalance: clientDb.balance - tariff.price,
    });
  }

  const tariff = await prisma.tariff.findUnique({ where: { id: tariffId! } });
  if (!tariff) return res.status(400).json({ message: "Тариф не найден" });

  let finalPrice = tariff.price;

  // Промокод на скидку
  let promoCodeRecord: { id: string } | null = null;
  if (promoCodeStr?.trim()) {
    const result = await validatePromoCode(promoCodeStr.trim(), clientRaw.id);
    if (!result.ok) return res.status(result.status).json({ message: result.error });
    const promo = result.promo;
    if (promo.type !== "DISCOUNT") return res.status(400).json({ message: "Этот промокод не даёт скидку на оплату" });

    if (promo.discountPercent && promo.discountPercent > 0) {
      finalPrice = Math.max(0, finalPrice - finalPrice * promo.discountPercent / 100);
    }
    if (promo.discountFixed && promo.discountFixed > 0) {
      finalPrice = Math.max(0, finalPrice - promo.discountFixed);
    }
    finalPrice = Math.round(finalPrice * 100) / 100;
    promoCodeRecord = promo;
  }

  // Проверяем баланс
  const clientDb = await prisma.client.findUnique({ where: { id: clientRaw.id } });
  if (!clientDb) return res.status(401).json({ message: "Unauthorized" });
  if (clientDb.balance < finalPrice) {
    return res.status(400).json({ message: `Недостаточно средств. Баланс: ${clientDb.balance.toFixed(2)}, нужно: ${finalPrice.toFixed(2)}` });
  }

  // Активируем тариф в Remnawave
  const activateResult = await activateTariffForClient(
    { id: clientRaw.id, remnawaveUuid: clientDb.remnawaveUuid, email: clientDb.email, telegramId: clientDb.telegramId },
    tariff,
  );
  if (!activateResult.ok) return res.status(activateResult.status).json({ message: activateResult.error });

  // Списываем баланс
  await prisma.client.update({
    where: { id: clientRaw.id },
    data: { balance: { decrement: finalPrice } },
  });

  // Создаём запись об оплате
  const orderId = randomUUID();
  const payment = await prisma.payment.create({
    data: {
      clientId: clientRaw.id,
      orderId,
      amount: finalPrice,
      currency: tariff.currency.toUpperCase(),
      status: "PAID",
      provider: "balance",
      tariffId,
      paidAt: new Date(),
      metadata: promoCodeRecord ? JSON.stringify({ promoCodeId: promoCodeRecord.id, originalPrice: tariff.price }) : null,
    },
  });

  // Записываем использование промокода
  if (promoCodeRecord) {
    await prisma.promoCodeUsage.create({ data: { promoCodeId: promoCodeRecord.id, clientId: clientRaw.id } });
  }

  // Реферальные начисления
  const { distributeReferralRewards } = await import("../referral/referral.service.js");
  await distributeReferralRewards(payment.id).catch(() => {});

  return res.json({
    message: `Тариф «${tariff.name}» активирован! Списано ${finalPrice.toFixed(2)} ${tariff.currency.toUpperCase()} с баланса.`,
    paymentId: payment.id,
    newBalance: clientDb.balance - finalPrice,
  });
});

// ——— Гибкий тариф (собери сам): расчёт и оплата балансом ———
function getCustomBuildConfig(config: Awaited<ReturnType<typeof getSystemConfig>>) {
  const c = config as {
    customBuildEnabled?: boolean;
    customBuildPricePerDay?: number;
    customBuildPricePerDevice?: number;
    customBuildTrafficMode?: string;
    customBuildPricePerGb?: number;
    customBuildSquadUuid?: string | null;
    customBuildCurrency?: string;
    customBuildMaxDays?: number;
    customBuildMaxDevices?: number;
  };
  if (!c.customBuildEnabled || !c.customBuildSquadUuid?.trim()) return null;
  return {
    pricePerDay: c.customBuildPricePerDay ?? 0,
    pricePerDevice: c.customBuildPricePerDevice ?? 0,
    trafficMode: c.customBuildTrafficMode === "per_gb" ? "per_gb" as const : "unlimited" as const,
    pricePerGb: c.customBuildPricePerGb ?? 0,
    squadUuid: c.customBuildSquadUuid.trim(),
    currency: (c.customBuildCurrency || "rub").toLowerCase(),
    maxDays: Math.min(360, Math.max(1, c.customBuildMaxDays ?? 360)),
    maxDevices: Math.min(20, Math.max(1, c.customBuildMaxDevices ?? 10)),
  };
}

const customBuildPayByBalanceSchema = z.object({
  days: z.number().int().min(1).max(360),
  devices: z.number().int().min(1).max(20),
  trafficGb: z.number().min(0).nullable().optional(),
  promoCode: z.string().max(50).optional(),
});

clientRouter.post("/custom-build/pay-balance", async (req, res) => {
  const clientRaw = (req as unknown as { client: { id: string } }).client;
  const parsed = customBuildPayByBalanceSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Неверные параметры", errors: parsed.error.flatten() });

  const config = await getSystemConfig();
  const cfg = getCustomBuildConfig(config);
  if (!cfg) return res.status(400).json({ message: "Гибкий тариф отключён" });

  let { days, devices, trafficGb } = parsed.data;
  if (days > cfg.maxDays || devices > cfg.maxDevices) {
    return res.status(400).json({ message: `Дни: 1–${cfg.maxDays}, устройств: 1–${cfg.maxDevices}` });
  }
  const trafficLimitBytes =
    cfg.trafficMode === "per_gb"
      ? (trafficGb != null && trafficGb >= 0 ? BigInt(Math.round(trafficGb * 1024 ** 3)) : null)
      : null;

  let amount = days * cfg.pricePerDay + devices * cfg.pricePerDevice;
  if (cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb > 0) {
    amount += trafficGb * cfg.pricePerGb;
  }

  let finalPrice = amount;
  let promoCodeRecord: { id: string } | null = null;
  if (parsed.data.promoCode?.trim()) {
    const result = await validatePromoCode(parsed.data.promoCode.trim(), clientRaw.id);
    if (!result.ok) return res.status(result.status).json({ message: result.error });
    const promo = result.promo;
    if (promo.type !== "DISCOUNT") return res.status(400).json({ message: "Этот промокод не даёт скидку на оплату" });
    if (promo.discountPercent && promo.discountPercent > 0) {
      finalPrice = Math.max(0, finalPrice - finalPrice * promo.discountPercent / 100);
    }
    if (promo.discountFixed && promo.discountFixed > 0) {
      finalPrice = Math.max(0, finalPrice - promo.discountFixed);
    }
    finalPrice = Math.round(finalPrice * 100) / 100;
    promoCodeRecord = promo;
  }

  const clientDb = await prisma.client.findUnique({ where: { id: clientRaw.id } });
  if (!clientDb) return res.status(401).json({ message: "Unauthorized" });
  if (clientDb.balance < finalPrice) {
    return res.status(400).json({
      message: `Недостаточно средств. Баланс: ${clientDb.balance.toFixed(2)}, нужно: ${finalPrice.toFixed(2)} ${cfg.currency.toUpperCase()}`,
    });
  }

  const metadata = JSON.stringify({
    customBuild: {
      durationDays: days,
      deviceLimit: devices,
      trafficLimitBytes: trafficLimitBytes != null ? Number(trafficLimitBytes) : null,
      internalSquadUuids: [cfg.squadUuid],
    },
    ...(promoCodeRecord && { promoCodeId: promoCodeRecord.id, originalPrice: amount }),
  });

  const orderId = randomUUID();
  const payment = await prisma.payment.create({
    data: {
      clientId: clientRaw.id,
      orderId,
      amount: finalPrice,
      currency: cfg.currency.toUpperCase(),
      status: "PAID",
      provider: "balance",
      paidAt: new Date(),
      metadata,
    },
  });

  const activation = await activateTariffByPaymentId(payment.id);
  if (!activation.ok) {
    await prisma.payment.update({ where: { id: payment.id }, data: { status: "FAILED" } });
    return res.status(activation.status).json({ message: activation.error });
  }

  await prisma.client.update({
    where: { id: clientRaw.id },
    data: { balance: { decrement: finalPrice } },
  });
  if (promoCodeRecord) {
    await prisma.promoCodeUsage.create({ data: { promoCodeId: promoCodeRecord.id, clientId: clientRaw.id } });
  }
  const { distributeReferralRewards } = await import("../referral/referral.service.js");
  await distributeReferralRewards(payment.id).catch((e) => console.error("[referral] Error:", e));

  return res.json({
    message: `Подписка на ${days} дн., ${devices} ${devices === 1 ? "устройство" : "устройства"} активирована. Списано ${finalPrice.toFixed(2)} ${cfg.currency.toUpperCase()}.`,
    paymentId: payment.id,
    newBalance: clientDb.balance - finalPrice,
  });
});

// ——— Оплата опции (доп. трафик/устройства/сервер) балансом ———
const payOptionByBalanceSchema = z.object({
  extraOption: z.object({ kind: z.enum(["traffic", "devices", "servers"]), productId: z.string().min(1) }),
});
clientRouter.post("/payments/balance/option", async (req, res) => {
  const clientRaw = (req as unknown as { clientId: string }).clientId;
  const parsed = payOptionByBalanceSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid input", errors: parsed.error.flatten() });

  const config = await getSystemConfig();
  if (!(config as { sellOptionsEnabled?: boolean }).sellOptionsEnabled) {
    return res.status(400).json({ message: "Продажа опций отключена" });
  }

  const cfg = config as {
    sellOptionsTrafficEnabled?: boolean; sellOptionsTrafficProducts?: SellOptionTrafficProduct[];
    sellOptionsDevicesEnabled?: boolean; sellOptionsDevicesProducts?: SellOptionDeviceProduct[];
    sellOptionsServersEnabled?: boolean; sellOptionsServersProducts?: SellOptionServerProduct[];
  };
  const { kind, productId } = parsed.data.extraOption;
  let price: number;
  let currency: string;
  let metadataExtra: Record<string, unknown>;

  if (kind === "traffic") {
    const product = cfg.sellOptionsTrafficEnabled && cfg.sellOptionsTrafficProducts?.find((p) => p.id === productId);
    if (!product) return res.status(400).json({ message: "Опция не найдена" });
    price = product.price;
    currency = product.currency;
    metadataExtra = { extraOption: { kind: "traffic", trafficBytes: Math.round(product.trafficGb * 1024 ** 3) } };
  } else if (kind === "devices") {
    const product = cfg.sellOptionsDevicesEnabled && cfg.sellOptionsDevicesProducts?.find((p) => p.id === productId);
    if (!product) return res.status(400).json({ message: "Опция не найдена" });
    price = product.price;
    currency = product.currency;
    metadataExtra = { extraOption: { kind: "devices", deviceCount: product.deviceCount } };
  } else {
    const product = cfg.sellOptionsServersEnabled && cfg.sellOptionsServersProducts?.find((p) => p.id === productId);
    if (!product) return res.status(400).json({ message: "Опция не найдена" });
    price = product.price;
    currency = product.currency;
    metadataExtra = {
        extraOption: {
          kind: "servers",
          squadUuid: product.squadUuid,
          ...((product.trafficGb ?? 0) > 0 && { trafficBytes: Math.round((product.trafficGb ?? 0) * 1024 ** 3) }),
        },
      };
  }

  const clientDb = await prisma.client.findUnique({ where: { id: clientRaw } });
  if (!clientDb) return res.status(401).json({ message: "Unauthorized" });
  if (clientDb.balance < price) {
    return res.status(400).json({ message: `Недостаточно средств. Баланс: ${clientDb.balance.toFixed(2)}, нужно: ${price.toFixed(2)}` });
  }

  const orderId = randomUUID();
  const payment = await prisma.payment.create({
    data: {
      clientId: clientDb.id,
      orderId,
      amount: price,
      currency: currency.toUpperCase(),
      status: "PAID",
      provider: "balance",
      paidAt: new Date(),
      metadata: JSON.stringify(metadataExtra),
    },
  });

  const applyResult = await applyExtraOptionByPaymentId(payment.id);
  if (!applyResult.ok) {
    await prisma.payment.update({ where: { id: payment.id }, data: { status: "FAILED" } });
    return res.status(applyResult.status).json({ message: (applyResult as { error?: string }).error || "Ошибка применения опции" });
  }

  await prisma.client.update({
    where: { id: clientDb.id },
    data: { balance: { decrement: price } },
  });

  const { distributeReferralRewards } = await import("../referral/referral.service.js");
  await distributeReferralRewards(payment.id).catch(() => {});

  const newBalance = clientDb.balance - price;
  return res.json({
    message: "Опция применена. Списано с баланса.",
    paymentId: payment.id,
    newBalance,
  });
});

// ——— ЮMoney: пополнение баланса ———

clientRouter.get("/yoomoney/auth-url", async (req, res) => {
  const clientId = (req as unknown as { clientId: string }).clientId;
  const config = await getSystemConfig();
  const appUrl = (config.publicAppUrl || "").replace(/\/$/, "");
  if (!config.yoomoneyClientId?.trim() || !appUrl) {
    return res.status(503).json({ message: "ЮMoney не настроен или не указан URL приложения" });
  }
  const redirectUri = `${appUrl}/api/client/yoomoney/callback`;
  const state = yoomoneyStateSign(clientId);
  const url = getAuthUrl({ clientId: config.yoomoneyClientId, redirectUri, state });
  return res.json({ url });
});

const yoomoneyRequestTopupSchema = z.object({ amount: z.number().positive().max(1e7) });
clientRouter.post("/yoomoney/request-topup", async (req, res) => {
  const client = (req as unknown as { client: { id: string; yoomoneyAccessToken?: string | null } }).client;
  const parsed = yoomoneyRequestTopupSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Укажите сумму", errors: parsed.error.flatten() });
  const { amount } = parsed.data;
  if (!client.yoomoneyAccessToken?.trim()) {
    return res.status(400).json({ message: "Сначала подключите кошелёк ЮMoney" });
  }
  const config = await getSystemConfig();
  const receiver = config.yoomoneyReceiverWallet?.trim();
  if (!receiver) return res.status(503).json({ message: "ЮMoney не настроен" });

  const serviceName = config.serviceName?.trim() || "STEALTHNET";
  const amountRounded = Math.round(amount * 100) / 100;
  const orderId = randomUUID();
  const payment = await prisma.payment.create({
    data: {
      clientId: client.id,
      orderId,
      amount: amountRounded,
      currency: "RUB",
      status: "PENDING",
      provider: "yoomoney",
      metadata: JSON.stringify({ type: "balance_topup" }),
    },
  });

  const result = await requestPayment(client.yoomoneyAccessToken, {
    to: receiver,
    amount_due: amountRounded,
    label: payment.id,
    message: `Пополнение баланса ${serviceName}. Заказ ${orderId}`,
    comment: `Пополнение баланса`,
  });

  if (result.status === "refused") {
    await prisma.payment.update({ where: { id: payment.id }, data: { status: "FAILED" } });
    return res.status(400).json({ message: result.error_description ?? result.error });
  }

  await prisma.payment.update({
    where: { id: payment.id },
    data: { metadata: JSON.stringify({ type: "balance_topup", request_id: result.request_id }) },
  });

  return res.json({
    paymentId: payment.id,
    request_id: result.request_id,
    money_source: result.money_source,
    contract_amount: result.contract_amount,
  });
});

const yoomoneyProcessPaymentSchema = z.object({
  paymentId: z.string().min(1),
  request_id: z.string().min(1),
  money_source: z.string().optional(),
  csc: z.string().max(10).optional(),
});
clientRouter.post("/yoomoney/process-payment", async (req, res) => {
  const client = (req as unknown as { client: { id: string; yoomoneyAccessToken?: string | null } }).client;
  const parsed = yoomoneyProcessPaymentSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Неверные параметры", errors: parsed.error.flatten() });
  const { paymentId, request_id, money_source, csc } = parsed.data;

  const payment = await prisma.payment.findFirst({
    where: { id: paymentId, clientId: client.id, status: "PENDING", provider: "yoomoney" },
  });
  if (!payment) return res.status(404).json({ message: "Платёж не найден или уже обработан" });
  if (!client.yoomoneyAccessToken?.trim()) return res.status(400).json({ message: "Кошелёк ЮMoney не подключён" });

  const result = await processPayment(client.yoomoneyAccessToken, { request_id, money_source, csc });

  if (result.status === "in_progress") {
    return res.status(202).json({ status: "in_progress", message: "Платёж обрабатывается, повторите запрос через минуту" });
  }
  if (result.status === "ext_auth_required") {
    return res.status(200).json({ status: "ext_auth_required", acs_uri: result.acs_uri, acs_params: result.acs_params });
  }
  if (result.status === "refused") {
    return res.status(400).json({ message: result.error });
  }

  await prisma.payment.update({
    where: { id: payment.id },
    data: { status: "PAID", paidAt: new Date(), externalId: result.payment_id ?? undefined },
  });
  const updated = await prisma.client.update({
    where: { id: client.id },
    data: { balance: { increment: payment.amount } },
    select: { balance: true },
  });

  const { distributeReferralRewards } = await import("../referral/referral.service.js");
  await distributeReferralRewards(payment.id).catch((e) => console.error("[referral] yoomoney process-payment:", e));

  return res.json({ message: "Баланс пополнен", newBalance: updated.balance });
});

// ——— ЮMoney: форма перевода (оплата картой). Пополнение баланса, тариф или опция ———
const yoomoneyFormPaymentSchema = z.object({
  amount: z.number().positive().max(1e7).optional(),
  paymentType: z.enum(["PC", "AC"]), // PC = с кошелька, AC = с карты
  tariffId: z.string().min(1).optional(),
  proxyTariffId: z.string().min(1).optional(),
  singboxTariffId: z.string().min(1).optional(),
  promoCode: z.string().max(50).optional(),
  extraOption: z.object({ kind: z.enum(["traffic", "devices", "servers"]), productId: z.string().min(1) }).optional(),
  customBuild: z.object({ days: z.number().int().min(1).max(360), devices: z.number().int().min(1).max(20), trafficGb: z.number().min(0).nullable().optional() }).optional(),
});
clientRouter.post("/yoomoney/create-form-payment", async (req, res) => {
  const clientId = (req as unknown as { clientId: string }).clientId;
  const parsed = yoomoneyFormPaymentSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Укажите сумму и способ оплаты", errors: parsed.error.flatten() });
  const { amount: amountBody, paymentType, tariffId: tariffIdBody, proxyTariffId: proxyTariffIdBody, singboxTariffId: singboxTariffIdBody, promoCode: promoCodeStr, extraOption, customBuild: customBuildBody } = parsed.data;
  const config = await getSystemConfig();
  const receiver = config.yoomoneyReceiverWallet?.trim();
  if (!receiver) return res.status(503).json({ message: "ЮMoney не настроен" });

  let tariffIdToStore: string | null = null;
  let proxyTariffIdToStore: string | null = null;
  let singboxTariffIdToStore: string | null = null;
  let amountRounded: number;
  let metadataObj: Record<string, unknown> = { paymentType };
  let yoomoneyPromoRecord: PromoCodeRow | null = null;
  let yoomoneyOriginalAmount: number | null = null;

  if (customBuildBody) {
    const cfg = getCustomBuildConfig(config);
    if (!cfg) return res.status(400).json({ message: "Гибкий тариф отключён" });
    let { days, devices, trafficGb } = customBuildBody;
    if (days > cfg.maxDays || devices > cfg.maxDevices) {
      return res.status(400).json({ message: `Дни: 1–${cfg.maxDays}, устройств: 1–${cfg.maxDevices}` });
    }
    const trafficLimitBytes =
      cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb >= 0
        ? Math.round(trafficGb * 1024 ** 3)
        : null;
    amountRounded = days * cfg.pricePerDay + devices * cfg.pricePerDevice;
    if (cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb > 0) amountRounded += trafficGb * cfg.pricePerGb;
    amountRounded = Math.round(amountRounded * 100) / 100;
    metadataObj = {
      paymentType,
      customBuild: {
        durationDays: days,
        deviceLimit: devices,
        trafficLimitBytes,
        internalSquadUuids: [cfg.squadUuid],
      },
    };
  } else if (extraOption) {
    if (!(config as { sellOptionsEnabled?: boolean }).sellOptionsEnabled) {
      return res.status(400).json({ message: "Продажа опций отключена" });
    }
    const cfg = config as {
      sellOptionsTrafficEnabled?: boolean; sellOptionsTrafficProducts?: SellOptionTrafficProduct[];
      sellOptionsDevicesEnabled?: boolean; sellOptionsDevicesProducts?: SellOptionDeviceProduct[];
      sellOptionsServersEnabled?: boolean; sellOptionsServersProducts?: SellOptionServerProduct[];
    };
    if (extraOption.kind === "traffic") {
      const product = cfg.sellOptionsTrafficEnabled && cfg.sellOptionsTrafficProducts?.find((p) => p.id === extraOption.productId);
      if (!product) return res.status(400).json({ message: "Опция не найдена" });
      amountRounded = Math.round(product.price * 100) / 100;
      metadataObj = { paymentType, extraOption: { kind: "traffic", trafficBytes: Math.round(product.trafficGb * 1024 ** 3) } };
    } else if (extraOption.kind === "devices") {
      const product = cfg.sellOptionsDevicesEnabled && cfg.sellOptionsDevicesProducts?.find((p) => p.id === extraOption.productId);
      if (!product) return res.status(400).json({ message: "Опция не найдена" });
      amountRounded = Math.round(product.price * 100) / 100;
      metadataObj = { paymentType, extraOption: { kind: "devices", deviceCount: product.deviceCount } };
    } else {
      const product = cfg.sellOptionsServersEnabled && cfg.sellOptionsServersProducts?.find((p) => p.id === extraOption.productId);
      if (!product) return res.status(400).json({ message: "Опция не найдена" });
      amountRounded = Math.round(product.price * 100) / 100;
      metadataObj = {
        paymentType,
        extraOption: {
          kind: "servers",
          squadUuid: product.squadUuid,
          ...((product.trafficGb ?? 0) > 0 && { trafficBytes: Math.round((product.trafficGb ?? 0) * 1024 ** 3) }),
        },
      };
    }
  } else {
    if (amountBody == null && !proxyTariffIdBody && !singboxTariffIdBody) return res.status(400).json({ message: "Укажите сумму" });
    if (tariffIdBody) {
      const tariff = await prisma.tariff.findUnique({ where: { id: tariffIdBody } });
      if (!tariff) return res.status(400).json({ message: "Тариф не найден" });
      tariffIdToStore = tariffIdBody;
      amountRounded = Math.round((amountBody ?? tariff.price) * 100) / 100;
      if (promoCodeStr?.trim()) {
        const result = await validatePromoCode(promoCodeStr.trim(), clientId);
        if (result.ok && result.promo.type === "DISCOUNT") {
          const promo = result.promo;
          yoomoneyOriginalAmount = amountRounded;
          yoomoneyPromoRecord = promo;
          if (promo.discountPercent && promo.discountPercent > 0) amountRounded = Math.max(0, amountRounded - amountRounded * promo.discountPercent / 100);
          if (promo.discountFixed && promo.discountFixed > 0) amountRounded = Math.max(0, amountRounded - promo.discountFixed);
          amountRounded = Math.round(amountRounded * 100) / 100;
        }
      }
    } else if (proxyTariffIdBody) {
      const proxyTariff = await prisma.proxyTariff.findUnique({ where: { id: proxyTariffIdBody } });
      if (!proxyTariff || !proxyTariff.enabled) return res.status(400).json({ message: "Прокси-тариф не найден" });
      proxyTariffIdToStore = proxyTariffIdBody;
      amountRounded = Math.round((amountBody ?? proxyTariff.price) * 100) / 100;
    } else if (singboxTariffIdBody) {
      const singboxTariff = await prisma.singboxTariff.findUnique({ where: { id: singboxTariffIdBody } });
      if (!singboxTariff || !singboxTariff.enabled) return res.status(400).json({ message: "Тариф Sing-box не найден" });
      singboxTariffIdToStore = singboxTariffIdBody;
      amountRounded = Math.round((amountBody ?? singboxTariff.price) * 100) / 100;
    } else {
      amountRounded = Math.round((amountBody ?? 0) * 100) / 100;
    }
  }

  if (amountRounded < 1) {
    return res.status(400).json({ message: "Минимальная сумма платежа — 1" });
  }

  if (yoomoneyPromoRecord != null && yoomoneyOriginalAmount != null) {
    metadataObj = { ...metadataObj, promoCodeId: yoomoneyPromoRecord.id, originalAmount: yoomoneyOriginalAmount };
  }

  const orderId = randomUUID();
  const payment = await prisma.payment.create({
    data: {
      clientId,
      orderId,
      amount: amountRounded,
      currency: "RUB",
      status: "PENDING",
      provider: "yoomoney_form",
      tariffId: tariffIdToStore,
      proxyTariffId: proxyTariffIdToStore,
      singboxTariffId: singboxTariffIdToStore,
      metadata: JSON.stringify(metadataObj),
    },
  });

  if (yoomoneyPromoRecord) {
    await prisma.promoCodeUsage.create({ data: { promoCodeId: yoomoneyPromoRecord.id, clientId } });
  }

  const serviceName = config.serviceName?.trim() || "STEALTHNET";
  const appUrl = (config.publicAppUrl || "").replace(/\/$/, "");
  const successURL = appUrl ? `${appUrl}/cabinet?yoomoney_form=success` : "";
  const targets = tariffIdToStore
    ? `Тариф ${serviceName} #${orderId}`
    : proxyTariffIdToStore
      ? `Прокси ${serviceName} #${orderId}`
      : singboxTariffIdToStore
        ? `Доступы ${serviceName} #${orderId}`
        : customBuildBody
          ? `Гибкий тариф ${serviceName} #${orderId}`
          : extraOption
            ? `Опция ${serviceName} #${orderId}`
            : `Пополнение баланса ${serviceName} #${orderId}`;
  const params = new URLSearchParams({
    receiver,
    "quickpay-form": "shop",
    targets,
    sum: String(amountRounded),
    paymentType,
    label: payment.id.slice(0, 64),
    successURL,
  });
  const paymentUrl = `https://yoomoney.ru/quickpay/confirm.xml?${params.toString()}`;

  return res.status(201).json({
    paymentId: payment.id,
    paymentUrl,
    form: {
      receiver,
      sum: amountRounded,
      label: payment.id,
      paymentType,
      successURL,
    },
    successURL,
  });
});

clientRouter.get("/yoomoney/form-payment/:paymentId", async (req, res) => {
  const clientId = (req as unknown as { clientId: string }).clientId;
  const paymentId = typeof req.params.paymentId === "string" ? req.params.paymentId : "";
  if (!paymentId) return res.status(400).json({ message: "paymentId required" });

  const payment = await prisma.payment.findFirst({
    where: { id: paymentId, clientId, status: "PENDING", provider: "yoomoney_form" },
    select: { id: true, amount: true, metadata: true },
  });
  if (!payment) return res.status(404).json({ message: "Платёж не найден или уже оплачен" });

  const config = await getSystemConfig();
  const receiver = config.yoomoneyReceiverWallet?.trim();
  if (!receiver) return res.status(503).json({ message: "ЮMoney не настроен" });

  let paymentType = "PC";
  try {
    const meta = payment.metadata ? JSON.parse(payment.metadata) as { paymentType?: string } : {};
    if (meta.paymentType === "AC" || meta.paymentType === "PC") paymentType = meta.paymentType;
  } catch { /* ignore */ }

  const appUrl = (config.publicAppUrl || "").replace(/\/$/, "");
  const successURL = appUrl ? `${appUrl}/cabinet?yoomoney_form=success` : "";

  return res.json({
    receiver,
    sum: payment.amount,
    label: payment.id,
    paymentType,
    successURL,
  });
});

// ——— ЮKassa API: создание платежа (тариф, пополнение или опция), редирект на confirmation_url ———
const yookassaCreatePaymentSchema = z.object({
  amount: z.number().positive().max(1e7).optional(),
  currency: z.string().min(1).max(10).optional(),
  tariffId: z.string().min(1).optional(),
  proxyTariffId: z.string().min(1).optional(),
  singboxTariffId: z.string().min(1).optional(),
  promoCode: z.string().optional(),
  extraOption: z.object({
    kind: z.enum(["traffic", "devices", "servers"]),
    productId: z.string().min(1),
  }).optional(),
  customBuild: z.object({
    days: z.number().int().min(1).max(360),
    devices: z.number().int().min(1).max(20),
    trafficGb: z.number().min(0).nullable().optional(),
  }).optional(),
});
clientRouter.post("/yookassa/create-payment", async (req, res) => {
  try {
    const clientId = (req as unknown as { clientId: string }).clientId;
    const parsed = yookassaCreatePaymentSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные параметры", errors: parsed.error.flatten() });
    const { amount: amountBody, currency: currencyBody, tariffId: tariffIdBody, proxyTariffId: proxyTariffIdBody, singboxTariffId: singboxTariffIdBody, promoCode, extraOption, customBuild: customBuildBody } = parsed.data;
    const config = await getSystemConfig();
    const shopId = config.yookassaShopId?.trim();
    const secretKey = config.yookassaSecretKey?.trim();
    if (!shopId || !secretKey) return res.status(503).json({ message: "ЮKassa не настроена" });

    let amountRounded: number;
    let currencyUpper: string;
    let tariffIdToStore: string | null = null;
    let proxyTariffIdToStore: string | null = null;
    let singboxTariffIdToStore: string | null = null;
    let metadataObj: Record<string, unknown> = promoCode ? { promoCode } : {};

    if (customBuildBody) {
      const cfg = getCustomBuildConfig(config);
      if (!cfg) return res.status(400).json({ message: "Гибкий тариф отключён" });
      let { days, devices, trafficGb } = customBuildBody;
      if (days > cfg.maxDays || devices > cfg.maxDevices) {
        return res.status(400).json({ message: `Дни: 1–${cfg.maxDays}, устройств: 1–${cfg.maxDevices}` });
      }
      const trafficLimitBytes =
        cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb >= 0
          ? Math.round(trafficGb * 1024 ** 3)
          : null;
      amountRounded = days * cfg.pricePerDay + devices * cfg.pricePerDevice;
      if (cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb > 0) amountRounded += trafficGb * cfg.pricePerGb;
      amountRounded = Math.round(amountRounded * 100) / 100;
      currencyUpper = cfg.currency.toUpperCase();
      metadataObj = {
        customBuild: {
          durationDays: days,
          deviceLimit: devices,
          trafficLimitBytes,
          internalSquadUuids: [cfg.squadUuid],
        },
      };
      if (currencyUpper !== "RUB") return res.status(400).json({ message: "ЮKassa принимает только рубли (RUB)" });
    } else if (extraOption) {
      if (!(config as { sellOptionsEnabled?: boolean }).sellOptionsEnabled) {
        return res.status(400).json({ message: "Продажа опций отключена" });
      }
      const cfg = config as {
        sellOptionsTrafficEnabled?: boolean;
        sellOptionsTrafficProducts?: SellOptionTrafficProduct[];
        sellOptionsDevicesEnabled?: boolean;
        sellOptionsDevicesProducts?: SellOptionDeviceProduct[];
        sellOptionsServersEnabled?: boolean;
        sellOptionsServersProducts?: SellOptionServerProduct[];
      };
      if (extraOption.kind === "traffic") {
        const product = cfg.sellOptionsTrafficEnabled && cfg.sellOptionsTrafficProducts?.find((p) => p.id === extraOption.productId);
        if (!product) return res.status(400).json({ message: "Опция не найдена" });
        amountRounded = Math.round(product.price * 100) / 100;
        currencyUpper = product.currency.toUpperCase();
        metadataObj = { extraOption: { kind: "traffic", trafficBytes: Math.round(product.trafficGb * 1024 ** 3) } };
      } else if (extraOption.kind === "devices") {
        const product = cfg.sellOptionsDevicesEnabled && cfg.sellOptionsDevicesProducts?.find((p) => p.id === extraOption.productId);
        if (!product) return res.status(400).json({ message: "Опция не найдена" });
        amountRounded = Math.round(product.price * 100) / 100;
        currencyUpper = product.currency.toUpperCase();
        metadataObj = { extraOption: { kind: "devices", deviceCount: product.deviceCount } };
      } else {
        const product = cfg.sellOptionsServersEnabled && cfg.sellOptionsServersProducts?.find((p) => p.id === extraOption.productId);
        if (!product) return res.status(400).json({ message: "Опция не найдена" });
        amountRounded = Math.round(product.price * 100) / 100;
        currencyUpper = product.currency.toUpperCase();
        metadataObj = {
        extraOption: {
          kind: "servers",
          squadUuid: product.squadUuid,
          ...((product.trafficGb ?? 0) > 0 && { trafficBytes: Math.round((product.trafficGb ?? 0) * 1024 ** 3) }),
        },
      };
      }
      if (currencyUpper !== "RUB") return res.status(400).json({ message: "ЮKassa принимает только рубли (RUB)" });
    } else {
      currencyUpper = (currencyBody ?? "RUB").toUpperCase();
      if (currencyUpper !== "RUB") return res.status(400).json({ message: "ЮKassa принимает только рубли (RUB)" });
      if (tariffIdBody) {
        const tariff = await prisma.tariff.findUnique({ where: { id: tariffIdBody } });
        if (!tariff) return res.status(400).json({ message: "Тариф не найден" });
        tariffIdToStore = tariffIdBody;
        amountRounded = Math.round((amountBody ?? tariff.price) * 100) / 100;
      } else if (proxyTariffIdBody) {
        const proxyTariff = await prisma.proxyTariff.findUnique({ where: { id: proxyTariffIdBody } });
        if (!proxyTariff || !proxyTariff.enabled) return res.status(400).json({ message: "Прокси-тариф не найден" });
        proxyTariffIdToStore = proxyTariffIdBody;
        amountRounded = Math.round((amountBody ?? proxyTariff.price) * 100) / 100;
      } else if (singboxTariffIdBody) {
        const singboxTariff = await prisma.singboxTariff.findUnique({ where: { id: singboxTariffIdBody } });
        if (!singboxTariff || !singboxTariff.enabled) return res.status(400).json({ message: "Тариф Sing-box не найден" });
        singboxTariffIdToStore = singboxTariffIdBody;
        amountRounded = Math.round((amountBody ?? singboxTariff.price) * 100) / 100;
    } else {
      if (amountBody == null) return res.status(400).json({ message: "Укажите сумму" });
      amountRounded = Math.round(amountBody * 100) / 100;
    }
  }

    if (amountRounded < 1) {
      return res.status(400).json({ message: "Минимальная сумма платежа — 1" });
    }

    // Применяем промокод на скидку (не для опций и гибких тарифов)
    let promoCodeRecord: { id: string } | null = null;
    if (promoCode?.trim() && !extraOption && !customBuildBody) {
      const result = await validatePromoCode(promoCode.trim(), clientId);
      if (!result.ok) return res.status(result.status).json({ message: result.error });
      const promo = result.promo;
      if (promo.type !== "DISCOUNT") return res.status(400).json({ message: "Этот промокод не даёт скидку на оплату" });
      const originalAmount = amountRounded;
      if (promo.discountPercent && promo.discountPercent > 0) {
        amountRounded = Math.max(0, amountRounded - amountRounded * promo.discountPercent / 100);
      }
      if (promo.discountFixed && promo.discountFixed > 0) {
        amountRounded = Math.max(0, amountRounded - promo.discountFixed);
      }
      amountRounded = Math.round(amountRounded * 100) / 100;
      if (amountRounded <= 0) return res.status(400).json({ message: "Итоговая сумма не может быть 0" });
      promoCodeRecord = promo;
      metadataObj = { ...metadataObj, promoCodeId: promo.id, originalAmount };
    }

    const client = await prisma.client.findUnique({
      where: { id: clientId },
      select: { email: true },
    });
    const customerEmail = client?.email?.trim() || null;

    const orderId = randomUUID();
    const payment = await prisma.payment.create({
      data: {
        clientId,
        orderId,
        amount: amountRounded,
        currency: currencyUpper,
        status: "PENDING",
        provider: "yookassa",
        tariffId: tariffIdToStore,
        proxyTariffId: proxyTariffIdToStore,
        singboxTariffId: singboxTariffIdToStore,
        metadata: Object.keys(metadataObj).length > 0 ? JSON.stringify(metadataObj) : null,
      },
    });

    const serviceName = config.serviceName?.trim() || "STEALTHNET";
    const appUrl = (config.publicAppUrl || "").replace(/\/$/, "");
    const returnUrl = appUrl ? `${appUrl}/cabinet?yookassa=success` : "";
    const description = tariffIdToStore
      ? `Тариф ${serviceName} #${orderId}`
      : proxyTariffIdToStore
        ? `Прокси ${serviceName} #${orderId}`
        : singboxTariffIdToStore
          ? `Доступы ${serviceName} #${orderId}`
        : extraOption
          ? `Опция ${serviceName} #${orderId}`
          : `Пополнение баланса ${serviceName} #${orderId}`;

    const result = await createYookassaPayment({
      shopId,
      secretKey,
      amount: amountRounded,
      currency: currencyUpper,
      returnUrl,
      description,
      metadata: { payment_id: payment.id },
      customerEmail,
      savePaymentMethod: config.yookassaRecurringEnabled,
    });

    if (!result.ok) {
      await prisma.payment.delete({ where: { id: payment.id } }).catch(() => {});
      return res.status(500).json({ message: result.error });
    }

    // Записываем использование промокода
    if (promoCodeRecord) {
      await prisma.promoCodeUsage.create({ data: { promoCodeId: promoCodeRecord.id, clientId } });
    }

    return res.status(201).json({
      paymentId: payment.id,
      confirmationUrl: result.confirmationUrl,
      yookassaPaymentId: result.paymentId,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[yookassa/create-payment]", message, err);
    return res.status(500).json({ message: message || "Ошибка создания платежа" });
  }
});

// --- Отвязка сохранённого способа оплаты ЮKassa ---
clientRouter.post("/yookassa/unlink-payment-method", async (req, res) => {
  try {
    const clientId = (req as unknown as { clientId: string }).clientId;
    const cl = await prisma.client.findUnique({ where: { id: clientId }, select: { yookassaPaymentMethodId: true } });
    if (!cl?.yookassaPaymentMethodId) {
      return res.status(400).json({ message: "Нет привязанного способа оплаты" });
    }
    const updated = await prisma.client.update({
      where: { id: clientId },
      data: { yookassaPaymentMethodId: null, yookassaPaymentMethodTitle: null },
      select: { id: true, email: true, telegramId: true, telegramUsername: true, preferredLang: true, preferredCurrency: true, balance: true, referralCode: true, referralPercent: true, remnawaveUuid: true, trialUsed: true, isBlocked: true, autoRenewEnabled: true, autoRenewTariffId: true, yoomoneyAccessToken: true, totpEnabled: true, createdAt: true, yookassaPaymentMethodTitle: true, onboardingCompleted: true },
    });
    return res.json({ client: toClientShape(updated as Parameters<typeof toClientShape>[0]) });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[yookassa/unlink-payment-method]", message, err);
    return res.status(500).json({ message: "Ошибка отвязки способа оплаты" });
  }
});

const cryptopayCreatePaymentSchema = z.object({
  amount: z.number().positive().optional(),
  currency: z.string().min(1).max(10).optional(),
  tariffId: z.string().min(1).optional(),
  proxyTariffId: z.string().min(1).optional(),
  singboxTariffId: z.string().min(1).optional(),
  promoCode: z.string().max(50).optional(),
  extraOption: z.object({
    kind: z.enum(["traffic", "devices", "servers"]),
    productId: z.string().min(1),
  }).optional(),
  customBuild: z.object({ days: z.number().int().min(1).max(360), devices: z.number().int().min(1).max(20), trafficGb: z.number().min(0).nullable().optional() }).optional(),
});
clientRouter.post("/cryptopay/create-payment", async (req, res) => {
  try {
    const clientId = (req as unknown as { clientId: string }).clientId;
    const parsed = cryptopayCreatePaymentSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные параметры", errors: parsed.error.flatten() });
    const config = await getSystemConfig();
    const cryptopayConfig = {
      apiToken: (config as { cryptopayApiToken?: string | null }).cryptopayApiToken ?? "",
      testnet: (config as { cryptopayTestnet?: boolean }).cryptopayTestnet ?? false,
    };
    if (!isCryptopayConfigured(cryptopayConfig)) return res.status(503).json({ message: "Crypto Pay не настроен" });

    const { amount: amountBody, currency: currencyBody, tariffId: tariffIdBody, proxyTariffId: proxyTariffIdBody, singboxTariffId: singboxTariffIdBody, promoCode: promoCodeStr, extraOption, customBuild: customBuildBody } = parsed.data;
    let amountRounded: number;
    let currencyUpper: string;
    let tariffIdToStore: string | null = null;
    let proxyTariffIdToStore: string | null = null;
    let singboxTariffIdToStore: string | null = null;
    let metadataObj: Record<string, unknown> = promoCodeStr ? { promoCode: promoCodeStr } : {};

    if (customBuildBody) {
      const cfg = getCustomBuildConfig(config);
      if (!cfg) return res.status(400).json({ message: "Гибкий тариф отключён" });
      let { days, devices, trafficGb } = customBuildBody;
      if (days > cfg.maxDays || devices > cfg.maxDevices) {
        return res.status(400).json({ message: `Дни: 1–${cfg.maxDays}, устройств: 1–${cfg.maxDevices}` });
      }
      const trafficLimitBytes =
        cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb >= 0
          ? Math.round(trafficGb * 1024 ** 3)
          : null;
      amountRounded = days * cfg.pricePerDay + devices * cfg.pricePerDevice;
      if (cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb > 0) amountRounded += trafficGb * cfg.pricePerGb;
      amountRounded = Math.round(amountRounded * 100) / 100;
      currencyUpper = cfg.currency.toUpperCase();
      metadataObj = {
        customBuild: {
          durationDays: days,
          deviceLimit: devices,
          trafficLimitBytes,
          internalSquadUuids: [cfg.squadUuid],
        },
      };
    } else if (extraOption) {
      const cfg = config as { sellOptionsEnabled?: boolean; sellOptionsTrafficEnabled?: boolean; sellOptionsTrafficProducts?: SellOptionTrafficProduct[]; sellOptionsDevicesEnabled?: boolean; sellOptionsDevicesProducts?: SellOptionDeviceProduct[]; sellOptionsServersEnabled?: boolean; sellOptionsServersProducts?: SellOptionServerProduct[] };
      if (!cfg.sellOptionsEnabled) return res.status(400).json({ message: "Продажа опций отключена" });
      if (extraOption.kind === "traffic") {
        const product = cfg.sellOptionsTrafficEnabled && cfg.sellOptionsTrafficProducts?.find((p) => p.id === extraOption.productId);
        if (!product) return res.status(400).json({ message: "Опция не найдена" });
        amountRounded = Math.round(product.price * 100) / 100;
        currencyUpper = product.currency.toUpperCase();
        metadataObj = { extraOption: { kind: "traffic", trafficBytes: Math.round(product.trafficGb * 1024 ** 3) } };
      } else if (extraOption.kind === "devices") {
        const product = cfg.sellOptionsDevicesEnabled && cfg.sellOptionsDevicesProducts?.find((p) => p.id === extraOption.productId);
        if (!product) return res.status(400).json({ message: "Опция не найдена" });
        amountRounded = Math.round(product.price * 100) / 100;
        currencyUpper = product.currency.toUpperCase();
        metadataObj = { extraOption: { kind: "devices", deviceCount: product.deviceCount } };
      } else {
        const product = cfg.sellOptionsServersEnabled && cfg.sellOptionsServersProducts?.find((p) => p.id === extraOption.productId);
        if (!product) return res.status(400).json({ message: "Опция не найдена" });
        amountRounded = Math.round(product.price * 100) / 100;
        currencyUpper = product.currency.toUpperCase();
        metadataObj = { extraOption: { kind: "servers", squadUuid: product.squadUuid, ...((product.trafficGb ?? 0) > 0 && { trafficBytes: Math.round((product.trafficGb ?? 0) * 1024 ** 3) }) } };
      }
    } else {
      currencyUpper = (currencyBody ?? "USD").toUpperCase();
      if (tariffIdBody) {
        const tariff = await prisma.tariff.findUnique({ where: { id: tariffIdBody } });
        if (!tariff) return res.status(400).json({ message: "Тариф не найден" });
        tariffIdToStore = tariffIdBody;
        amountRounded = Math.round((amountBody ?? tariff.price) * 100) / 100;
      } else if (proxyTariffIdBody) {
        const proxyTariff = await prisma.proxyTariff.findUnique({ where: { id: proxyTariffIdBody } });
        if (!proxyTariff || !proxyTariff.enabled) return res.status(400).json({ message: "Прокси-тариф не найден" });
        proxyTariffIdToStore = proxyTariffIdBody;
        amountRounded = Math.round((amountBody ?? proxyTariff.price) * 100) / 100;
      } else if (singboxTariffIdBody) {
        const singboxTariff = await prisma.singboxTariff.findUnique({ where: { id: singboxTariffIdBody } });
        if (!singboxTariff || !singboxTariff.enabled) return res.status(400).json({ message: "Тариф Sing-box не найден" });
        singboxTariffIdToStore = singboxTariffIdBody;
        amountRounded = Math.round((amountBody ?? singboxTariff.price) * 100) / 100;
      } else {
        if (amountBody == null) return res.status(400).json({ message: "Укажите сумму" });
        amountRounded = Math.round(amountBody * 100) / 100;
      }
    }

    const fiatSupported = ["USD", "RUB", "EUR", "UAH", "KZT", "BYN", "UZS", "GEL", "TRY", "AMD", "THB", "INR", "CNY", "GBP", "BRL", "IDR", "AZN", "AED", "PLN", "ILS"];
    if (!fiatSupported.includes(currencyUpper)) return res.status(400).json({ message: "Crypto Pay: поддерживаются USD, RUB, EUR и др. Укажите валюту из списка." });
    if (amountRounded < 0.5) return res.status(400).json({ message: "Минимальная сумма — 0.5" });

    // Применяем промокод на скидку (не для опций и гибких тарифов)
    let promoCodeRecord: { id: string } | null = null;
    if (promoCodeStr?.trim() && !extraOption && !customBuildBody) {
      const result = await validatePromoCode(promoCodeStr.trim(), clientId);
      if (!result.ok) return res.status(result.status).json({ message: result.error });
      const promo = result.promo;
      if (promo.type !== "DISCOUNT") return res.status(400).json({ message: "Этот промокод не даёт скидку на оплату" });
      const originalAmount = amountRounded;
      if (promo.discountPercent && promo.discountPercent > 0) {
        amountRounded = Math.max(0, amountRounded - amountRounded * promo.discountPercent / 100);
      }
      if (promo.discountFixed && promo.discountFixed > 0) {
        amountRounded = Math.max(0, amountRounded - promo.discountFixed);
      }
      amountRounded = Math.round(amountRounded * 100) / 100;
      if (amountRounded <= 0) return res.status(400).json({ message: "Итоговая сумма не может быть 0" });
      promoCodeRecord = promo;
      metadataObj = { ...metadataObj, promoCodeId: promo.id, originalAmount };
    }

    const orderId = randomUUID();
    const payment = await prisma.payment.create({
      data: {
        clientId,
        orderId,
        amount: amountRounded,
        currency: currencyUpper,
        status: "PENDING",
        provider: "cryptopay",
        tariffId: tariffIdToStore,
        proxyTariffId: proxyTariffIdToStore,
        singboxTariffId: singboxTariffIdToStore,
        metadata: Object.keys(metadataObj).length > 0 ? JSON.stringify(metadataObj) : null,
      },
    });

    const serviceName = config.serviceName?.trim() || "STEALTHNET";
    const description = tariffIdToStore
      ? `Тариф ${serviceName} #${orderId}`
      : proxyTariffIdToStore
        ? `Прокси ${serviceName} #${orderId}`
        : singboxTariffIdToStore
          ? `Доступы ${serviceName} #${orderId}`
          : customBuildBody
            ? `Гибкий тариф ${serviceName} #${orderId}`
            : extraOption
              ? `Опция ${serviceName} #${orderId}`
              : `Пополнение баланса ${serviceName} #${orderId}`;

    const result = await createCryptopayInvoice({
      config: cryptopayConfig,
      amount: String(amountRounded),
      currencyType: "fiat",
      fiat: currencyUpper,
      description: description.slice(0, 1024),
      payload: payment.id,
    });

    if (!result.ok) {
      await prisma.payment.delete({ where: { id: payment.id } }).catch(() => {});
      return res.status(500).json({ message: result.error });
    }

    // Записываем использование промокода
    if (promoCodeRecord) {
      await prisma.promoCodeUsage.create({ data: { promoCodeId: promoCodeRecord.id, clientId } });
    }

    return res.status(201).json({
      paymentId: payment.id,
      payUrl: result.payUrl,
      miniAppPayUrl: result.miniAppPayUrl,
      webAppPayUrl: result.webAppPayUrl,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[cryptopay/create-payment]", message, err);
    return res.status(500).json({ message: message || "Ошибка создания платежа" });
  }
});

const heleketCreatePaymentSchema = z.object({
  amount: z.number().positive().optional(),
  currency: z.string().min(1).max(10).optional(),
  tariffId: z.string().min(1).optional(),
  proxyTariffId: z.string().min(1).optional(),
  singboxTariffId: z.string().min(1).optional(),
  promoCode: z.string().max(50).optional(),
  extraOption: z.object({
    kind: z.enum(["traffic", "devices", "servers"]),
    productId: z.string().min(1),
  }).optional(),
  customBuild: z.object({ days: z.number().int().min(1).max(360), devices: z.number().int().min(1).max(20), trafficGb: z.number().min(0).nullable().optional() }).optional(),
});
clientRouter.post("/heleket/create-payment", async (req, res) => {
  try {
    const clientId = (req as unknown as { clientId: string }).clientId;
    const parsed = heleketCreatePaymentSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ message: "Неверные параметры", errors: parsed.error.flatten() });
    const config = await getSystemConfig();
    const heleketConfig = {
      merchantId: (config as { heleketMerchantId?: string | null }).heleketMerchantId ?? "",
      apiKey: (config as { heleketApiKey?: string | null }).heleketApiKey ?? "",
    };
    if (!isHeleketConfigured(heleketConfig)) return res.status(503).json({ message: "Heleket не настроен" });

    const { amount: amountBody, currency: currencyBody, tariffId: tariffIdBody, proxyTariffId: proxyTariffIdBody, singboxTariffId: singboxTariffIdBody, promoCode: promoCodeStr, extraOption, customBuild: customBuildBody } = parsed.data;
    let amountRounded: number;
    let currencyUpper: string;
    let tariffIdToStore: string | null = null;
    let proxyTariffIdToStore: string | null = null;
    let singboxTariffIdToStore: string | null = null;
    let metadataObj: Record<string, unknown> = promoCodeStr ? { promoCode: promoCodeStr } : {};

    if (customBuildBody) {
      const cfg = getCustomBuildConfig(config);
      if (!cfg) return res.status(400).json({ message: "Гибкий тариф отключён" });
      let { days, devices, trafficGb } = customBuildBody;
      if (days > cfg.maxDays || devices > cfg.maxDevices) {
        return res.status(400).json({ message: `Дни: 1–${cfg.maxDays}, устройств: 1–${cfg.maxDevices}` });
      }
      const trafficLimitBytes =
        cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb >= 0
          ? Math.round(trafficGb * 1024 ** 3)
          : null;
      amountRounded = days * cfg.pricePerDay + devices * cfg.pricePerDevice;
      if (cfg.trafficMode === "per_gb" && trafficGb != null && trafficGb > 0) amountRounded += trafficGb * cfg.pricePerGb;
      amountRounded = Math.round(amountRounded * 100) / 100;
      currencyUpper = cfg.currency.toUpperCase();
      metadataObj = {
        customBuild: {
          durationDays: days,
          deviceLimit: devices,
          trafficLimitBytes,
          internalSquadUuids: [cfg.squadUuid],
        },
      };
    } else if (extraOption) {
      const cfg = config as { sellOptionsEnabled?: boolean; sellOptionsTrafficEnabled?: boolean; sellOptionsTrafficProducts?: SellOptionTrafficProduct[]; sellOptionsDevicesEnabled?: boolean; sellOptionsDevicesProducts?: SellOptionDeviceProduct[]; sellOptionsServersEnabled?: boolean; sellOptionsServersProducts?: SellOptionServerProduct[] };
      if (!cfg.sellOptionsEnabled) return res.status(400).json({ message: "Продажа опций отключена" });
      if (extraOption.kind === "traffic") {
        const product = cfg.sellOptionsTrafficEnabled && cfg.sellOptionsTrafficProducts?.find((p) => p.id === extraOption.productId);
        if (!product) return res.status(400).json({ message: "Опция не найдена" });
        amountRounded = Math.round(product.price * 100) / 100;
        currencyUpper = product.currency.toUpperCase();
        metadataObj = { extraOption: { kind: "traffic", trafficBytes: Math.round(product.trafficGb * 1024 ** 3) } };
      } else if (extraOption.kind === "devices") {
        const product = cfg.sellOptionsDevicesEnabled && cfg.sellOptionsDevicesProducts?.find((p) => p.id === extraOption.productId);
        if (!product) return res.status(400).json({ message: "Опция не найдена" });
        amountRounded = Math.round(product.price * 100) / 100;
        currencyUpper = product.currency.toUpperCase();
        metadataObj = { extraOption: { kind: "devices", deviceCount: product.deviceCount } };
      } else {
        const product = cfg.sellOptionsServersEnabled && cfg.sellOptionsServersProducts?.find((p) => p.id === extraOption.productId);
        if (!product) return res.status(400).json({ message: "Опция не найдена" });
        amountRounded = Math.round(product.price * 100) / 100;
        currencyUpper = product.currency.toUpperCase();
        metadataObj = { extraOption: { kind: "servers", squadUuid: product.squadUuid, ...((product.trafficGb ?? 0) > 0 && { trafficBytes: Math.round((product.trafficGb ?? 0) * 1024 ** 3) }) } };
      }
    } else {
      currencyUpper = (currencyBody ?? "USD").toUpperCase();
      if (tariffIdBody) {
        const tariff = await prisma.tariff.findUnique({ where: { id: tariffIdBody } });
        if (!tariff) return res.status(400).json({ message: "Тариф не найден" });
        tariffIdToStore = tariffIdBody;
        amountRounded = Math.round((amountBody ?? tariff.price) * 100) / 100;
      } else if (proxyTariffIdBody) {
        const proxyTariff = await prisma.proxyTariff.findUnique({ where: { id: proxyTariffIdBody } });
        if (!proxyTariff || !proxyTariff.enabled) return res.status(400).json({ message: "Прокси-тариф не найден" });
        proxyTariffIdToStore = proxyTariffIdBody;
        amountRounded = Math.round((amountBody ?? proxyTariff.price) * 100) / 100;
      } else if (singboxTariffIdBody) {
        const singboxTariff = await prisma.singboxTariff.findUnique({ where: { id: singboxTariffIdBody } });
        if (!singboxTariff || !singboxTariff.enabled) return res.status(400).json({ message: "Тариф Sing-box не найден" });
        singboxTariffIdToStore = singboxTariffIdBody;
        amountRounded = Math.round((amountBody ?? singboxTariff.price) * 100) / 100;
      } else {
        if (amountBody == null) return res.status(400).json({ message: "Укажите сумму" });
        amountRounded = Math.round(amountBody * 100) / 100;
      }
    }

    if (amountRounded < 1) return res.status(400).json({ message: "Минимальная сумма платежа — 1" });

    // Применяем промокод на скидку (не для опций и гибких тарифов)
    let promoCodeRecord: { id: string } | null = null;
    if (promoCodeStr?.trim() && !extraOption && !customBuildBody) {
      const result = await validatePromoCode(promoCodeStr.trim(), clientId);
      if (!result.ok) return res.status(result.status).json({ message: result.error });
      const promo = result.promo;
      if (promo.type !== "DISCOUNT") return res.status(400).json({ message: "Этот промокод не даёт скидку на оплату" });
      const originalAmount = amountRounded;
      if (promo.discountPercent && promo.discountPercent > 0) {
        amountRounded = Math.max(0, amountRounded - amountRounded * promo.discountPercent / 100);
      }
      if (promo.discountFixed && promo.discountFixed > 0) {
        amountRounded = Math.max(0, amountRounded - promo.discountFixed);
      }
      amountRounded = Math.round(amountRounded * 100) / 100;
      if (amountRounded <= 0) return res.status(400).json({ message: "Итоговая сумма не может быть 0" });
      promoCodeRecord = promo;
      metadataObj = { ...metadataObj, promoCodeId: promo.id, originalAmount };
    }

    const orderId = randomUUID();
    const payment = await prisma.payment.create({
      data: {
        clientId,
        orderId,
        amount: amountRounded,
        currency: currencyUpper,
        status: "PENDING",
        provider: "heleket",
        tariffId: tariffIdToStore,
        proxyTariffId: proxyTariffIdToStore,
        singboxTariffId: singboxTariffIdToStore,
        metadata: Object.keys(metadataObj).length > 0 ? JSON.stringify(metadataObj) : null,
      },
    });

    const serviceName = config.serviceName?.trim() || "STEALTHNET";
    const appUrl = (config.publicAppUrl || "").replace(/\/$/, "");
    const urlCallback = appUrl ? `${appUrl}/api/webhooks/heleket` : undefined;
    const urlSuccess = appUrl ? `${appUrl}/cabinet?heleket=success` : undefined;
    const urlReturn = appUrl ? `${appUrl}/cabinet?heleket=return` : undefined;

    const result = await createHeleketInvoice({
      config: heleketConfig,
      amount: String(amountRounded),
      currency: currencyUpper,
      orderId,
      urlCallback,
      urlSuccess,
      urlReturn,
      additionalData: payment.id,
      lifetime: 3600,
      toCurrency: "usdt",
    });

    if (!result.ok) {
      await prisma.payment.delete({ where: { id: payment.id } }).catch(() => {});
      return res.status(500).json({ message: result.error });
    }

    // Записываем использование промокода
    if (promoCodeRecord) {
      await prisma.promoCodeUsage.create({ data: { promoCodeId: promoCodeRecord.id, clientId } });
    }

    return res.status(201).json({
      paymentId: payment.id,
      payUrl: result.url,
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[heleket/create-payment]", message, err);
    return res.status(500).json({ message: message || "Ошибка создания платежа" });
  }
});

const aiChatSchema = z.object({
  messages: z.array(z.object({
    role: z.enum(["user", "assistant", "system"]),
    content: z.string()
  })).max(50),
});

clientRouter.post("/ai/chat", async (req, res) => {
  try {
    const client = (req as unknown as { client: { id: string; remnawaveUuid: string | null } }).client;

    const parsed = aiChatSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ message: "Неверный формат сообщений", errors: parsed.error.flatten() });
    }

    const config = await getSystemConfig();
    const publicConfig = await getPublicConfig();
    if ((publicConfig as { aiChatEnabled?: boolean }).aiChatEnabled === false) {
      return res.status(403).json({ message: "AI-чат отключён" });
    }

    const apiKey = (config as { groqApiKey?: string | null }).groqApiKey?.trim();
    if (!apiKey) {
      // Заглушка, если API ключ не настроен
      return res.json({
        reply: "Извините, AI-ассистент пока не настроен. Пожалуйста, обратитесь в поддержку или настройте Groq API Key в админ-панели."
      });
    }

    const primaryModel = (config as { groqModel?: string | null }).groqModel?.trim() || "llama3-8b-8192";
    const fallback1 = (config as { groqFallback1?: string | null }).groqFallback1?.trim();
    const fallback2 = (config as { groqFallback2?: string | null }).groqFallback2?.trim();
    const fallback3 = (config as { groqFallback3?: string | null }).groqFallback3?.trim();
    
    const modelsToTry = [primaryModel];
    if (fallback1) modelsToTry.push(fallback1);
    if (fallback2) modelsToTry.push(fallback2);
    if (fallback3) modelsToTry.push(fallback3);

    const systemPromptText = (config as { aiSystemPrompt?: string | null }).aiSystemPrompt?.trim() || "Ты — лучший менеджер техподдержки VPN-сервиса. Твоя цель — вежливо, быстро и точно помогать пользователям с настройкой VPN, тарифами и решением технических проблем. Отвечай кратко и по делу.";

    const vpnTariffs = await prisma.tariff.findMany({ orderBy: { price: 'asc' } });
    const proxyTariffs = await prisma.proxyTariff.findMany({ where: { enabled: true }, orderBy: { price: 'asc' } });
    const singboxTariffs = await prisma.singboxTariff.findMany({ where: { enabled: true }, orderBy: { price: 'asc' } });

    let tariffsContext = "\n\nАКТУАЛЬНАЯ ИНФОРМАЦИЯ О ТАРИФАХ ДЛЯ ПОЛЬЗОВАТЕЛЯ:\nОбязательно используй только эти тарифы, если пользователь спрашивает про цены.\n";
    if (vpnTariffs.length > 0) tariffsContext += "VPN Тарифы: " + vpnTariffs.map(t => `${t.name} (${t.price} ${t.currency.toUpperCase()} на ${t.durationDays} дней)`).join(", ") + ".\n";
    if (proxyTariffs.length > 0) tariffsContext += "Прокси: " + proxyTariffs.map(t => `${t.name} (${t.price} ${t.currency.toUpperCase()} на ${t.durationDays} дней)`).join(", ") + ".\n";
    if (singboxTariffs.length > 0) tariffsContext += "Sing-box: " + singboxTariffs.map(t => `${t.name} (${t.price} ${t.currency.toUpperCase()} на ${t.durationDays} дней)`).join(", ") + ".\n";

    const paymentMethods = [];
    if (publicConfig.yookassaEnabled) paymentMethods.push("YooKassa (Банковские карты, СБП и др.)");
    if (publicConfig.yoomoneyEnabled) paymentMethods.push("YooMoney (Кошелек, Карты)");
    if (publicConfig.cryptopayEnabled) paymentMethods.push("Crypto Pay (Криптовалюта в Telegram)");
    if (publicConfig.heleketEnabled) paymentMethods.push("Heleket (Криптовалюта)");
    if (publicConfig.plategaMethods && publicConfig.plategaMethods.length > 0) {
      paymentMethods.push("Platega (" + publicConfig.plategaMethods.map(m => m.label).join(", ") + ")");
    }

    let paymentContext = "\n\nДОСТУПНЫЕ СПОСОБЫ ОПЛАТЫ НА САЙТЕ:\n";
    if (paymentMethods.length > 0) {
      paymentContext += "Пользователь может оплатить следующими способами:\n- " + paymentMethods.join("\n- ") + "\nЕсли спрашивают как оплатить, перечисли ТОЛЬКО эти способы. Не выдумывай Сбербанк Онлайн, QIWI, WebMoney, PayPal и т.д., если их нет в списке.\n";
    } else {
      paymentContext += "В данный момент на сайте не настроено автоматических способов оплаты.\n";
    }

    const instructionsContext = `\n\nИНСТРУКЦИЯ ПО ПОДКЛЮЧЕНИЮ:
Если пользователь спрашивает, как подключиться или настроить VPN, отвечай СТРОГО по следующему алгоритму (не придумывай свои методы):
1. В личном кабинете на сайте нажать кнопку "Подключить VPN".
2. Выбрать свою платформу и скачать предложенное приложение.
3. Вернуться на сайт и нажать кнопку "Добавить подписку" (оная автоматически добавит конфигурацию в приложение) либо отсканировать QR-код.

ПРАВИЛА ОТВЕТА О ЛИМИТАХ И ТАРИФАХ:
Если пользователь спрашивает "какой у меня тариф", "сколько осталось дней", "какой лимит трафика", "сколько устройств", "какой у меня баланс" и т.д., ВСЕГДА используй данные из блока "ИНФОРМАЦИЯ О ТЕКУЩЕМ ПОЛЬЗОВАТЕЛЕ" ниже. НИКОГДА не говори, что ты не можешь найти информацию. Просто прочитай её из блока и ответь пользователю.\n`;

    let userInfoContext = "\n\nИНФОРМАЦИЯ О ТЕКУЩЕМ ПОЛЬЗОВАТЕЛЕ:\nИспользуй эти данные, если пользователь спрашивает про свои текущие подписки или лимиты. Если написано, что чего-то нет, прямо скажи пользователю, что у него этого нет.\n";
    try {
      const dbClient = await prisma.client.findUnique({
        where: { id: client.id },
        include: {
          proxySlots: { where: { status: 'ACTIVE' }, include: { proxyTariff: true } },
          singboxSlots: { where: { status: 'ACTIVE' }, include: { singboxTariff: true } }
        }
      });
      
      userInfoContext += `- Баланс: ${dbClient?.balance || 0} ${(dbClient?.preferredCurrency || 'usd').toUpperCase()}\n`;

      let vpnInfo = "У пользователя НЕТ активной подписки VPN";
      if (client.remnawaveUuid) {
        const u = await remnaGetUser(client.remnawaveUuid);
        if (u && !u.error && u.data) {
          const exp = extractCurrentExpireAt(u.data);
          if (exp && exp > new Date()) {
             const resp = ((u.data as any).response ?? (u.data as any).data ?? u.data) as any;
             const tLimitRaw = resp?.trafficLimitBytes ?? resp?.trafficLimit;
             const tLimit = (tLimitRaw != null && tLimitRaw > 0) ? (Number(tLimitRaw) / 1024**3).toFixed(2) + " GB" : "Безлимит";
             const tUsedRaw = resp?.trafficUsedBytes ?? resp?.trafficUsed;
             const tUsed = tUsedRaw != null ? (Number(tUsedRaw) / 1024**3).toFixed(2) + " GB" : "0 GB";
             const dLimitRaw = resp?.hwidDeviceLimit ?? resp?.deviceLimit;
             const dLimit = (dLimitRaw != null && dLimitRaw > 0) ? dLimitRaw : "Безлимит";
             vpnInfo = `Активна до ${exp.toISOString().split('T')[0]}, Трафик: ${tUsed} / ${tLimit}, Лимит устройств: ${dLimit}`;
          }
        }
      }
      userInfoContext += `- VPN: ${vpnInfo}\n`;
      
      if (dbClient?.proxySlots?.length) {
        userInfoContext += `- Прокси: ${dbClient.proxySlots.map((s: any) => `${s.proxyTariff?.name || 'Слот'} (до ${s.expiresAt.toISOString().split('T')[0]})`).join(', ')}\n`;
      } else {
        userInfoContext += `- Прокси: У пользователя НЕТ прокси\n`;
      }
      
      if (dbClient?.singboxSlots?.length) {
        userInfoContext += `- Sing-box: ${dbClient.singboxSlots.map((s: any) => `${s.singboxTariff?.name || 'Слот'} (до ${s.expiresAt.toISOString().split('T')[0]})`).join(', ')}\n`;
      } else {
        userInfoContext += `- Sing-box: У пользователя НЕТ подписок Sing-box\n`;
      }
    } catch (e) {
      console.error("[ai/chat] Error fetching user info:", e);
    }

    const systemPrompt = systemPromptText + tariffsContext + paymentContext + instructionsContext + userInfoContext;

    const messages = [
      { role: "system", content: systemPrompt },
      ...parsed.data.messages
    ];

    let lastErrorDetails = "";
    let lastStatus = 500;

    for (const model of modelsToTry) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 30000);

        const groqRes = await fetch("https://api.groq.com/openai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model,
            messages,
            temperature: 0.5,
            max_tokens: 1024,
          }),
          signal: controller.signal,
        });
        
        clearTimeout(timeoutId);

        if (groqRes.ok) {
          const data = await groqRes.json() as any;
          const reply = data.choices?.[0]?.message?.content || "Не удалось получить ответ.";
          return res.json({ reply });
        }

        // Если ошибка (например, 429 Rate Limit), пробуем следующую модель
        const errText = await groqRes.text().catch(() => "");
        console.error(`[ai/chat] Groq error (model: ${model}):`, groqRes.status, errText);
        lastStatus = groqRes.status;
        lastErrorDetails = errText;
        
        // Если это не 429 Rate Limit или 5xx, возможно стоит прервать, но лучше попробовать следующую
      } catch (err) {
        console.error(`[ai/chat] Network/Abort error with model ${model}:`, err);
        lastErrorDetails = err instanceof Error ? err.message : String(err);
      }
    }

    // Если все модели не сработали
    return res.status(502).json({ message: "Ошибка сервиса AI или превышены лимиты", details: lastErrorDetails });

  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error("[ai/chat]", message, err);
    return res.status(500).json({ message: "Внутренняя ошибка сервера" });
  }
});

clientRouter.get("/payments", async (req, res) => {
  const clientId = (req as unknown as { clientId: string }).clientId;
  const payments = await prisma.payment.findMany({
    where: { clientId },
    orderBy: { createdAt: "desc" },
    take: 50,
    select: { id: true, orderId: true, amount: true, currency: true, status: true, createdAt: true, paidAt: true },
  });
  return res.json({
    items: payments.map((p) => ({
      id: p.id,
      orderId: p.orderId,
      amount: p.amount,
      currency: p.currency,
      status: p.status,
      createdAt: p.createdAt.toISOString(),
      paidAt: p.paidAt?.toISOString() ?? null,
    })),
  });
});

// ——— Тикеты (доступны только при включённой тикет-системе в настройках)
async function ensureTicketsEnabled(res: import("express").Response): Promise<boolean> {
  const config = await getPublicConfig();
  if (!config?.ticketsEnabled) {
    res.status(404).json({ message: "Тикет-система отключена" });
    return false;
  }
  return true;
}

const createTicketSchema = z.object({ subject: z.string().min(1).max(500), message: z.string().min(1).max(10000) });
clientRouter.post("/tickets", async (req, res) => {
  if (!(await ensureTicketsEnabled(res))) return;
  const clientId = (req as unknown as { client: { id: string } }).client.id;
  const body = createTicketSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });
  const ticket = await prisma.ticket.create({
    data: {
      clientId,
      subject: body.data.subject.trim(),
      status: "open",
      messages: {
        create: { authorType: "client", content: body.data.message.trim() },
      },
    },
    include: { messages: true },
  });
  notifyAdminsAboutNewTicket({
    ticketId: ticket.id,
    clientId,
    subject: ticket.subject,
    firstMessage: body.data.message.trim(),
  }).catch(() => {});
  return res.status(201).json({
    id: ticket.id,
    subject: ticket.subject,
    status: ticket.status,
    createdAt: ticket.createdAt.toISOString(),
    updatedAt: ticket.updatedAt.toISOString(),
    messages: ticket.messages.map((m) => ({ id: m.id, authorType: m.authorType, content: m.content, createdAt: m.createdAt.toISOString() })),
  });
});

clientRouter.get("/tickets/unread-count", async (req, res) => {
  if (!(await ensureTicketsEnabled(res))) return;
  const clientId = (req as unknown as { client: { id: string } }).client.id;
  const count = await prisma.ticketMessage.count({
    where: {
      ticket: { clientId },
      authorType: "support",
      isRead: false,
    },
  });
  return res.json({ count });
});

clientRouter.get("/tickets", async (req, res) => {
  if (!(await ensureTicketsEnabled(res))) return;
  const clientId = (req as unknown as { client: { id: string } }).client.id;
  const list = await prisma.ticket.findMany({
    where: { clientId },
    orderBy: { updatedAt: "desc" },
    select: { id: true, subject: true, status: true, createdAt: true, updatedAt: true },
  });
  return res.json({
    items: list.map((t) => ({ id: t.id, subject: t.subject, status: t.status, createdAt: t.createdAt.toISOString(), updatedAt: t.updatedAt.toISOString() })),
  });
});

clientRouter.get("/tickets/:id", async (req, res) => {
  if (!(await ensureTicketsEnabled(res))) return;
  const clientId = (req as unknown as { client: { id: string } }).client.id;
  const ticket = await prisma.ticket.findFirst({
    where: { id: req.params.id, clientId },
    include: { messages: { orderBy: { createdAt: "asc" } } },
  });
  if (!ticket) return res.status(404).json({ message: "Тикет не найден" });

  // Mark support messages as read
  await prisma.ticketMessage.updateMany({
    where: { ticketId: ticket.id, authorType: "support", isRead: false },
    data: { isRead: true },
  });

  return res.json({
    id: ticket.id,
    subject: ticket.subject,
    status: ticket.status,
    createdAt: ticket.createdAt.toISOString(),
    updatedAt: ticket.updatedAt.toISOString(),
    messages: ticket.messages.map((m) => ({ id: m.id, authorType: m.authorType, content: m.content, createdAt: m.createdAt.toISOString(), isRead: m.isRead })),
  });
});

const replyTicketSchema = z.object({ content: z.string().min(1).max(10000) });
clientRouter.post("/tickets/:id/messages", async (req, res) => {
  if (!(await ensureTicketsEnabled(res))) return;
  const clientId = (req as unknown as { client: { id: string } }).client.id;
  const body = replyTicketSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });
  const ticket = await prisma.ticket.findFirst({ where: { id: req.params.id, clientId } });
  if (!ticket) return res.status(404).json({ message: "Тикет не найден" });
  const msg = await prisma.ticketMessage.create({
    data: { ticketId: ticket.id, authorType: "client", content: body.data.content.trim() },
  });
  await prisma.ticket.update({ where: { id: ticket.id }, data: { updatedAt: new Date() } });
  notifyAdminsAboutClientTicketMessage({
    ticketId: ticket.id,
    clientId,
    content: body.data.content.trim(),
  }).catch(() => {});
  return res.status(201).json({ id: msg.id, authorType: msg.authorType, content: msg.content, createdAt: msg.createdAt.toISOString() });
});

// Публичный конфиг для бота, mini app, сайта (без паролей и секретов)
export const publicConfigRouter = Router();
publicConfigRouter.get("/config", async (_req, res) => {
  const config = await getPublicConfig();
  return res.json(config);
});

/**
 * Промежуточная страница для диплинков: открывается через Telegram.WebApp.openLink() в системном браузере,
 * который уже может обработать кастомную URL-схему (happ://, stash://, v2rayng:// и т.д.).
 * В Telegram Mini App WebView кастомные схемы заблокированы — это единственный рабочий обходной путь.
 */
publicConfigRouter.get("/deeplink", (req, res) => {
  const url = typeof req.query.url === "string" ? req.query.url : "";
  if (!url) return res.status(400).send("Missing url parameter");
  const skipAuto = req.query.skip_auto === "1" || req.query.skip_auto === "true";
  const safeUrl = url.replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const safeUrlJs = url.replace(/\\/g, "\\\\").replace(/'/g, "\\'").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r");
  const autoRedirectScript = skipAuto
    ? "/* skip_auto: только кнопка, без авто-редиректа (из мини-аппа) */"
    : `setTimeout(function(){ try { window.location.href = "${safeUrlJs}"; } catch (e) {} }, 300);`;
  const html = `<!DOCTYPE html>
<html><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Открытие приложения…</title>
<style>
  body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#0d1117;color:#e6edf3;padding:16px;box-sizing:border-box}
  .btn{display:inline-block;margin-top:24px;padding:14px 32px;background:#2ea043;color:#fff;border:none;border-radius:12px;font-size:17px;text-decoration:none;cursor:pointer}
  .btn:active{opacity:.85}
  .sub{margin-top:16px;font-size:13px;color:#8b949e;max-width:90%;text-align:center;word-break:break-all}
  .hint{margin-top:12px;font-size:12px;color:#8b949e;max-width:90%;text-align:center}
</style>
</head><body>
<p>Открываем приложение…</p>
<a class="btn" href="${safeUrl}" id="open">Открыть приложение</a>
<p class="sub">Если приложение не открылось — нажмите кнопку выше.<br>Ссылка подписки скопирована в буфер обмена.</p>
<p class="hint" id="androidHint" style="display:none">На Android или в Telegram на ПК: если страница открылась внутри Telegram, зайдите в Настройки → Чаты → «Открывать ссылки во внешнем браузере» и нажмите кнопку ещё раз.</p>
<script>
  (function(){
    var ua = navigator.userAgent || "";
    if (/Android|Windows|tdesktop/i.test(ua)) document.getElementById("androidHint").style.display = "block";
    ${autoRedirectScript}
  })();
</script>
</body></html>`;
  res.type("html").send(html);
});

/** Привязка Telegram к аккаунту по коду (вызывается ботом после /link КОД) */
const linkTelegramFromBotSchema = z.object({
  code: z.string().min(1),
  telegramId: z.number(),
  telegramUsername: z.string().optional(),
});
publicConfigRouter.post("/link-telegram-from-bot", async (req, res) => {
  const config = await getSystemConfig();
  const botToken = (config.telegramBotToken ?? "").trim();
  const headerToken = typeof req.headers["x-telegram-bot-token"] === "string" ? req.headers["x-telegram-bot-token"].trim() : "";
  if (!botToken || headerToken !== botToken) return res.status(401).json({ message: "Unauthorized" });
  const body = linkTelegramFromBotSchema.safeParse(req.body);
  if (!body.success) return res.status(400).json({ message: "Invalid input", errors: body.error.flatten() });
  const { code, telegramId, telegramUsername } = body.data;
  const tid = String(telegramId);
  const pending = await prisma.pendingTelegramLink.findUnique({ where: { code: code.trim() } });
  if (!pending) return res.status(400).json({ message: "Неверный или просроченный код" });
  if (new Date() > pending.expiresAt) {
    await prisma.pendingTelegramLink.deleteMany({ where: { id: pending.id } }).catch(() => {});
    return res.status(400).json({ message: "Код истёк. Запросите новый в кабинете." });
  }
  const other = await prisma.client.findUnique({ where: { telegramId: tid } });
  if (other && other.id !== pending.clientId) {
    await prisma.pendingTelegramLink.deleteMany({ where: { id: pending.id } }).catch(() => {});
    return res.status(409).json({ message: "Этот Telegram-аккаунт уже привязан к другому аккаунту. Отвяжите его сначала или обратитесь в поддержку." });
  }
  await prisma.client.update({
    where: { id: pending.clientId },
    data: { telegramId: tid, telegramUsername: (telegramUsername ?? "").trim() || null },
  });
  await prisma.pendingTelegramLink.deleteMany({ where: { id: pending.id } }).catch(() => {});
  return res.json({ message: "Telegram привязан" });
});

/** Конфиг страницы подписки (приложения по платформам, тексты) — для кабинета /cabinet/subscribe */
publicConfigRouter.get("/subscription-page", async (_req, res) => {
  try {
    const row = await prisma.systemSetting.findUnique({
      where: { key: "subscription_page_config" },
    });
    if (!row?.value) return res.json(null);
    const parsed = JSON.parse(row.value) as unknown;
    return res.json(parsed);
  } catch {
    return res.json(null);
  }
});

function tariffToJson(t: { id: string; name: string; description: string | null; durationDays: number; internalSquadUuids: string[]; trafficLimitBytes: bigint | null; trafficResetMode?: string; deviceLimit: number | null; price: number; currency: string }) {
  return {
    id: t.id,
    name: t.name,
    description: t.description ?? null,
    durationDays: t.durationDays,
    trafficLimitBytes: t.trafficLimitBytes != null ? Number(t.trafficLimitBytes) : null,
    trafficResetMode: t.trafficResetMode ?? "no_reset",
    deviceLimit: t.deviceLimit,
    price: t.price,
    currency: t.currency,
  };
}

publicConfigRouter.get("/tariffs", async (_req, res) => {
  try {
    const config = await getSystemConfig();
    const categoryEmojis = config.categoryEmojis ?? { ordinary: "📦", premium: "⭐" };
    const list = await prisma.tariffCategory.findMany({
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
      include: { tariffs: { orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] } },
    });
    return res.json({
      items: list.map((c) => {
        const emoji = (c.emojiKey && categoryEmojis[c.emojiKey]) ? categoryEmojis[c.emojiKey] : "";
        return {
          id: c.id,
          name: c.name,
          emojiKey: c.emojiKey ?? null,
          emoji,
          tariffs: c.tariffs.map(tariffToJson),
        };
      }),
    });
  } catch (e) {
    console.error("GET /public/tariffs error:", e);
    return res.status(500).json({ message: "Ошибка загрузки тарифов" });
  }
});

// GET /api/public/proxy-tariffs — публичный список тарифов прокси (для бота и кабинета)
publicConfigRouter.get("/proxy-tariffs", async (_req, res) => {
  try {
    const list = await prisma.proxyCategory.findMany({
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
      include: { tariffs: { where: { enabled: true }, orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] } },
    });
    return res.json({
      items: list.map((c) => ({
        id: c.id,
        name: c.name,
        sortOrder: c.sortOrder,
        tariffs: c.tariffs.map((t) => ({
          id: t.id,
          name: t.name,
          proxyCount: t.proxyCount,
          durationDays: t.durationDays,
          trafficLimitBytes: t.trafficLimitBytes?.toString() ?? null,
          connectionLimit: t.connectionLimit,
          price: t.price,
          currency: t.currency,
        })),
      })),
    });
  } catch (e) {
    console.error("GET /public/proxy-tariffs error:", e);
    return res.status(500).json({ message: "Ошибка загрузки тарифов прокси" });
  }
});

// GET /api/public/singbox-tariffs — публичный список тарифов Sing-box (для бота и кабинета)
publicConfigRouter.get("/singbox-tariffs", async (_req, res) => {
  try {
    const list = await prisma.singboxCategory.findMany({
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
      include: { tariffs: { where: { enabled: true }, orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] } },
    });
    return res.json({
      items: list.map((c) => ({
        id: c.id,
        name: c.name,
        sortOrder: c.sortOrder,
        tariffs: c.tariffs.map((t) => ({
          id: t.id,
          name: t.name,
          slotCount: t.slotCount,
          durationDays: t.durationDays,
          trafficLimitBytes: t.trafficLimitBytes?.toString() ?? null,
          price: t.price,
          currency: t.currency,
        })),
      })),
    });
  } catch (e) {
    console.error("GET /public/singbox-tariffs error:", e);
    return res.status(500).json({ message: "Ошибка загрузки тарифов Sing-box" });
  }
});



