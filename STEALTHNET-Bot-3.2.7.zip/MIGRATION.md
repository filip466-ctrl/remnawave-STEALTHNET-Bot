# Миграция на STEALTHNET 3.0

Инструкции по переносу данных с предыдущих версий панелей.

> **Важно:** Перед любой миграцией сделайте бэкап новой БД.  
> Все скрипты **идемпотентные** — при повторном запуске дубликаты пропускаются.

---

## Содержание

- [Общее: подготовка](#общее-подготовка)
- [Определение валюты](#определение-валюты)
- [Вариант 1: Миграция из старой панели (Flask)](#вариант-1-миграция-из-старой-панели-flask)
- [Вариант 2: Миграция из Бедолага Бот](#вариант-2-миграция-из-бедолага-бот)
- [Часто задаваемые вопросы](#часто-задаваемые-вопросы)

---

## Общее: подготовка

### 1. Убедитесь, что новая панель работает

```bash
docker compose ps
# Все сервисы должны быть Up
```

### 2. Установите зависимости скриптов миграции (один раз)

```bash
cd /opt/remnawave-STEALTHNET-Bot/scripts
npm install
cd ..
```

### 3. Сделайте бэкап новой БД

```bash
docker compose exec postgres pg_dump -U stealthnet stealthnet > backup_before_migration.sql
```

---

## Определение валюты

Оба скрипта миграции **автоматически определяют системную валюту** из настроек новой панели (таблица `system_settings`, ключ `default_currency`).

| Системная валюта | Что происходит |
|---|---|
| `rub` | Балансы, цены, платежи переносятся в **рублях** |
| `usd` | Всё конвертируется в **доллары** |
| `uah` | Всё в **гривнах** |

Валюту можно задать через настройки в админ-панели (Настройки → Валюта по умолчанию) **до** запуска миграции, или переопределить через ENV:

```bash
DEFAULT_CURRENCY=rub node scripts/migrate-from-old-panel.js
```

---

## Вариант 1: Миграция из старой панели (Flask)

> Скрипт: `scripts/migrate-from-old-panel.js`  
> Источник: PostgreSQL-база предыдущей STEALTHNET-панели (Flask + SQLAlchemy)

### Что переносится

| Старая панель (Flask) | STEALTHNET 3.0 | Детали |
|---|---|---|
| `User` | `Client` | email, telegram_id, баланс, referral_code, remnawave_uuid, trial_used |
| `TariffLevel` / поле `tier` | `TariffCategory` | basic → «Базовый», pro → «Премиум», elite → «Элитный» |
| `Tariff` | `Tariff` | Цена берётся из колонки системной валюты (`price_rub` / `price_usd` / `price_uah`) |
| `Payment` | `Payment` | Вся история платежей с провайдерами |
| `PromoCode` | `PromoCode` | PERCENT → DISCOUNT, DAYS → FREE_DAYS |
| `referrer_id` связи | `referrerId` | Реферальные цепочки |
| `SystemSetting` | `SystemSettings` | Язык, валюта, активные языки/валюты |
| `BotConfig` | `SystemSettings` | Имя сервиса, поддержка, дни триала |
| `BrandingSetting` | `SystemSettings` | Логотип, favicon, название |
| `ReferralSetting` | `SystemSettings` | Проценты рефералов, сквад триала |
| `TrialSettings` | `SystemSettings` | Дни, устройства, трафик |

### Запуск

```bash
cd /opt/remnawave-STEALTHNET-Bot

OLD_DB_HOST=localhost \
OLD_DB_PORT=5432 \
OLD_DB_NAME=stealthnet_old \
OLD_DB_USER=stealthnet \
OLD_DB_PASSWORD=old_password \
NEW_DB_HOST=localhost \
NEW_DB_PORT=5432 \
NEW_DB_NAME=stealthnet \
NEW_DB_USER=stealthnet \
NEW_DB_PASSWORD=new_password \
node scripts/migrate-from-old-panel.js
```

> Если обе БД на одном сервере — укажите разные `OLD_DB_NAME` / `NEW_DB_NAME`.

### Все переменные

| Переменная | По умолчанию | Описание |
|---|---|---|
| `OLD_DB_HOST` | `localhost` | Хост старой PostgreSQL |
| `OLD_DB_PORT` | `5432` | Порт старой БД |
| `OLD_DB_NAME` | `stealthnet` | Имя старой БД |
| `OLD_DB_USER` | `stealthnet` | Пользователь старой БД |
| `OLD_DB_PASSWORD` | `stealthnet_password_change_me` | Пароль старой БД |
| `NEW_DB_HOST` | `localhost` | Хост новой PostgreSQL |
| `NEW_DB_PORT` | `5432` | Порт новой БД |
| `NEW_DB_NAME` | `stealthnet` | Имя новой БД |
| `NEW_DB_USER` | `stealthnet` | Пользователь новой БД |
| `NEW_DB_PASSWORD` | `stealthnet_change_me` | Пароль новой БД |
| `DEFAULT_CURRENCY` | *(из system_settings)* | Переопределить валюту (`rub`, `usd`, `uah`) |

### Пример вывода

```
  💱  Системная валюта: RUB
      Балансы и цены будут перенесены в RUB

═══════════════════════════════════════════════════════════════
  1/7  Категории тарифов (TariffLevel → TariffCategory)
═══════════════════════════════════════════════════════════════
  ✅  Категория "Базовый" (basic)
  ✅  Категория "Премиум" (pro)
  ...

╔══════════════════════════════════════════════════════════════╗
║                    МИГРАЦИЯ ЗАВЕРШЕНА                        ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  Клиенты:       42 создано      0 пропущено    0 ошибок     ║
║  Категории:      3 создано      0 пропущено                 ║
║  Тарифы:         9 создано      0 пропущено    0 ошибок     ║
║  Платежи:      156 создано      0 пропущено    0 ошибок     ║
║  Промокоды:      5 создано      0 пропущено    0 ошибок     ║
║  Рефералы:      18 связано                     0 ошибок     ║
║  Настройки:     12 перенесено                               ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
```

### После миграции

- [ ] Зайдите в **админ-панель** → проверьте клиентов, тарифы, платежи
- [ ] Настройте **платёжную систему** (Platega) в разделе «Настройки»
- [ ] Нажмите **«Sync from Remna»** в админке — привяжет актуальные подписки
- [ ] Проверьте **бот-токен** в `.env` (если бот новый — `docker compose restart bot`)

---

## Вариант 2: Миграция из Бедолага Бот

> Скрипт: `scripts/migrate-from-bedolaga.js`  
> Источник: JSON-бэкап (`backup_*.tar.gz`) из remnawave-bedolaga-telegram-bot

### Что переносится

| Бедолага Бот | STEALTHNET 3.0 | Детали |
|---|---|---|
| `users` | `clients` | telegram_id, username, имя, баланс, remnawave_uuid, referral_code |
| `subscriptions` | обновление `trial_used` | Данные подписок уже в Remnawave — подтянутся через Sync |
| `transactions` | `payments` | Все транзакции: пополнения, покупки, бонусы |
| `referred_by_id` | `referrerId` | Реферальные цепочки |
| `referral_earnings` | `referral_credits` | Начисления рефералам |
| `system_settings` | `system_settings` | Общие настройки (секреты/токены пропускаются) |

### Конвертация валюты (копейки)

Бедолага хранит суммы в **копейках**. Скрипт конвертирует автоматически:

| Системная валюта | Формула | Пример: 30000 копеек |
|---|---|---|
| `rub` | копейки ÷ 100 | **300 ₽** |
| `uah` | копейки ÷ 100 | **300 ₴** |
| `usd` | копейки × курс `KOPEKS_TO_USD` | **3.00 $** (при курсе 0.0001) |

### Запуск

```bash
cd /opt/remnawave-STEALTHNET-Bot

# Путь к бэкапу как аргумент
node scripts/migrate-from-bedolaga.js ./backup_20260126_000000.tar.gz
```

Или с переменными:

```bash
NEW_DB_HOST=localhost \
NEW_DB_PORT=5432 \
NEW_DB_NAME=stealthnet \
NEW_DB_USER=stealthnet \
NEW_DB_PASSWORD=new_password \
KOPEKS_TO_USD=0.0001 \
node scripts/migrate-from-bedolaga.js ./backup.tar.gz
```

### Все переменные

| Переменная | По умолчанию | Описание |
|---|---|---|
| `NEW_DB_HOST` | `localhost` | Хост новой PostgreSQL |
| `NEW_DB_PORT` | `5432` | Порт |
| `NEW_DB_NAME` | `stealthnet` | Имя БД |
| `NEW_DB_USER` | `stealthnet` | Пользователь |
| `NEW_DB_PASSWORD` | `stealthnet_change_me` | Пароль |
| `DEFAULT_CURRENCY` | *(из system_settings)* | Переопределить валюту |
| `KOPEKS_TO_USD` | `0.0001` | Курс для USD (1 копейка = X USD). Только при `usd` |

### Пример вывода

```
  💱  Системная валюта: RUB
      Копейки → рубли (÷100)

╔══════════════════════════════════════════════════════════════╗
║               МИГРАЦИЯ ИЗ БЕДОЛАГИ ЗАВЕРШЕНА                ║
╠══════════════════════════════════════════════════════════════╣
║                                                              ║
║  Клиенты:        17 создано     0 пропущено    0 ошибок     ║
║  Подписки:        6 обновл.     0 пропущено                 ║
║  Платежи:        11 создано     0 пропущено    0 ошибок     ║
║  Рефералы:        2 связано                    0 ошибок     ║
║  Реф.бонусы:      1 создано                    0 ошибок     ║
║  Настройки:       4 перенесено                              ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
```

### После миграции

- [ ] Проверьте клиентов в **админ-панели**
- [ ] Нажмите **«Sync from Remna»** — подтянет подписки из Remnawave
- [ ] **Создайте тарифы** вручную (в Бедолаге тарифных планов нет)
- [ ] Настройте **платёжную систему** Platega
- [ ] При необходимости скорректируйте курс и перезапустите миграцию

---

## Часто задаваемые вопросы

### Можно ли запускать миграцию повторно?

Да. Оба скрипта идемпотентные — дубликаты пропускаются по `telegram_id`, `email`, `order_id`. Данные не задваиваются.

### Как откатить миграцию?

Восстановите бэкап:

```bash
docker compose exec -T postgres psql -U stealthnet stealthnet < backup_before_migration.sql
```

### У меня SQLite в старой панели, не PostgreSQL

Скрипт `migrate-from-old-panel.js` работает только с PostgreSQL. Если старая панель на SQLite, сначала мигрируйте её в PostgreSQL (в старой панели есть скрипт `migration/manual/migrate_to_postgresql.py`), затем запустите наш скрипт.

### Как узнать, какая валюта стоит в системе?

```bash
docker compose exec postgres psql -U stealthnet stealthnet \
  -c "SELECT value FROM system_settings WHERE key = 'default_currency';"
```

Или зайдите в админ-панель → **Настройки** → раздел «Валюта по умолчанию».

### Балансы перенеслись в неправильной валюте

1. Установите нужную валюту в админке (Настройки → Валюта)
2. Очистите перенесённых клиентов (или восстановите бэкап)
3. Перезапустите миграцию — она возьмёт актуальную валюту

### Где бэкап Бедолаги?

В настройках Бедолага Бот → Бэкапы, или в папке `/app/data/backups/` внутри контейнера:

```bash
docker cp stealthnet-bot:/app/data/backups/ ./bedolaga-backups/
ls ./bedolaga-backups/
```
