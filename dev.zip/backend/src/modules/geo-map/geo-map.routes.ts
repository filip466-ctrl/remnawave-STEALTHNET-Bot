import { Router } from "express";
import { requireAuth, requireAdminSection } from "../auth/middleware.js";
import { getGeoMapData, invalidateCache } from "./geo-map.service.js";

export const geoMapRouter = Router();
geoMapRouter.use(requireAuth);
geoMapRouter.use(requireAdminSection);

geoMapRouter.get("/data", async (_req, res) => {
  try {
    const data = await getGeoMapData(false);
    res.json(data);
  } catch (e) {
    console.error("[geo-map] Error fetching map data:", e);
    res.status(500).json({ message: "Failed to fetch geo map data" });
  }
});

geoMapRouter.post("/refresh", async (_req, res) => {
  try {
    invalidateCache();
    const data = await getGeoMapData(true);
    res.json(data);
  } catch (e) {
    console.error("[geo-map] Error refreshing map data:", e);
    res.status(500).json({ message: "Failed to refresh geo map data" });
  }
});
