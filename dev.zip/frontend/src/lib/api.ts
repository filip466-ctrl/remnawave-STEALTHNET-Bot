const API_BASE = "/api";

/** Вызывается при 401: возвращает новый access token или null. Устанавливается из AuthProvider. */
let tokenRefreshFn: (() => Promise<string | null>) | null = null;
export function setTokenRefreshFn(fn: (() => Promise<string | null>) | null) {
  tokenRefreshFn = fn;
}

export interface Admin {
  id: string;
  email: string;
  mustChangePassword: boolean;
  role: string;
  /** Для роли MANAGER — список разделов, к которым есть доступ. Для ADMIN не используется. */
  allowedSections?: string[];
  /** Включена ли двухфакторная аутентификация */
  totpEnabled?: boolean;
}

/** Разделы, которые можно выдать менеджеру (без "admins"). */
export const MANAGER_SECTIONS = [
  { key: "dashboard", label: "Дашборд" },
  { key: "remna-nodes", label: "Ноды Remna" },
  { key: "clients", label: "Клиенты" },
  { key: "referrals", label: "Реферальная сеть" },
  { key: "tariffs", label: "Тарифы" },
  { key: "promo", label: "Промо-ссылки" },
  { key: "promo-codes", label: "Промокоды" },
  { key: "analytics", label: "Аналитика" },
  { key: "traffic-abuse", label: "Анализ трафика" },
  { key: "marketing", label: "Маркетинг" },
  { key: "sales-report", label: "Отчёты продаж" },
  { key: "broadcast", label: "Рассылка" },
  { key: "auto-broadcast", label: "Авто-рассылка" },
  { key: "backup", label: "Бэкапы" },
  { key: "proxy", label: "Прокси" },
  { key: "singbox", label: "Sing-box" },
  { key: "contests", label: "Конкурсы" },
  { key: "settings", label: "Настройки" },
  { key: "api-keys", label: "API ключи" },
] as const;

export interface AdminListItem {
  id: string;
  email: string;
  role: string;
  allowedSections: string[];
  mustChangePassword?: boolean;
  createdAt?: string;
}

export type ContestPrizeType = "custom" | "balance" | "vpn_days";
export type ContestDrawType = "random" | "by_days_bought" | "by_payments_count" | "by_referrals_count";
export type ContestStatus = "draft" | "active" | "ended" | "drawn";

export interface ContestFormPayload {
  name: string;
  startAt: string;
  endAt: string;
  prize1Type: ContestPrizeType;
  prize1Value: string;
  prize2Type: ContestPrizeType;
  prize2Value: string;
  prize3Type: ContestPrizeType;
  prize3Value: string;
  conditionsJson: string | null;
  drawType: ContestDrawType;
  dailyMessage: string | null;
  buttonText?: string | null;
  buttonUrl?: string | null;
}

export interface ContestListItem {
  id: string;
  name: string;
  startAt: string;
  endAt: string;
  prize1Type: ContestPrizeType;
  prize1Value: string;
  prize2Type: ContestPrizeType;
  prize2Value: string;
  prize3Type: ContestPrizeType;
  prize3Value: string;
  conditionsJson: string | null;
  drawType: ContestDrawType;
  dailyMessage: string | null;
  buttonText?: string | null;
  buttonUrl?: string | null;
  status: ContestStatus;
  createdAt: string;
  updatedAt: string;
  winners: { place: number; prizeType: string; prizeValue: string; client?: { id: string; email: string | null; telegramUsername: string | null } }[];
}

export interface ContestDetail extends ContestListItem {
  winners: { place: number; prizeType: string; prizeValue: string; appliedAt: string | null; client?: { id: string; email: string | null; telegramId: string | null; telegramUsername: string | null } }[];
}

export interface LoginResponse {
  accessToken: string;
  refreshToken: string;
  expiresIn: string;
  admin: Admin;
}

/** Ответ входа, когда у админа включена 2FA */
export interface AdminAuthRequires2FA {
  requires2FA: true;
  tempToken: string;
}

export interface AuthState {
  admin: Admin | null;
  accessToken: string | null;
  refreshToken: string | null;
  /** Временный токен для шага 2FA после проверки пароля */
  pending2FAToken: string | null;
}

async function request<T>(
  path: string,
  options: RequestInit & { token?: string; _retry?: boolean } = {}
): Promise<T> {
  const { token, _retry, ...init } = options;
  const headers = new Headers(init.headers);
  headers.set("Content-Type", "application/json");
  if (token) headers.set("Authorization", `Bearer ${token}`);

  const res = await fetch(`${API_BASE}${path}`, { ...init, headers });
  const text = await res.text();
  let data: unknown;
  try {
    data = text ? JSON.parse(text) : undefined;
  } catch {
    throw new Error(res.statusText || "Request failed");
  }

  if (res.status === 401 && token && !_retry && tokenRefreshFn && !path.startsWith("/auth/")) {
    const newToken = await tokenRefreshFn();
    if (newToken) {
      return request<T>(path, { ...options, token: newToken, _retry: true });
    }
  }

  if (!res.ok) {
    const message = (data as { message?: string })?.message ?? res.statusText;
    throw new Error(message);
  }
  return data as T;
}

export const api = {
  async login(email: string, password: string): Promise<LoginResponse | AdminAuthRequires2FA> {
    return request<LoginResponse | AdminAuthRequires2FA>("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
  },

  /** Обмен временного токена на access/refresh после ввода кода 2FA */
  async admin2FALogin(tempToken: string, code: string): Promise<LoginResponse> {
    return request("/auth/2fa-login", {
      method: "POST",
      body: JSON.stringify({ tempToken, code }),
    });
  },

  /** Запуск настройки 2FA админа (возвращает secret и otpauthUrl для QR) */
  async admin2FASetup(token: string): Promise<{ secret: string; otpauthUrl: string }> {
    return request("/auth/2fa/setup", { method: "POST", token });
  },
  /** Подтвердить включение 2FA админа кодом из приложения */
  async admin2FAConfirm(token: string, code: string): Promise<{ message: string }> {
    return request("/auth/2fa/confirm", { method: "POST", body: JSON.stringify({ code }), token });
  },
  /** Отключить 2FA админа (требуется код из приложения) */
  async admin2FADisable(token: string, code: string): Promise<{ message: string }> {
    return request("/auth/2fa/disable", { method: "POST", body: JSON.stringify({ code }), token });
  },

  async refresh(refreshToken: string): Promise<{ accessToken: string; expiresIn: string; admin: Admin }> {
    return request("/auth/refresh", {
      method: "POST",
      body: JSON.stringify({ refreshToken }),
    });
  },

  async logout(refreshToken: string | null) {
    if (refreshToken) {
      await request("/auth/logout", {
        method: "POST",
        body: JSON.stringify({ refreshToken }),
      }).catch(() => { });
    }
  },

  async changePassword(
    currentPassword: string,
    newPassword: string,
    token: string
  ): Promise<{ success: boolean; message: string; admin: Admin }> {
    return request("/auth/change-password", {
      method: "POST",
      body: JSON.stringify({ currentPassword, newPassword }),
      token,
    });
  },

  async getMe(token: string): Promise<Admin> {
    return request<Admin>("/admin/me", { token });
  },

  async getRemnaStatus(token: string): Promise<{ configured: boolean }> {
    return request("/admin/remna/status", { token });
  },

  async getDashboardStats(token: string): Promise<DashboardStats> {
    return request("/admin/dashboard/stats", { token });
  },

  async getServerStats(token: string): Promise<ServerStats> {
    return request("/admin/server/stats", { token });
  },

  async getSshConfig(token: string): Promise<SshConfig | null> {
    return request("/admin/server/ssh", { token }).then((r) => r as SshConfig).catch(() => null);
  },

  async updateSshConfig(token: string, data: Partial<SshConfig>): Promise<SshConfig> {
    return request("/admin/server/ssh", { method: "PATCH", body: JSON.stringify(data), token });
  },

  async testNalogConnection(token: string): Promise<{ ok: boolean; error?: string; inn?: string }> {
    return request("/admin/nalog/test", { method: "POST", token });
  },

  async getAutoRenewStats(token: string): Promise<AutoRenewStats> {
    return request("/admin/auto-renew/stats", { token });
  },

  async getAdminNotificationCounters(token: string): Promise<AdminNotificationCounters> {
    return request("/admin/notifications/counters", { token });
  },

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async getAnalytics(token: string): Promise<any> {
    return request("/admin/analytics", { token });
  },

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  async getSalesReport(token: string, params?: { from?: string; to?: string; provider?: string; page?: number; limit?: number }): Promise<any> {
    const search = new URLSearchParams();
    if (params?.from) search.set("from", params.from);
    if (params?.to) search.set("to", params.to);
    if (params?.provider) search.set("provider", params.provider);
    if (params?.page) search.set("page", String(params.page));
    if (params?.limit) search.set("limit", String(params.limit));
    const q = search.toString();
    return request(`/admin/sales-report${q ? `?${q}` : ""}`, { token });
  },

  async getRemnaSystemStats(token: string): Promise<RemnaSystemStats> {
    return request("/admin/remna/system/stats", { token });
  },

  async getRemnaNodes(token: string): Promise<RemnaNodesResponse> {
    return request("/admin/remna/nodes", { token });
  },

  async remnaNodeEnable(token: string, nodeUuid: string): Promise<unknown> {
    return request(`/admin/remna/nodes/${nodeUuid}/enable`, { method: "POST", token });
  },

  async remnaNodeDisable(token: string, nodeUuid: string): Promise<unknown> {
    return request(`/admin/remna/nodes/${nodeUuid}/disable`, { method: "POST", token });
  },

  async remnaNodeRestart(token: string, nodeUuid: string): Promise<unknown> {
    return request(`/admin/remna/nodes/${nodeUuid}/restart`, { method: "POST", token });
  },

  // ——— Прокси-ноды ———
  async getProxyNodes(token: string): Promise<{ items: ProxyNodeListItem[] }> {
    return request("/admin/proxy/nodes", { token });
  },

  async createProxyNode(token: string, data?: { name?: string }): Promise<CreateProxyNodeResponse> {
    return request("/admin/proxy/nodes", { method: "POST", body: JSON.stringify(data ?? {}), token });
  },

  async getProxyNode(token: string, id: string): Promise<ProxyNodeDetail> {
    return request(`/admin/proxy/nodes/${id}`, { token });
  },

  async updateProxyNode(token: string, id: string, data: { name?: string; status?: string; capacity?: number | null; socksPort?: number; httpPort?: number }): Promise<unknown> {
    return request(`/admin/proxy/nodes/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async deleteProxyNode(token: string, id: string): Promise<void> {
    return request(`/admin/proxy/nodes/${id}`, { method: "DELETE", token });
  },

  async getProxyCategories(token: string): Promise<{ items: { id: string; name: string; sortOrder: number; tariffs: { id: string; categoryId: string; name: string; proxyCount: number; durationDays: number; trafficLimitBytes: string | null; connectionLimit: number | null; price: number; currency: string; sortOrder: number; enabled: boolean; nodeIds: string[] }[] }[] }> {
    return request("/admin/proxy/categories", { token });
  },
  async createProxyCategory(token: string, data: { name: string; sortOrder?: number }): Promise<{ id: string; name: string; sortOrder: number }> {
    return request("/admin/proxy/categories", { method: "POST", body: JSON.stringify(data), token });
  },
  async updateProxyCategory(token: string, id: string, data: { name?: string; sortOrder?: number }): Promise<unknown> {
    return request(`/admin/proxy/categories/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },
  async deleteProxyCategory(token: string, id: string): Promise<void> {
    return request(`/admin/proxy/categories/${id}`, { method: "DELETE", token });
  },

  async getProxyTariffs(token: string, categoryId?: string): Promise<{ items: { id: string; categoryId: string; categoryName: string; name: string; proxyCount: number; durationDays: number; trafficLimitBytes: string | null; connectionLimit: number | null; price: number; currency: string; sortOrder: number; enabled: boolean }[] }> {
    const q = categoryId ? `?categoryId=${encodeURIComponent(categoryId)}` : "";
    return request(`/admin/proxy/tariffs${q}`, { token });
  },
  async createProxyTariff(token: string, data: { categoryId: string; name: string; proxyCount: number; durationDays: number; trafficLimitBytes?: string | number | null; connectionLimit?: number | null; price: number; currency: string; sortOrder?: number; enabled?: boolean; nodeIds?: string[] }): Promise<unknown> {
    return request("/admin/proxy/tariffs", { method: "POST", body: JSON.stringify(data), token });
  },
  async updateProxyTariff(token: string, id: string, data: Partial<{ name: string; proxyCount: number; durationDays: number; trafficLimitBytes: string | number | null; connectionLimit: number | null; price: number; currency: string; sortOrder: number; enabled: boolean; nodeIds: string[] }>): Promise<unknown> {
    return request(`/admin/proxy/tariffs/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },
  async deleteProxyTariff(token: string, id: string): Promise<void> {
    return request(`/admin/proxy/tariffs/${id}`, { method: "DELETE", token });
  },

  async getProxySlotsAdmin(token: string): Promise<{ items: ProxySlotAdminItem[] }> {
    return request("/admin/proxy/slots", { token });
  },

  async updateProxySlotAdmin(token: string, id: string, data: { login?: string; password?: string; connectionLimit?: number | null; status?: string; expiresAt?: string }): Promise<unknown> {
    return request(`/admin/proxy/slots/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async deleteProxySlotAdmin(token: string, id: string): Promise<void> {
    return request(`/admin/proxy/slots/${id}`, { method: "DELETE", token });
  },

  // ——— Sing-box ноды ———
  async getSingboxNodes(token: string): Promise<{ items: SingboxNodeListItem[] }> {
    return request("/admin/singbox/nodes", { token });
  },

  async createSingboxNode(token: string, data?: { name?: string; protocol?: string; port?: number; tlsEnabled?: boolean }): Promise<CreateSingboxNodeResponse> {
    return request("/admin/singbox/nodes", { method: "POST", body: JSON.stringify(data ?? {}), token });
  },

  async getSingboxNode(token: string, id: string): Promise<SingboxNodeDetail> {
    return request(`/admin/singbox/nodes/${id}`, { token });
  },

  async updateSingboxNode(
    token: string,
    id: string,
    data: {
      name?: string;
      status?: string;
      capacity?: number | null;
      port?: number;
      protocol?: string;
      tlsEnabled?: boolean;
      customConfigJson?: string | null;
    }
  ): Promise<unknown> {
    return request(`/admin/singbox/nodes/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async deleteSingboxNode(token: string, id: string): Promise<void> {
    return request(`/admin/singbox/nodes/${id}`, { method: "DELETE", token });
  },

  async getSingboxCategories(token: string): Promise<{ items: SingboxCategoryItem[] }> {
    return request("/admin/singbox/categories", { token });
  },

  async createSingboxCategory(token: string, data: { name: string; sortOrder?: number }): Promise<{ id: string; name: string; sortOrder: number }> {
    return request("/admin/singbox/categories", { method: "POST", body: JSON.stringify(data), token });
  },

  async updateSingboxCategory(token: string, id: string, data: { name?: string; sortOrder?: number }): Promise<unknown> {
    return request(`/admin/singbox/categories/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async deleteSingboxCategory(token: string, id: string): Promise<void> {
    return request(`/admin/singbox/categories/${id}`, { method: "DELETE", token });
  },

  async getSingboxTariffs(token: string, categoryId?: string): Promise<{ items: SingboxTariffListItem[] }> {
    const q = categoryId ? `?categoryId=${encodeURIComponent(categoryId)}` : "";
    return request(`/admin/singbox/tariffs${q}`, { token });
  },

  async createSingboxTariff(
    token: string,
    data: { categoryId: string; name: string; slotCount: number; durationDays: number; trafficLimitBytes?: string | number | null; price: number; currency: string; sortOrder?: number; enabled?: boolean }
  ): Promise<unknown> {
    return request("/admin/singbox/tariffs", { method: "POST", body: JSON.stringify(data), token });
  },

  async updateSingboxTariff(
    token: string,
    id: string,
    data: { categoryId?: string; name?: string; slotCount?: number; durationDays?: number; trafficLimitBytes?: string | number | null; price?: number; currency?: string; sortOrder?: number; enabled?: boolean }
  ): Promise<unknown> {
    return request(`/admin/singbox/tariffs/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async deleteSingboxTariff(token: string, id: string): Promise<void> {
    return request(`/admin/singbox/tariffs/${id}`, { method: "DELETE", token });
  },

  /** Скачивает CSV со списком прокси-слотов. */
  async downloadProxySlotsCsv(token: string): Promise<void> {
    const res = await fetch(`${API_BASE}/admin/proxy/slots/export?format=csv`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) throw new Error(res.statusText || "Export failed");
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "proxy-slots.csv";
    a.click();
    URL.revokeObjectURL(url);
  },

  async getClients(
    token: string,
    page = 1,
    limit = 20,
    params?: { search?: string; isBlocked?: boolean }
  ): Promise<{ items: ClientRecord[]; total: number; page: number; limit: number }> {
    const sp = new URLSearchParams({ page: String(page), limit: String(limit) });
    if (params?.search?.trim()) sp.set("search", params.search.trim());
    if (params?.isBlocked === true) sp.set("isBlocked", "true");
    if (params?.isBlocked === false) sp.set("isBlocked", "false");
    return request(`/admin/clients?${sp.toString()}`, { token });
  },

  async getClient(token: string, id: string): Promise<ClientRecord> {
    return request(`/admin/clients/${id}`, { token });
  },

  async updateClient(token: string, id: string, data: UpdateClientPayload): Promise<ClientRecord> {
    return request(`/admin/clients/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async setClientPassword(token: string, clientId: string, newPassword: string): Promise<{ success: boolean; message?: string }> {
    return request(`/admin/clients/${clientId}/password`, {
      method: "PATCH",
      body: JSON.stringify({ newPassword }),
      token,
    });
  },

  async deleteClient(token: string, id: string): Promise<{ success: boolean }> {
    return request(`/admin/clients/${id}`, { method: "DELETE", token });
  },

  async getClientRemna(token: string, clientId: string): Promise<unknown> {
    return request(`/admin/clients/${clientId}/remna`, { token });
  },

  async updateClientRemna(token: string, clientId: string, data: UpdateClientRemnaPayload): Promise<unknown> {
    return request(`/admin/clients/${clientId}/remna`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async clientRemnaRevokeSubscription(token: string, clientId: string): Promise<unknown> {
    return request(`/admin/clients/${clientId}/remna/revoke-subscription`, { method: "POST", token });
  },

  async clientRemnaDisable(token: string, clientId: string): Promise<unknown> {
    return request(`/admin/clients/${clientId}/remna/disable`, { method: "POST", token });
  },

  async clientRemnaEnable(token: string, clientId: string): Promise<unknown> {
    return request(`/admin/clients/${clientId}/remna/enable`, { method: "POST", token });
  },

  async clientRemnaResetTraffic(token: string, clientId: string): Promise<unknown> {
    return request(`/admin/clients/${clientId}/remna/reset-traffic`, { method: "POST", token });
  },

  async clientRemnaSquadAdd(token: string, clientId: string, squadUuid: string): Promise<unknown> {
    return request(`/admin/clients/${clientId}/remna/squads/add`, { method: "POST", body: JSON.stringify({ squadUuid }), token });
  },

  async clientRemnaSquadRemove(token: string, clientId: string, squadUuid: string): Promise<unknown> {
    return request(`/admin/clients/${clientId}/remna/squads/remove`, { method: "POST", body: JSON.stringify({ squadUuid }), token });
  },

  async getRemnaSubscriptionTemplates(token: string): Promise<unknown> {
    return request("/admin/remna/subscription-templates", { token });
  },

  async getRemnaSquadsInternal(token: string): Promise<unknown> {
    return request("/admin/remna/squads/internal", { token });
  },

  async getSettings(token: string): Promise<AdminSettings> {
    return request("/admin/settings", { token });
  },

  async getReferralNetwork(token: string): Promise<{
    nodes: Array<{
      id: string;
      name: string;
      status: string;
      referralsCount: number;
      subscriptionIncome: number;
      referralIncome: number;
      campaign: string | null;
    }>;
    links: Array<{ source: string; target: string }>;
    stats: {
      totalUsers: number;
      totalReferrers: number;
      totalCampaigns: number;
      totalSubscriptionIncome: number;
      totalReferralIncome: number;
    };
  }> {
    return request("/admin/referrals/network", { token });
  },

  async getTrafficAbuseAnalytics(
    token: string,
    params?: { days?: number; threshold?: number; minBytes?: number }
  ): Promise<TrafficAbuseResponse> {
    const qs = new URLSearchParams();
    if (params?.days) qs.set("days", String(params.days));
    if (params?.threshold) qs.set("threshold", String(params.threshold));
    if (params?.minBytes) qs.set("minBytes", String(params.minBytes));
    const q = qs.toString();
    return request(`/admin/traffic-abuse/analytics${q ? `?${q}` : ""}`, { token });
  },

  async getApiKeys(token: string): Promise<ApiKeyListItem[]> {
    return request("/admin/api-keys", { token });
  },
  async createApiKey(token: string, data: { name: string; description?: string }): Promise<ApiKeyCreated> {
    return request("/admin/api-keys", { method: "POST", body: JSON.stringify(data), token });
  },
  async toggleApiKey(token: string, id: string, isActive: boolean): Promise<void> {
    return request(`/admin/api-keys/${id}/toggle`, { method: "PATCH", body: JSON.stringify({ isActive }), token });
  },
  async deleteApiKey(token: string, id: string): Promise<void> {
    return request(`/admin/api-keys/${id}`, { method: "DELETE", token });
  },

  async getAdmins(token: string): Promise<AdminListItem[]> {
    return request("/admin/admins", { token });
  },
  async createManager(token: string, data: { email: string; password: string; allowedSections: string[] }): Promise<AdminListItem> {
    return request("/admin/admins", { method: "POST", body: JSON.stringify(data), token });
  },
  async updateManager(token: string, id: string, data: { allowedSections?: string[]; password?: string }): Promise<AdminListItem> {
    return request(`/admin/admins/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },
  async deleteManager(token: string, id: string): Promise<{ success: boolean }> {
    return request(`/admin/admins/${id}`, { method: "DELETE", token });
  },

  /** Конкурсы: список */
  async getContests(token: string): Promise<ContestListItem[]> {
    return request("/admin/contests", { token });
  },
  /** Конкурсы: один */
  async getContest(token: string, id: string): Promise<ContestDetail> {
    return request(`/admin/contests/${id}`, { token });
  },
  /** Конкурсы: создать */
  async createContest(token: string, data: ContestFormPayload): Promise<ContestDetail> {
    return request("/admin/contests", { method: "POST", body: JSON.stringify(data), token });
  },
  /** Конкурсы: обновить */
  async updateContest(token: string, id: string, data: Partial<ContestFormPayload>): Promise<ContestDetail> {
    return request(`/admin/contests/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },
  /** Конкурсы: сменить статус */
  async patchContestStatus(token: string, id: string, status: "draft" | "active" | "ended"): Promise<ContestDetail> {
    return request(`/admin/contests/${id}/status`, { method: "PATCH", body: JSON.stringify({ status }), token });
  },
  /** Конкурсы: превью участников */
  async getContestParticipantsPreview(token: string, id: string): Promise<{ total: number; participants: { clientId: string; totalDaysBought: number; paymentsCount: number; referralsCount?: number }[] }> {
    return request(`/admin/contests/${id}/participants-preview`, { token });
  },
  /** Конкурсы: запустить (отправить уведомление всем и выставить статус «Активен») */
  async launchContest(token: string, id: string): Promise<{ message: string; sent?: number; errors?: number }> {
    return request(`/admin/contests/${id}/launch`, { method: "POST", token });
  },
  /** Конкурсы: провести розыгрыш */
  async runContestDraw(token: string, id: string): Promise<{ message: string; winners: unknown[] }> {
    return request(`/admin/contests/${id}/draw`, { method: "POST", token });
  },
  /** Конкурсы: удалить */
  async deleteContest(token: string, id: string): Promise<void> {
    return request(`/admin/contests/${id}`, { method: "DELETE", token });
  },

  /** Базовый конфиг страницы подписки для визуального редактора (subpage-*.json) */
  async getDefaultSubscriptionPageConfig(token: string): Promise<SubscriptionPageConfig | null> {
    return request("/admin/default-subscription-page-config", { token });
  },

  async updateSettings(token: string, data: UpdateSettingsPayload): Promise<AdminSettings> {
    return request("/admin/settings", { method: "PATCH", body: JSON.stringify(data), token });
  },

  /** Админ: сброс текстов лендинга на исходные (из кода). Возвращает обновлённые настройки. */
  async resetLandingText(token: string): Promise<AdminSettings> {
    return request("/admin/settings/reset-landing-text", { method: "POST", token });
  },

  /** Админ: список тикетов (опционально ?status=open|closed) */
  async getAdminTickets(token: string, status?: "open" | "closed"): Promise<{
    items: { id: string; subject: string; status: string; createdAt: string; updatedAt: string; client: { id: string; email: string | null; telegramUsername: string | null } }[];
  }> {
    const q = status ? `?status=${status}` : "";
    return request(`/admin/tickets${q}`, { token });
  },
  /** Админ: один тикет с сообщениями */
  async getAdminTicket(token: string, id: string): Promise<{
    id: string;
    subject: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    client: { id: string; email: string | null; telegramUsername: string | null };
    messages: { id: string; authorType: string; content: string; createdAt: string }[];
  }> {
    return request(`/admin/tickets/${id}`, { token });
  },
  /** Админ: закрыть/открыть тикет */
  async patchAdminTicket(token: string, id: string, data: { status: "open" | "closed" }): Promise<{ id: string; status: string }> {
    return request(`/admin/tickets/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },
  /** Админ: ответ в тикет (поддержка) */
  async postAdminTicketMessage(
    token: string,
    ticketId: string,
    data: { content: string }
  ): Promise<{ id: string; authorType: string; content: string; createdAt: string }> {
    return request(`/admin/tickets/${ticketId}/messages`, { method: "POST", body: JSON.stringify(data), token });
  },

  async syncFromRemna(token: string): Promise<SyncResult> {
    return request("/admin/sync/from-remna", { method: "POST", token });
  },

  async syncToRemna(token: string): Promise<SyncToRemnaResult> {
    return request("/admin/sync/to-remna", { method: "POST", token });
  },

  async syncCreateRemnaForMissing(token: string): Promise<SyncCreateRemnaForMissingResult> {
    return request("/admin/sync/create-remna-for-missing", { method: "POST", token });
  },

  /** Количество получателей рассылки (с Telegram / с email) */
  async broadcastRecipientsCount(token: string): Promise<{ withTelegram: number; withEmail: number }> {
    return request("/admin/broadcast/recipients-count", { token });
  },

  /** Запустить рассылку (опционально — изображение или файл вложения). */
  async broadcast(
    token: string,
    body: { channel: "telegram" | "email" | "both"; subject?: string; message: string; buttonText?: string; buttonUrl?: string },
    attachment?: File | null
  ): Promise<BroadcastResult> {
    const form = new FormData();
    form.append("channel", body.channel);
    form.append("message", body.message);
    if (body.subject != null && body.subject !== "") form.append("subject", body.subject);
    if (body.buttonText?.trim()) form.append("buttonText", body.buttonText.trim());
    if (body.buttonUrl?.trim()) form.append("buttonUrl", body.buttonUrl.trim());
    if (attachment) form.append("attachment", attachment, attachment.name);
    const headers = new Headers();
    headers.set("Authorization", `Bearer ${token}`);
    const res = await fetch(`${API_BASE}/admin/broadcast`, { method: "POST", headers, body: form });
    const text = await res.text();
    let data: unknown;
    try {
      data = text ? JSON.parse(text) : undefined;
    } catch {
      throw new Error(res.statusText || "Request failed");
    }
    if (res.status === 401 && token && tokenRefreshFn && !res.url.includes("/auth/")) {
      const newToken = await tokenRefreshFn();
      if (newToken) return api.broadcast(newToken, body, attachment);
    }
    if (!res.ok) {
      const message = (data as { message?: string })?.message ?? res.statusText;
      throw new Error(message);
    }
    return data as BroadcastResult;
  },

  /** Авто-рассылка: список правил */
  async getAutoBroadcastRules(token: string): Promise<AutoBroadcastRule[]> {
    return request("/admin/auto-broadcast/rules", { token });
  },

  /** Количество получателей для правила (ещё не получали) */
  async getAutoBroadcastEligibleCount(token: string, ruleId: string): Promise<{ count: number }> {
    return request(`/admin/auto-broadcast/rules/${ruleId}/eligible-count`, { token });
  },

  /** Создать правило авто-рассылки */
  async createAutoBroadcastRule(token: string, data: AutoBroadcastRulePayload): Promise<AutoBroadcastRule> {
    return request("/admin/auto-broadcast/rules", { method: "POST", body: JSON.stringify(data), token });
  },

  /** Обновить правило */
  async updateAutoBroadcastRule(token: string, id: string, data: Partial<AutoBroadcastRulePayload>): Promise<AutoBroadcastRule> {
    return request(`/admin/auto-broadcast/rules/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  /** Удалить правило */
  async deleteAutoBroadcastRule(token: string, id: string): Promise<void> {
    return request(`/admin/auto-broadcast/rules/${id}`, { method: "DELETE", token });
  },

  /** Запустить все правила сейчас */
  async runAutoBroadcastAll(token: string): Promise<{ results: RunRuleResult[] }> {
    return request("/admin/auto-broadcast/run", { method: "POST", token });
  },

  /** Запустить одно правило сейчас */
  async runAutoBroadcastRule(token: string, ruleId: string): Promise<RunRuleResult> {
    return request(`/admin/auto-broadcast/run/${ruleId}`, { method: "POST", token });
  },

  /** Создать бэкап БД (скачать SQL) */
  async createBackup(token: string): Promise<{ blob: Blob; filename: string }> {
    const headers = new Headers();
    headers.set("Authorization", `Bearer ${token}`);
    const res = await fetch(`${API_BASE}/admin/backup/create`, { headers });
    if (res.status === 401 && token && tokenRefreshFn) {
      const newToken = await tokenRefreshFn();
      if (newToken) return api.createBackup(newToken);
    }
    if (!res.ok) {
      const text = await res.text();
      let msg = res.statusText;
      try {
        const d = JSON.parse(text);
        if (d.message) msg = d.message;
      } catch {
        // ignore
      }
      throw new Error(msg);
    }
    const blob = await res.blob();
    const disposition = res.headers.get("Content-Disposition") || "";
    const match = /filename="?([^";]+)"?/.exec(disposition);
    const filename = match ? match[1].trim() : `stealthnet-backup-${new Date().toISOString().slice(0, 10)}.sql`;
    return { blob, filename };
  },

  /** Список сохранённых на сервере бэкапов */
  async getBackupList(token: string): Promise<{ items: { path: string; filename: string; date: string; size: number }[] }> {
    return request("/admin/backup/list", { token });
  },

  /** Скачать бэкап с сервера по пути (path из списка) */
  async downloadBackup(token: string, path: string): Promise<{ blob: Blob; filename: string }> {
    const headers = new Headers();
    headers.set("Authorization", `Bearer ${token}`);
    const res = await fetch(`${API_BASE}/admin/backup/download?path=${encodeURIComponent(path)}`, { headers });
    if (res.status === 401 && token && tokenRefreshFn) {
      const newToken = await tokenRefreshFn();
      if (newToken) return api.downloadBackup(newToken, path);
    }
    if (!res.ok) {
      const text = await res.text();
      let msg = res.statusText;
      try {
        const d = JSON.parse(text);
        if (d.message) msg = d.message;
      } catch {
        // ignore
      }
      throw new Error(msg);
    }
    const blob = await res.blob();
    const disposition = res.headers.get("Content-Disposition") || "";
    const match = /filename="?([^";]+)"?/.exec(disposition);
    const filename = match ? match[1].trim() : path.split("/").pop() || "backup.sql";
    return { blob, filename };
  },

  /** Восстановить БД из бэкапа на сервере (path из списка) */
  async restoreBackupFromServer(token: string, path: string): Promise<{ message: string }> {
    return request("/admin/backup/restore", {
      method: "POST",
      body: JSON.stringify({ confirm: "RESTORE", path }),
      token,
    });
  },

  /** Восстановить БД из загруженного SQL-файла */
  async restoreBackup(token: string, file: File): Promise<{ message: string }> {
    const form = new FormData();
    form.append("file", file);
    form.append("confirm", "RESTORE");
    const headers = new Headers();
    headers.set("Authorization", `Bearer ${token}`);
    const res = await fetch(`${API_BASE}/admin/backup/restore`, { method: "POST", body: form, headers });
    const text = await res.text();
    let data: unknown;
    try {
      data = text ? JSON.parse(text) : undefined;
    } catch {
      throw new Error(res.statusText || "Request failed");
    }
    if (res.status === 401 && token && tokenRefreshFn) {
      const newToken = await tokenRefreshFn();
      if (newToken) return api.restoreBackup(newToken, file);
    }
    if (!res.ok) {
      const message = (data as { message?: string })?.message ?? res.statusText;
      throw new Error(message);
    }
    return data as { message: string };
  },

  async getTariffCategories(token: string): Promise<{ items: TariffCategoryWithTariffs[] }> {
    return request("/admin/tariff-categories", { token });
  },

  async createTariffCategory(token: string, data: { name: string; sortOrder?: number; emojiKey?: string | null }): Promise<TariffCategoryRecord> {
    return request("/admin/tariff-categories", { method: "POST", body: JSON.stringify(data), token });
  },

  async updateTariffCategory(token: string, id: string, data: { name?: string; sortOrder?: number; emojiKey?: string | null }): Promise<TariffCategoryRecord> {
    return request(`/admin/tariff-categories/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async deleteTariffCategory(token: string, id: string): Promise<{ success: boolean }> {
    return request(`/admin/tariff-categories/${id}`, { method: "DELETE", token });
  },

  async getTariffs(token: string, categoryId?: string): Promise<{ items: TariffRecord[] }> {
    const q = categoryId ? `?categoryId=${encodeURIComponent(categoryId)}` : "";
    return request(`/admin/tariffs${q}`, { token });
  },

  async createTariff(token: string, data: CreateTariffPayload): Promise<TariffRecord> {
    return request("/admin/tariffs", { method: "POST", body: JSON.stringify(data), token });
  },

  async updateTariff(token: string, id: string, data: UpdateTariffPayload): Promise<TariffRecord> {
    return request(`/admin/tariffs/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async deleteTariff(token: string, id: string): Promise<{ success: boolean }> {
    return request(`/admin/tariffs/${id}`, { method: "DELETE", token });
  },

  // ——— Кабинет клиента (клиентский API) ———
  async clientLogin(email: string, password: string): Promise<ClientAuthResponse | ClientAuthRequires2FA> {
    return request("/client/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
  },

  async clientRegister(data: ClientRegisterPayload): Promise<ClientAuthResponse | ClientAuthRequires2FA | { message: string; requiresVerification: true }> {
    return request("/client/auth/register", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },

  async clientVerifyEmail(token: string): Promise<ClientAuthResponse | ClientAuthRequires2FA> {
    return request("/client/auth/verify-email", {
      method: "POST",
      body: JSON.stringify({ token }),
    });
  },

  /** Авторизация по initData из Telegram Mini App (Web App) */
  async clientAuthByTelegramMiniapp(initData: string): Promise<ClientAuthResponse | ClientAuthRequires2FA> {
    return request("/client/auth/telegram-miniapp", {
      method: "POST",
      body: JSON.stringify({ initData }),
    });
  },
  async clientGoogleAuth(idToken: string): Promise<ClientAuthResponse | ClientAuthRequires2FA> {
    return request("/client/auth/google", {
      method: "POST",
      body: JSON.stringify({ idToken }),
    });
  },

  async clientAppleAuth(idToken: string): Promise<ClientAuthResponse | ClientAuthRequires2FA> {
    return request("/client/auth/apple", {
      method: "POST",
      body: JSON.stringify({ idToken }),
    });
  },

  /** Генерация одноразового токена для deep-link авторизации через Telegram */
  async clientTelegramLoginToken(): Promise<{ token: string; expiresAt: string }> {
    return request("/client/auth/telegram-login-token", { method: "POST" });
  },

  /** Проверка статуса deep-link авторизации (поллинг) */
  async clientTelegramLoginCheck(token: string): Promise<(ClientAuthResponse & { confirmed: true }) | (ClientAuthRequires2FA & { confirmed: true }) | { confirmed: false }> {
    return request(`/client/auth/telegram-login-check?token=${encodeURIComponent(token)}`);
  },

  /** Обмен временного токена (после пароля/Telegram) на полный токен по коду 2FA */
  async client2FALogin(tempToken: string, code: string): Promise<ClientAuthResponse> {
    return request("/client/auth/2fa-login", {
      method: "POST",
      body: JSON.stringify({ tempToken, code }),
    });
  },

  async clientMe(token: string): Promise<ClientProfile> {
    return request("/client/auth/me", { token });
  },

  async clientSubscription(token: string): Promise<{ subscription: unknown; tariffDisplayName?: string | null; message?: string }> {
    return request("/client/subscription", { token });
  },

  async clientPayments(token: string): Promise<{ items: ClientPayment[] }> {
    return request("/client/payments", { token });
  },

  /** Список устройств (HWID) пользователя в Remna */
  async getClientDevices(token: string): Promise<{ total: number; devices: { hwid: string; platform?: string; deviceModel?: string; createdAt?: string }[] }> {
    return request("/client/devices", { token });
  },

  /** Удалить устройство по HWID */
  async deleteClientDevice(token: string, hwid: string): Promise<{ ok: boolean; message?: string }> {
    return request("/client/devices/delete", { method: "POST", body: JSON.stringify({ hwid }), token });
  },

  /** Запуск настройки 2FA: возвращает secret и otpauthUrl для QR */
  async client2FASetup(token: string): Promise<{ secret: string; otpauthUrl: string }> {
    return request("/client/2fa/setup", { method: "POST", token });
  },
  /** Подтвердить включение 2FA кодом из приложения */
  async client2FAConfirm(token: string, code: string): Promise<{ message: string }> {
    return request("/client/2fa/confirm", { method: "POST", body: JSON.stringify({ code }), token });
  },
  /** Отключить 2FA (требуется код из приложения) */
  async client2FADisable(token: string, code: string): Promise<{ message: string }> {
    return request("/client/2fa/disable", { method: "POST", body: JSON.stringify({ code }), token });
  },

  async clientCreatePlategaPayment(
    token: string,
    data: {
      amount?: number;
      currency?: string;
      paymentMethod: number;
      description?: string;
      tariffId?: string;
      proxyTariffId?: string;
      singboxTariffId?: string;
      promoCode?: string;
      extraOption?: { kind: "traffic" | "devices" | "servers"; productId: string };
      customBuild?: { days: number; devices: number; trafficGb?: number };
    }
  ): Promise<{ paymentUrl: string; orderId: string; paymentId: string; discountApplied?: boolean; finalAmount?: number }> {
    return request("/client/payments/platega", { method: "POST", body: JSON.stringify(data), token });
  },

  async getPublicTariffs(): Promise<{ items: PublicTariffCategory[] }> {
    return request("/public/tariffs");
  },

  /** Публичный список тарифов прокси по категориям */
  async getPublicProxyTariffs(): Promise<{
    items: { id: string; name: string; sortOrder: number; tariffs: { id: string; name: string; proxyCount: number; durationDays: number; trafficLimitBytes: string | null; connectionLimit: number | null; price: number; currency: string }[] }[];
  }> {
    return request("/public/proxy-tariffs");
  },

  /** Публичный список тарифов Sing-box по категориям */
  async getPublicSingboxTariffs(): Promise<{
    items: { id: string; name: string; sortOrder: number; tariffs: { id: string; name: string; slotCount: number; durationDays: number; trafficLimitBytes: string | null; price: number; currency: string }[] }[];
  }> {
    return request("/public/singbox-tariffs");
  },

  /** Активные прокси-слоты клиента */
  async getProxySlots(token: string): Promise<{
    slots: { id: string; login: string; password: string; host: string; socksPort: number; httpPort: number; expiresAt: string; trafficLimitBytes: string | null; trafficUsedBytes: string; connectionLimit: number | null }[];
  }> {
    return request("/client/proxy-slots", { token });
  },

  /** Активные Sing-box слоты клиента (с ссылкой подписки) */
  async getSingboxSlots(token: string): Promise<{
    slots: { id: string; subscriptionLink: string; expiresAt: string; trafficLimitBytes: string | null; trafficUsedBytes: string; protocol: string }[];
  }> {
    return request("/client/singbox-slots", { token });
  },

  async getPublicConfig(): Promise<PublicConfig> {
    return request("/public/config");
  },

  /** Конфиг страницы подписки (приложения по платформам) для /cabinet/subscribe */
  async getPublicSubscriptionPageConfig(): Promise<SubscriptionPageConfig | null> {
    return request("/public/subscription-page");
  },

  async clientPayByBalance(
    token: string,
    data: { tariffId?: string; proxyTariffId?: string; singboxTariffId?: string; promoCode?: string }
  ): Promise<{ message: string; paymentId: string; newBalance: number }> {
    return request("/client/payments/balance", { method: "POST", body: JSON.stringify(data), token });
  },

  /** Оплата опции (доп. трафик/устройства/сервер) с баланса */
  async clientPayOptionByBalance(
    token: string,
    data: { extraOption: { kind: "traffic" | "devices" | "servers"; productId: string } }
  ): Promise<{ message: string; paymentId: string; newBalance: number }> {
    return request("/client/payments/balance/option", { method: "POST", body: JSON.stringify(data), token });
  },

  /** Оплата гибкого тарифа (собери сам) с баланса */
  async customBuildPayBalance(
    token: string,
    data: { days: number; devices: number; trafficGb?: number; promoCode?: string }
  ): Promise<{ message: string; paymentId: string; newBalance: number }> {
    return request("/client/custom-build/pay-balance", { method: "POST", body: JSON.stringify(data), token });
  },

  async getYoomoneyAuthUrl(token: string): Promise<{ url: string }> {
    return request("/client/yoomoney/auth-url", { token });
  },
  /** Форма перевода ЮMoney (оплата картой). Пополнение баланса, тариф, прокси, доступы, опция или гибкий тариф. */
  async yoomoneyCreateFormPayment(
    token: string,
    data: {
      amount?: number;
      paymentType: "PC" | "AC";
      tariffId?: string;
      proxyTariffId?: string;
      singboxTariffId?: string;
      promoCode?: string;
      extraOption?: { kind: "traffic" | "devices" | "servers"; productId: string };
      customBuild?: { days: number; devices: number; trafficGb?: number };
    }
  ): Promise<{ paymentId: string; paymentUrl: string; form: { receiver: string; sum: number; label: string; paymentType: string; successURL: string }; successURL: string }> {
    return request("/client/yoomoney/create-form-payment", { method: "POST", body: JSON.stringify(data), token });
  },
  async yoomoneyFormPaymentParams(token: string, paymentId: string): Promise<{ receiver: string; sum: number; label: string; paymentType: string; successURL: string }> {
    return request(`/client/yoomoney/form-payment/${encodeURIComponent(paymentId)}`, { token });
  },
  async yoomoneyRequestTopup(token: string, amount: number): Promise<{ paymentId: string; request_id: string; money_source: Record<string, unknown>; contract_amount?: number }> {
    return request("/client/yoomoney/request-topup", { method: "POST", body: JSON.stringify({ amount }), token });
  },
  async yoomoneyProcessPayment(
    token: string,
    data: { paymentId: string; request_id: string; money_source?: string; csc?: string }
  ): Promise<{ message: string; newBalance: number }> {
    return request("/client/yoomoney/process-payment", { method: "POST", body: JSON.stringify(data), token });
  },

  /** ЮKassa API: создание платежа (тариф, прокси, гибкий тариф или пополнение), возвращает confirmationUrl для редиректа. */
  async yookassaCreatePayment(
    token: string,
    data: {
      amount?: number;
      currency?: string;
      tariffId?: string;
      proxyTariffId?: string;
      singboxTariffId?: string;
      promoCode?: string;
      extraOption?: { kind: "traffic" | "devices" | "servers"; productId: string };
      customBuild?: { days: number; devices: number; trafficGb?: number };
    }
  ): Promise<{ paymentId: string; confirmationUrl: string; yookassaPaymentId: string }> {
    return request("/client/yookassa/create-payment", { method: "POST", body: JSON.stringify(data), token });
  },

  /** ЮKassa: отвязка сохранённого способа оплаты */
  async yookassaUnlinkPaymentMethod(token: string): Promise<{ client: ClientProfile }> {
    return request("/client/yookassa/unlink-payment-method", { method: "POST", token });
  },

  /** Crypto Pay (Crypto Bot) — создание инвойса, возвращает ссылку на оплату */
  async cryptopayCreatePayment(
    token: string,
    data: {
      amount?: number;
      currency?: string;
      tariffId?: string;
      proxyTariffId?: string;
      singboxTariffId?: string;
      promoCode?: string;
      extraOption?: { kind: "traffic" | "devices" | "servers"; productId: string };
      customBuild?: { days: number; devices: number; trafficGb?: number };
    }
  ): Promise<{ paymentId: string; payUrl: string; miniAppPayUrl?: string; webAppPayUrl?: string }> {
    return request("/client/cryptopay/create-payment", { method: "POST", body: JSON.stringify(data), token });
  },

  /** Heleket — создание инвойса (крипто), возвращает ссылку на оплату */
  async heleketCreatePayment(
    token: string,
    data: {
      amount?: number;
      currency?: string;
      tariffId?: string;
      proxyTariffId?: string;
      singboxTariffId?: string;
      promoCode?: string;
      extraOption?: { kind: "traffic" | "devices" | "servers"; productId: string };
      customBuild?: { days: number; devices: number; trafficGb?: number };
    }
  ): Promise<{ paymentId: string; payUrl: string }> {
    return request("/client/heleket/create-payment", { method: "POST", body: JSON.stringify(data), token });
  },

  async clientActivateTrial(token: string): Promise<{ message: string; client: ClientProfile | null }> {
    return request("/client/trial", { method: "POST", token });
  },

  async clientUpdateProfile(token: string, data: { preferredLang?: string; preferredCurrency?: string }): Promise<ClientProfile> {
    return request("/client/profile", { method: "PATCH", body: JSON.stringify(data), token });
  },

  async clientUpdateAutoRenew(token: string, data: { enabled?: boolean; tariffId?: string | null }): Promise<ClientProfile> {
    return request("/client/auto-renew", { method: "PATCH", body: JSON.stringify(data), token });
  },

  async clientChangePassword(token: string, data: { currentPassword: string; newPassword: string }): Promise<{ message: string }> {
    return request("/client/change-password", { method: "POST", body: JSON.stringify(data), token });
  },

  async clientSetPassword(token: string, data: { newPassword: string }): Promise<{ message: string }> {
    return request("/client/set-password", { method: "POST", body: JSON.stringify(data), token });
  },

  /** Запросить код для привязки Telegram через бота (без авторизации по токену не нужен) */
  async clientLinkTelegramRequest(token: string): Promise<{ code: string; expiresAt: string; botUsername: string | null }> {
    return request("/client/link-telegram-request", { method: "POST", token });
  },

  /** Привязать Telegram из Mini App (initData от Telegram WebApp) */
  async clientLinkTelegram(token: string, data: { initData: string }): Promise<{ client: ClientProfile }> {
    return request("/client/link-telegram", { method: "POST", body: JSON.stringify(data), token });
  },

  /** Запросить привязку email (отправить письмо со ссылкой) */
  async clientLinkEmailRequest(token: string, data: { email: string }): Promise<{ message: string }> {
    return request("/client/link-email-request", { method: "POST", body: JSON.stringify(data), token });
  },

  /** Подтвердить привязку email по токену из письма (без Bearer; возвращает token и client) */
  async clientVerifyLinkEmail(verificationToken: string): Promise<ClientAuthResponse | ClientAuthRequires2FA> {
    return request("/client/auth/verify-link-email", { method: "POST", body: JSON.stringify({ token: verificationToken }) });
  },

  async getClientReferralStats(token: string): Promise<ClientReferralStats> {
    return request("/client/referral-stats", { token });
  },

  /** Список тикетов клиента (доступно при включённой тикет-системе) */
  async getTickets(token: string): Promise<{ items: { id: string; subject: string; status: string; createdAt: string; updatedAt: string }[] }> {
    return request("/client/tickets", { token });
  },
  /** Количество непрочитанных сообщений от поддержки */
  async getUnreadTicketsCount(token: string): Promise<{ count: number }> {
    return request("/client/tickets/unread-count", { token });
  },
  /** Один тикет с сообщениями */
  async getTicket(token: string, id: string): Promise<{
    id: string;
    subject: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    messages: { id: string; authorType: string; content: string; createdAt: string }[];
  }> {
    return request(`/client/tickets/${id}`, { token });
  },
  /** Создать тикет (тема + первое сообщение) */
  async createTicket(
    token: string,
    data: { subject: string; message: string }
  ): Promise<{
    id: string;
    subject: string;
    status: string;
    createdAt: string;
    updatedAt: string;
    messages: { id: string; authorType: string; content: string; createdAt: string }[];
  }> {
    return request("/client/tickets", { method: "POST", body: JSON.stringify(data), token });
  },
  /** Ответ в тикет */
  async replyTicket(
    token: string,
    ticketId: string,
    data: { content: string }
  ): Promise<{ id: string; authorType: string; content: string; createdAt: string }> {
    return request(`/client/tickets/${ticketId}/messages`, { method: "POST", body: JSON.stringify(data), token });
  },

  /** AI Чат (Groq) */
  async chatAi(
    token: string,
    data: { messages: { role: "user" | "assistant" | "system"; content: string }[] }
  ): Promise<{ reply: string }> {
    return request("/client/ai/chat", { method: "POST", body: JSON.stringify(data), token });
  },

  // ——— Промо-группы (админ) ———
  async getPromoGroups(token: string): Promise<PromoGroup[]> {
    return request("/admin/promo-groups", { token });
  },

  async getPromoGroup(token: string, id: string): Promise<PromoGroupDetail> {
    return request(`/admin/promo-groups/${id}`, { token });
  },

  async createPromoGroup(token: string, data: CreatePromoGroupPayload): Promise<PromoGroup> {
    return request("/admin/promo-groups", { method: "POST", body: JSON.stringify(data), token });
  },

  async updatePromoGroup(token: string, id: string, data: UpdatePromoGroupPayload): Promise<PromoGroup> {
    return request(`/admin/promo-groups/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async deletePromoGroup(token: string, id: string): Promise<{ ok: boolean }> {
    return request(`/admin/promo-groups/${id}`, { method: "DELETE", token });
  },

  // ——— Промокоды (админ) ———
  async getPromoCodes(token: string): Promise<PromoCodeRecord[]> {
    return request("/admin/promo-codes", { token });
  },

  async getPromoCode(token: string, id: string): Promise<PromoCodeDetail> {
    return request(`/admin/promo-codes/${id}`, { token });
  },

  async createPromoCode(token: string, data: CreatePromoCodePayload): Promise<PromoCodeRecord> {
    return request("/admin/promo-codes", { method: "POST", body: JSON.stringify(data), token });
  },

  async updatePromoCode(token: string, id: string, data: UpdatePromoCodePayload): Promise<PromoCodeRecord> {
    return request(`/admin/promo-codes/${id}`, { method: "PATCH", body: JSON.stringify(data), token });
  },

  async deletePromoCode(token: string, id: string): Promise<{ ok: boolean }> {
    return request(`/admin/promo-codes/${id}`, { method: "DELETE", token });
  },

  // ——— Промокоды (клиент) ———
  async clientCheckPromoCode(token: string, code: string): Promise<{ type: string; discountPercent?: number | null; discountFixed?: number | null; durationDays?: number | null; name: string }> {
    return request("/client/promo-code/check", { method: "POST", body: JSON.stringify({ code }), token });
  },

  async clientActivatePromoCode(token: string, code: string): Promise<{ message: string }> {
    return request("/client/promo-code/activate", { method: "POST", body: JSON.stringify({ code }), token });
  },

  // ——— Geo Map ———
  async getGeoMapData(token: string): Promise<GeoMapResponse> {
    return request("/admin/geo-map/data", { token });
  },
  async refreshGeoMap(token: string): Promise<GeoMapResponse> {
    return request("/admin/geo-map/refresh", { method: "POST", token });
  },
};

export interface ClientReferralStats {
  referralCode: string | null;
  referralPercent: number;
  referralPercentLevel2: number;
  referralPercentLevel3: number;
  referralCount: number;
  totalEarnings: number;
}

export interface SyncResult {
  ok: boolean;
  created: number;
  updated: number;
  skipped: number;
  errors: string[];
}

export interface SyncToRemnaResult {
  ok: boolean;
  updated: number;
  unlinked: number;
  errors: string[];
}

export interface SyncCreateRemnaForMissingResult {
  ok: boolean;
  created: number;
  linked: number;
  errors: string[];
}

export interface BroadcastResult {
  ok: boolean;
  sentTelegram: number;
  sentEmail: number;
  failedTelegram: number;
  failedEmail: number;
  errors: string[];
}

export type AutoBroadcastTriggerType =
  | "after_registration"
  | "inactivity"
  | "no_payment"
  | "trial_not_connected"
  | "trial_used_never_paid"
  | "no_traffic"
  | "subscription_expired"
  | "subscription_ending_soon";

export interface AutoBroadcastRule {
  id: string;
  name: string;
  triggerType: AutoBroadcastTriggerType;
  delayDays: number;
  channel: "telegram" | "email" | "both";
  subject: string | null;
  message: string;
  buttonText: string | null;
  buttonUrl: string | null;
  enabled: boolean;
  sentCount?: number;
}

export interface AutoBroadcastRulePayload {
  name: string;
  triggerType: AutoBroadcastTriggerType;
  delayDays: number;
  channel: "telegram" | "email" | "both";
  subject?: string | null;
  message: string;
  buttonText?: string | null;
  buttonUrl?: string | null;
  enabled?: boolean;
}

export interface RunRuleResult {
  ruleId: string;
  sent: number;
  skipped: number;
  errors: string[];
}

export type UpdateSettingsPayload = {
  allowUserThemeChange?: boolean;
  activeLanguages?: string;
  activeCurrencies?: string;
  defaultLanguage?: string;
  defaultCurrency?: string;
  defaultReferralPercent?: number;
  referralPercentLevel2?: number;
  referralPercentLevel3?: number;
  trialDays?: number;
  trialSquadUuid?: string | null;
  trialDeviceLimit?: number | null;
  trialTrafficLimitBytes?: number | null;
  serviceName?: string;
  logo?: string | null;
  logoBot?: string | null;
  favicon?: string | null;
  remnaClientUrl?: string | null;
  smtpHost?: string | null;
  smtpPort?: number;
  smtpSecure?: boolean;
  smtpUser?: string | null;
  smtpPassword?: string | null;
  smtpFromEmail?: string | null;
  smtpFromName?: string | null;
  publicAppUrl?: string | null;
  telegramBotToken?: string | null;
  telegramBotUsername?: string | null;
  botAdminTelegramIds?: string[] | null;
  notificationTelegramGroupId?: string | null;
  notificationTopicNewClients?: string | null;
  notificationTopicPayments?: string | null;
  notificationTopicTickets?: string | null;
  plategaMerchantId?: string | null;
  plategaSecret?: string | null;
  plategaMethods?: string | null;
  yoomoneyClientId?: string | null;
  yoomoneyClientSecret?: string | null;
  yoomoneyReceiverWallet?: string | null;
  yoomoneyNotificationSecret?: string | null;
  yookassaShopId?: string | null;
  yookassaSecretKey?: string | null;
  cryptopayApiToken?: string | null;
  cryptopayTestnet?: boolean;
  heleketMerchantId?: string | null;
  heleketApiKey?: string | null;
  groqApiKey?: string | null;
  groqModel?: string | null;
  groqFallback1?: string | null;
  groqFallback2?: string | null;
  groqFallback3?: string | null;
  aiSystemPrompt?: string | null;
  botButtons?: string | null;
  botButtonsPerRow?: 1 | 2;
  botEmojis?: Record<string, { unicode?: string; tgEmojiId?: string }> | string | null;
  botBackLabel?: string | null;
  botMenuTexts?: string | null;
  botMenuLineVisibility?: string | null;
  botInnerButtonStyles?: string | null;
  botTariffsText?: string | null;
  botTariffsFields?: string | null;
  botPaymentText?: string | null;
  subscriptionPageConfig?: string | null;
  supportLink?: string | null;
  agreementLink?: string | null;
  offerLink?: string | null;
  instructionsLink?: string | null;
  ticketsEnabled?: boolean;
  themeAccent?: string;
  forceSubscribeEnabled?: boolean;
  forceSubscribeChannelId?: string | null;
  forceSubscribeMessage?: string | null;
  blacklistEnabled?: boolean;
  sellOptionsEnabled?: boolean;
  sellOptionsTrafficEnabled?: boolean;
  sellOptionsTrafficProducts?: string | null;
  sellOptionsDevicesEnabled?: boolean;
  sellOptionsDevicesProducts?: string | null;
  sellOptionsServersEnabled?: boolean;
  sellOptionsServersProducts?: string | null;
  googleAnalyticsId?: string | null;
  yandexMetrikaId?: string | null;
  autoBroadcastCron?: string | null;
  adminFrontNotificationsEnabled?: boolean;
  skipEmailVerification?: boolean;
  useRemnaSubscriptionPage?: boolean;
  aiChatEnabled?: boolean;
  customBuildEnabled?: boolean;
  customBuildPricePerDay?: number;
  customBuildPricePerDevice?: number;
  customBuildTrafficMode?: "unlimited" | "per_gb";
  customBuildPricePerGb?: number;
  customBuildSquadUuid?: string | null;
  customBuildCurrency?: string;
  customBuildMaxDays?: number;
  customBuildMaxDevices?: number;
  defaultAutoRenewEnabled?: boolean;
  autoRenewDaysBeforeExpiry?: number;
  autoRenewNotifyDaysBefore?: number;
  autoRenewGracePeriodDays?: number;
  autoRenewMaxRetries?: number;
  yookassaRecurringEnabled?: boolean;
  googleLoginEnabled?: boolean;
  googleClientId?: string | null;
  googleClientSecret?: string | null;
  appleLoginEnabled?: boolean;
  appleClientId?: string | null;
  appleTeamId?: string | null;
  appleKeyId?: string | null;
  applePrivateKey?: string | null;
  landingEnabled?: boolean;
  landingHeroTitle?: string | null;
  landingHeroSubtitle?: string | null;
  landingHeroCtaText?: string | null;
  landingShowTariffs?: boolean;
  landingContacts?: string | null;
  landingOfferLink?: string | null;
  landingPrivacyLink?: string | null;
  landingFooterText?: string | null;
  landingHeroBadge?: string | null;
  landingHeroHint?: string | null;
  landingFeature1Label?: string | null;
  landingFeature1Sub?: string | null;
  landingFeature2Label?: string | null;
  landingFeature2Sub?: string | null;
  landingFeature3Label?: string | null;
  landingFeature3Sub?: string | null;
  landingFeature4Label?: string | null;
  landingFeature4Sub?: string | null;
  landingFeature5Label?: string | null;
  landingFeature5Sub?: string | null;
  landingBenefitsTitle?: string | null;
  landingBenefitsSubtitle?: string | null;
  landingBenefit1Title?: string | null;
  landingBenefit1Desc?: string | null;
  landingBenefit2Title?: string | null;
  landingBenefit2Desc?: string | null;
  landingBenefit3Title?: string | null;
  landingBenefit3Desc?: string | null;
  landingBenefit4Title?: string | null;
  landingBenefit4Desc?: string | null;
  landingBenefit5Title?: string | null;
  landingBenefit5Desc?: string | null;
  landingBenefit6Title?: string | null;
  landingBenefit6Desc?: string | null;
  landingTariffsTitle?: string | null;
  landingTariffsSubtitle?: string | null;
  landingDevicesTitle?: string | null;
  landingDevicesSubtitle?: string | null;
  landingFaqTitle?: string | null;
  landingFaqJson?: string | null;
  landingHeroHeadline1?: string | null;
  landingHeroHeadline2?: string | null;
  landingHeaderBadge?: string | null;
  landingButtonLogin?: string | null;
  landingButtonLoginCabinet?: string | null;
  landingNavBenefits?: string | null;
  landingNavTariffs?: string | null;
  landingNavDevices?: string | null;
  landingNavFaq?: string | null;
  landingBenefitsBadge?: string | null;
  landingDefaultPaymentText?: string | null;
  landingButtonChooseTariff?: string | null;
  landingNoTariffsMessage?: string | null;
  landingButtonWatchTariffs?: string | null;
  landingButtonStart?: string | null;
  landingButtonOpenCabinet?: string | null;
  landingJourneyStepsJson?: string | null;
  landingSignalCardsJson?: string | null;
  landingTrustPointsJson?: string | null;
  landingExperiencePanelsJson?: string | null;
  landingDevicesListJson?: string | null;
  landingQuickStartJson?: string | null;
  landingInfraTitle?: string | null;
  landingNetworkCockpitText?: string | null;
  landingPulseTitle?: string | null;
  landingComfortTitle?: string | null;
  landingComfortBadge?: string | null;
  landingPrinciplesTitle?: string | null;
  landingTechTitle?: string | null;
  landingTechDesc?: string | null;
  landingCategorySubtitle?: string | null;
  landingTariffDefaultDesc?: string | null;
  landingTariffBullet1?: string | null;
  landingTariffBullet2?: string | null;
  landingTariffBullet3?: string | null;
  landingLowestTariffDesc?: string | null;
  landingDevicesCockpitText?: string | null;
  landingUniversalityTitle?: string | null;
  landingUniversalityDesc?: string | null;
  landingQuickSetupTitle?: string | null;
  landingQuickSetupDesc?: string | null;
  landingPremiumServiceTitle?: string | null;
  landingPremiumServicePara1?: string | null;
  landingPremiumServicePara2?: string | null;
  landingHowItWorksTitle?: string | null;
  landingHowItWorksDesc?: string | null;
  landingStatsPlatforms?: string | null;
  landingStatsTariffsLabel?: string | null;
  landingStatsAccessLabel?: string | null;
  landingStatsPaymentMethods?: string | null;
  landingReadyToConnectEyebrow?: string | null;
  landingReadyToConnectTitle?: string | null;
  landingReadyToConnectDesc?: string | null;
  landingShowFeatures?: boolean;
  landingShowBenefits?: boolean;
  landingShowDevices?: boolean;
  landingShowFaq?: boolean;
  landingShowHowItWorks?: boolean;
  landingShowCta?: boolean;
  proxyEnabled?: boolean;
  proxyUrl?: string | null;
  proxyTelegram?: boolean;
  proxyPayments?: boolean;
  nalogEnabled?: boolean;
  nalogInn?: string | null;
  nalogPassword?: string | null;
  nalogDeviceId?: string | null;
  nalogServiceName?: string | null;
};

export interface ClientRecord {
  id: string;
  email: string | null;
  telegramId: string | null;
  telegramUsername: string | null;
  preferredLang: string;
  preferredCurrency: string;
  balance: number;
  referralCode: string | null;
  remnawaveUuid: string | null;
  trialUsed: boolean;
  isBlocked: boolean;
  blockReason: string | null;
  referralPercent: number | null;
  createdAt: string;
  /** Количество приглашённых рефералов (приходит с бэкенда) */
  _count?: { referrals: number };
  /** Активная нода Remna (если есть) */
  activeNode?: string | null;
}

export type UpdateClientPayload = {
  email?: string | null;
  preferredLang?: string;
  preferredCurrency?: string;
  balance?: number;
  isBlocked?: boolean;
  blockReason?: string | null;
  referralPercent?: number | null;
};

export type UpdateClientRemnaPayload = {
  trafficLimitBytes?: number;
  trafficLimitStrategy?: "NO_RESET" | "DAY" | "WEEK" | "MONTH";
  hwidDeviceLimit?: number | null;
  expireAt?: string;
  activeInternalSquads?: string[];
  status?: "ACTIVE" | "DISABLED";
};

export interface AdminSettings {
  allowUserThemeChange?: boolean;
  activeLanguages: string[];
  activeCurrencies: string[];
  defaultLanguage?: string;
  defaultCurrency?: string;
  defaultReferralPercent: number;
  referralPercentLevel2: number;
  referralPercentLevel3: number;
  trialDays: number;
  trialSquadUuid?: string | null;
  trialDeviceLimit?: number | null;
  trialTrafficLimitBytes?: number | null;
  serviceName: string;
  logo?: string | null;
  logoBot?: string | null;
  favicon?: string | null;
  remnaClientUrl?: string | null;
  smtpHost?: string | null;
  smtpPort?: number;
  smtpSecure?: boolean;
  smtpUser?: string | null;
  smtpPassword?: string | null;
  smtpFromEmail?: string | null;
  smtpFromName?: string | null;
  publicAppUrl?: string | null;
  telegramBotToken?: string | null;
  defaultAutoRenewEnabled?: boolean;
  autoRenewDaysBeforeExpiry?: number;
  autoRenewNotifyDaysBefore?: number;
  autoRenewGracePeriodDays?: number;
  autoRenewMaxRetries?: number;
  yookassaRecurringEnabled?: boolean;
  telegramBotUsername?: string | null;
  /** Telegram ID админов бота (видят кнопку «Панель админа» в боте) */
  botAdminTelegramIds?: string[] | null;
  /** Группа для уведомлений: Chat ID (например -1001234567890). Бот должен быть в группе. */
  notificationTelegramGroupId?: string | null;
  notificationTopicNewClients?: string | null;
  notificationTopicPayments?: string | null;
  notificationTopicTickets?: string | null;
  plategaMerchantId?: string | null;
  plategaSecret?: string | null;
  plategaMethods?: { id: number; enabled: boolean; label: string }[];
  yoomoneyClientId?: string | null;
  yoomoneyClientSecret?: string | null;
  yoomoneyReceiverWallet?: string | null;
  yoomoneyNotificationSecret?: string | null;
  yookassaShopId?: string | null;
  yookassaSecretKey?: string | null;
  cryptopayApiToken?: string | null;
  cryptopayTestnet?: boolean;
  heleketMerchantId?: string | null;
  heleketApiKey?: string | null;
  groqApiKey?: string | null;
  groqModel?: string | null;
  groqFallback1?: string | null;
  groqFallback2?: string | null;
  groqFallback3?: string | null;
  aiSystemPrompt?: string | null;
  /** Кнопки главного меню бота: порядок, видимость, текст, стиль, ключ эмодзи, в один ряд */
  botButtons?: { id: string; visible: boolean; label: string; order: number; style?: string; emojiKey?: string; onePerRow?: boolean }[];
  /** Кнопок в ряд в главном меню: 1 или 2 (по умолчанию 1) */
  botButtonsPerRow?: 1 | 2;
  /** Эмодзи по ключам: Unicode и/или TG custom emoji ID (премиум). Ключи: TRIAL, PACKAGE, CARD, LINK, SERVERS, … */
  botEmojis?: Record<string, { unicode?: string; tgEmojiId?: string }>;
  /** Текст кнопки «В меню» */
  botBackLabel?: string | null;
  /** Тексты главного меню бота (приветствие, подписи) */
  botMenuTexts?: Record<string, string> | null;
  /** Видимость строк приветственного текста и главного меню */
  botMenuLineVisibility?: Record<string, boolean> | null;
  /** Стили внутренних кнопок бота (тарифы, пополнение, «Назад» и т.д.) */
  botInnerButtonStyles?: Record<string, string> | null;
  /** Текст экрана тарифов в боте */
  botTariffsText?: string | null;
  /** Какие поля показывать в строке тарифа */
  botTariffsFields?: Record<string, boolean> | null;
  /** Текст окна оплаты в боте */
  botPaymentText?: string | null;
  /** JSON конфиг страницы подписки (приложения, тексты) */
  subscriptionPageConfig?: string | null;
  /** Ссылки раздела «Поддержка» в боте (если пусто — кнопка не показывается) */
  supportLink?: string | null;
  agreementLink?: string | null;
  offerLink?: string | null;
  instructionsLink?: string | null;
  /** Тикет-система включена (кабинет + мини-апп) */
  ticketsEnabled?: boolean;
  /** Глобальная цветовая тема */
  themeAccent?: string;
  /** Принудительная подписка на канал/группу */
  forceSubscribeEnabled?: boolean;
  forceSubscribeChannelId?: string | null;
  forceSubscribeMessage?: string | null;
  /** Community Blacklist — автоблокировка пользователей из общего списка */
  blacklistEnabled?: boolean;
  /** Продажа опций: доп. трафик, устройства, серверы */
  sellOptionsEnabled?: boolean;
  sellOptionsTrafficEnabled?: boolean;
  sellOptionsTrafficProducts?: { id: string; name: string; trafficGb: number; price: number; currency: string }[];
  sellOptionsDevicesEnabled?: boolean;
  sellOptionsDevicesProducts?: { id: string; name: string; deviceCount: number; price: number; currency: string }[];
  sellOptionsServersEnabled?: boolean;
  sellOptionsServersProducts?: { id: string; name: string; squadUuid: string; trafficGb?: number; price: number; currency: string }[];
  /** Google Analytics 4 Measurement ID (G-XXXXXXXXXX) — подключается на страницах кабинета */
  googleAnalyticsId?: string | null;
  /** Яндекс.Метрика: номер счётчика — подключается на страницах кабинета */
  yandexMetrikaId?: string | null;
  /** Расписание авто-рассылки (cron, например "0 9 * * *" = 9:00 каждый день). Пусто = по умолчанию 9:00. */
  autoBroadcastCron?: string | null;
  /** Фронтовые всплывающие уведомления в панели админа включены */
  adminFrontNotificationsEnabled?: boolean;
  /** Регистрация без подтверждения почты */
  skipEmailVerification?: boolean;
  /** Кнопка VPN в боте ведёт на страницу подписки Remna */
  useRemnaSubscriptionPage?: boolean;
  /** AI-чат в кабинете включён */
  aiChatEnabled?: boolean;
  /** Гибкий тариф (собери сам) */
  customBuildEnabled?: boolean;
  customBuildPricePerDay?: number;
  customBuildPricePerDevice?: number;
  customBuildTrafficMode?: "unlimited" | "per_gb";
  customBuildPricePerGb?: number;
  customBuildSquadUuid?: string | null;
  customBuildCurrency?: string;
  customBuildMaxDays?: number;
  customBuildMaxDevices?: number;
  /** OAuth */
  googleLoginEnabled?: boolean;
  googleClientId?: string | null;
  googleClientSecret?: string | null;
  appleLoginEnabled?: boolean;
  appleClientId?: string | null;
  appleTeamId?: string | null;
  appleKeyId?: string | null;
  applePrivateKey?: string | null;
  /** Лендинг на главной (/) */
  landingEnabled?: boolean;
  landingHeroTitle?: string | null;
  landingHeroSubtitle?: string | null;
  landingHeroCtaText?: string | null;
  landingShowTariffs?: boolean;
  landingContacts?: string | null;
  landingOfferLink?: string | null;
  landingPrivacyLink?: string | null;
  landingFooterText?: string | null;
  landingHeroBadge?: string | null;
  landingHeroHint?: string | null;
  landingFeature1Label?: string | null;
  landingFeature1Sub?: string | null;
  landingFeature2Label?: string | null;
  landingFeature2Sub?: string | null;
  landingFeature3Label?: string | null;
  landingFeature3Sub?: string | null;
  landingFeature4Label?: string | null;
  landingFeature4Sub?: string | null;
  landingFeature5Label?: string | null;
  landingFeature5Sub?: string | null;
  landingBenefitsTitle?: string | null;
  landingBenefitsSubtitle?: string | null;
  landingBenefit1Title?: string | null;
  landingBenefit1Desc?: string | null;
  landingBenefit2Title?: string | null;
  landingBenefit2Desc?: string | null;
  landingBenefit3Title?: string | null;
  landingBenefit3Desc?: string | null;
  landingBenefit4Title?: string | null;
  landingBenefit4Desc?: string | null;
  landingBenefit5Title?: string | null;
  landingBenefit5Desc?: string | null;
  landingBenefit6Title?: string | null;
  landingBenefit6Desc?: string | null;
  landingTariffsTitle?: string | null;
  landingTariffsSubtitle?: string | null;
  landingDevicesTitle?: string | null;
  landingDevicesSubtitle?: string | null;
  landingFaqTitle?: string | null;
  landingFaqJson?: string | null;
  landingHeroHeadline1?: string | null;
  landingHeroHeadline2?: string | null;
  landingHeaderBadge?: string | null;
  landingButtonLogin?: string | null;
  landingButtonLoginCabinet?: string | null;
  landingNavBenefits?: string | null;
  landingNavTariffs?: string | null;
  landingNavDevices?: string | null;
  landingNavFaq?: string | null;
  landingBenefitsBadge?: string | null;
  landingDefaultPaymentText?: string | null;
  landingButtonChooseTariff?: string | null;
  landingNoTariffsMessage?: string | null;
  landingButtonWatchTariffs?: string | null;
  landingButtonStart?: string | null;
  landingButtonOpenCabinet?: string | null;
  landingJourneyStepsJson?: string | null;
  landingSignalCardsJson?: string | null;
  landingTrustPointsJson?: string | null;
  landingExperiencePanelsJson?: string | null;
  landingDevicesListJson?: string | null;
  landingQuickStartJson?: string | null;
  landingInfraTitle?: string | null;
  landingNetworkCockpitText?: string | null;
  landingPulseTitle?: string | null;
  landingComfortTitle?: string | null;
  landingComfortBadge?: string | null;
  landingPrinciplesTitle?: string | null;
  landingTechTitle?: string | null;
  landingTechDesc?: string | null;
  landingCategorySubtitle?: string | null;
  landingTariffDefaultDesc?: string | null;
  landingTariffBullet1?: string | null;
  landingTariffBullet2?: string | null;
  landingTariffBullet3?: string | null;
  landingLowestTariffDesc?: string | null;
  landingDevicesCockpitText?: string | null;
  landingUniversalityTitle?: string | null;
  landingUniversalityDesc?: string | null;
  landingQuickSetupTitle?: string | null;
  landingQuickSetupDesc?: string | null;
  landingPremiumServiceTitle?: string | null;
  landingPremiumServicePara1?: string | null;
  landingPremiumServicePara2?: string | null;
  landingHowItWorksTitle?: string | null;
  landingHowItWorksDesc?: string | null;
  landingStatsPlatforms?: string | null;
  landingStatsTariffsLabel?: string | null;
  landingStatsAccessLabel?: string | null;
  landingStatsPaymentMethods?: string | null;
  landingReadyToConnectEyebrow?: string | null;
  landingReadyToConnectTitle?: string | null;
  landingReadyToConnectDesc?: string | null;
  landingShowFeatures?: boolean;
  landingShowBenefits?: boolean;
  landingShowDevices?: boolean;
  landingShowFaq?: boolean;
  landingShowHowItWorks?: boolean;
  landingShowCta?: boolean;
  /** Прокси для внешних запросов */
  proxyEnabled?: boolean;
  proxyUrl?: string | null;
  proxyTelegram?: boolean;
  proxyPayments?: boolean;
  nalogEnabled?: boolean;
  nalogInn?: string | null;
  nalogPassword?: string | null;
  nalogDeviceId?: string | null;
  nalogServiceName?: string | null;
}

/** Конфиг страницы подписки (формат как sub.stealthnet.app) */
export type SubscriptionPageConfig = {
  locales?: string[];
  version?: string;
  uiConfig?: { subscriptionInfoBlockType?: string; installationGuidesBlockType?: string };
  platforms?: Record<
    string,
    {
      apps?: {
        name: string;
        featured?: boolean;
        blocks?: {
          title?: Record<string, string>;
          description?: Record<string, string>;
          buttons?: { link: string; text: Record<string, string>; type: string; svgIconKey?: string }[];
          svgIconKey?: string;
          svgIconColor?: string;
        }[];
      }[];
      displayName?: Record<string, string>;
      svgIconKey?: string;
    }
  >;
  translations?: Record<string, Record<string, string>>;
  brandingSettings?: { title?: string; logoUrl?: string; supportUrl?: string };
} | null;

export interface ServerStats {
  hostname: string;
  platform: string;
  arch: string;
  uptimeSeconds: number;
  loadAvg: [number, number, number];
  cpu: { model: string; cores: number; usagePercent: number };
  memory: { totalBytes: number; usedBytes: number; freeBytes: number; usagePercent: number };
  disk: { totalBytes: number; usedBytes: number; freeBytes: number; usagePercent: number; mount: string } | null;
}

export interface SshConfig {
  port: number;
  permitRootLogin: string;
  passwordAuthentication: boolean;
  pubkeyAuthentication: boolean;
}

export interface DashboardStats {
  users: {
    total: number;
    withRemna: number;
    newToday: number;
    newLast7Days: number;
    newLast30Days: number;
  };
  sales: {
    totalAmount: number;
    totalCount: number;
    todayAmount: number;
    todayCount: number;
    last7DaysAmount: number;
    last7DaysCount: number;
    last30DaysAmount: number;
    last30DaysCount: number;
  };
}

export interface AutoRenewStats {
  enabled: number;
  disabled: number;
  retriesInProgress: number;
  renewalsLast7Days: number;
  renewalsLast30Days: number;
  amountLast30Days: number;
}

export interface AdminNotificationCounters {
  totalClients: number;
  totalTickets: number;
  totalTariffPayments: number;
  totalBalanceTopups: number;
}

export interface ApiKeyListItem {
  id: string;
  name: string;
  description: string | null;
  prefix: string;
  isActive: boolean;
  lastUsedAt: string | null;
  createdAt: string;
}

export interface ApiKeyCreated extends ApiKeyListItem {
  keyHash: string;
  rawKey: string;
}

export interface TrafficAbuser {
  uuid: string;
  username: string;
  email: string | null;
  telegramId: number | null;
  status: string;
  trafficLimitBytes: number;
  trafficLimitStrategy: string;
  usedTrafficBytes: number;
  lifetimeUsedTrafficBytes: number;
  periodUsageBytes: number;
  usagePercent: number;
  perNodeUsage: { nodeName: string; bytes: number }[];
  onlineAt: string | null;
  lastConnectedNodeUuid: string | null;
  createdAt: string;
  expireAt: string;
  abuseScore: number;
}

export interface TrafficAbuseStats {
  totalUsers: number;
  activeNodes: number;
  nodesWithData?: number;
  periodDays: number;
  periodStart: string;
  periodEnd: string;
  totalTrafficPeriod: number;
  abusersCount: number;
  abuserTrafficTotal: number;
  abuserTrafficPercent: number;
  threshold: number;
  minBytes: number;
}

export interface TrafficAbuseResponse {
  abusers: TrafficAbuser[];
  stats: TrafficAbuseStats;
}

export interface RemnaNode {
  uuid: string;
  name: string;
  address: string;
  port?: number | null;
  isConnected: boolean;
  isDisabled: boolean;
  isConnecting: boolean;
  lastStatusChange?: string | null;
  lastStatusMessage?: string | null;
  xrayVersion?: string | null;
  nodeVersion?: string | null;
  xrayUptime?: string;
  isTrafficTrackingActive?: boolean;
  /** Онлайн пользователей на ноде */
  usersOnline?: number | null;
  /** Трафик использовано (байты) */
  trafficUsedBytes?: number | null;
  /** Лимит трафика (байты) */
  trafficLimitBytes?: number | null;
  /** Ядер CPU */
  cpuCount?: number | null;
  /** Модель CPU */
  cpuModel?: string | null;
  /** Всего RAM (строка, напр. "2.06 GB") */
  totalRam?: string | null;
}

export interface ProxySlotAdminItem {
  id: string;
  nodeId: string;
  nodeName: string;
  publicHost: string | null;
  socksPort: number;
  httpPort: number;
  clientId: string;
  clientEmail: string | null;
  clientTelegram: string | null;
  clientTelegramId: string | null;
  login: string;
  password: string;
  expiresAt: string;
  trafficLimitBytes: string | null;
  trafficUsedBytes: string;
  connectionLimit: number | null;
  currentConnections: number;
  status: string;
  createdAt: string;
}

export type RemnaNodesResponse = { response?: RemnaNode[] };

export interface ProxyNodeListItem {
  id: string;
  name: string;
  status: string;
  lastSeenAt: string | null;
  publicHost: string | null;
  socksPort: number;
  httpPort: number;
  capacity: number | null;
  currentConnections: number;
  trafficInBytes: string;
  trafficOutBytes: string;
  slotsCount: number;
  createdAt: string;
}

export interface CreateProxyNodeResponse {
  node: { id: string; name: string; status: string; token: string; createdAt: string };
  dockerCompose: string;
  instructions: string;
}

export interface ProxyNodeDetail {
  id: string;
  name: string;
  status: string;
  lastSeenAt: string | null;
  publicHost: string | null;
  socksPort: number;
  httpPort: number;
  capacity: number | null;
  currentConnections: number;
  trafficInBytes: string;
  trafficOutBytes: string;
  metadata: string | null;
  createdAt: string;
  updatedAt: string;
  slots: Array<{
    id: string;
    login: string;
    expiresAt: string;
    trafficLimitBytes: string | null;
    connectionLimit: number | null;
    trafficUsedBytes: string;
    currentConnections: number;
    status: string;
    client: { id: string; email: string | null; telegramUsername: string | null; telegramId: string | null };
    createdAt: string;
  }>;
}

export interface SingboxNodeListItem {
  id: string;
  name: string;
  status: string;
  lastSeenAt: string | null;
  publicHost: string | null;
  port: number;
  protocol: string;
  tlsEnabled: boolean;
  capacity: number | null;
  currentConnections: number;
  trafficInBytes: string;
  trafficOutBytes: string;
  slotsCount: number;
  hasCustomConfig: boolean;
  createdAt: string;
}

export interface CreateSingboxNodeResponse {
  node: { id: string; name: string; status: string; protocol: string; port: number; token: string; createdAt: string };
  dockerCompose: string;
  instructions: string;
}

export interface SingboxNodeDetail {
  id: string;
  name: string;
  status: string;
  lastSeenAt: string | null;
  publicHost: string | null;
  port: number;
  protocol: string;
  tlsEnabled: boolean;
  capacity: number | null;
  currentConnections: number;
  trafficInBytes: string;
  trafficOutBytes: string;
  metadata: string | null;
  customConfigJson: string | null;
  createdAt: string;
  updatedAt: string;
  slots: Array<{
    id: string;
    userIdentifier: string;
    expiresAt: string;
    trafficLimitBytes: string | null;
    trafficUsedBytes: string;
    currentConnections: number;
    status: string;
    client: { id: string; email: string | null; telegramUsername: string | null; telegramId: string | null };
    createdAt: string;
  }>;
}

export interface SingboxCategoryItem {
  id: string;
  name: string;
  sortOrder: number;
  tariffs: { id: string; name: string; slotCount: number; durationDays: number; trafficLimitBytes: string | null; price: number; currency: string; enabled: boolean }[];
}

export interface SingboxTariffListItem {
  id: string;
  categoryId: string;
  categoryName: string;
  name: string;
  slotCount: number;
  durationDays: number;
  trafficLimitBytes: string | null;
  price: number;
  currency: string;
  sortOrder: number;
  enabled: boolean;
}

export type RemnaSystemStats = {
  response?: {
    users?: { totalUsers?: number; statusCounts?: Record<string, number> };
    cpu?: { cores?: number; physicalCores?: number };
    memory?: { total?: number; used?: number; free?: number };
    uptime?: number;
  };
};

export interface TariffCategoryRecord {
  id: string;
  name: string;
  emojiKey: string | null;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export interface TariffCategoryWithTariffs extends TariffCategoryRecord {
  tariffs: TariffRecord[];
}

export interface TariffRecord {
  id: string;
  categoryId: string;
  name: string;
  description: string | null;
  durationDays: number;
  internalSquadUuids: string[];
  trafficLimitBytes: number | null;
  trafficResetMode: string;
  deviceLimit: number | null;
  price: number;
  currency: string;
  sortOrder: number;
  createdAt: string;
  updatedAt: string;
}

export type CreateTariffPayload = {
  categoryId: string;
  name: string;
  description?: string | null;
  durationDays: number;
  internalSquadUuids: string[];
  trafficLimitBytes?: number | null;
  trafficResetMode?: string;
  deviceLimit?: number | null;
  price?: number;
  currency?: string;
  sortOrder?: number;
};

export type UpdateTariffPayload = {
  name?: string;
  description?: string | null;
  durationDays?: number;
  internalSquadUuids?: string[];
  trafficLimitBytes?: number | null;
  trafficResetMode?: string;
  deviceLimit?: number | null;
  price?: number;
  currency?: string;
  sortOrder?: number;
};

// ——— Кабинет клиента ———
export interface ClientProfile {
  id: string;
  email: string | null;
  telegramId: string | null;
  telegramUsername: string | null;
  preferredLang: string;
  preferredCurrency: string;
  balance: number;
  referralCode: string | null;
  remnawaveUuid: string | null;
  trialUsed: boolean;
  isBlocked: boolean;
  /** Кошелёк ЮMoney подключён (токен сохранён) */
  yoomoneyConnected?: boolean;
  /** Включена ли двухфакторная аутентификация (TOTP) */
  totpEnabled?: boolean;
  createdAt?: string;
  autoRenewEnabled?: boolean;
  autoRenewTariffId?: string | null;
  /** Название привязанного способа оплаты ЮKassa (например "Банковская карта *4444") */
  yookassaPaymentMethodTitle?: string | null;
}

export interface ClientAuthResponse {
  token: string;
  client: ClientProfile;
}

/** Ответ входа, когда включена 2FA: нужен шаг ввода кода. */
export interface ClientAuthRequires2FA {
  requires2FA: true;
  tempToken: string;
}

export type ClientRegisterPayload = {
  email?: string;
  password?: string;
  telegramId?: string;
  telegramUsername?: string;
  preferredLang?: string;
  preferredCurrency?: string;
  referralCode?: string;
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_content?: string;
  utm_term?: string;
};

export interface ClientPayment {
  id: string;
  orderId: string;
  amount: number;
  currency: string;
  status: string;
  createdAt: string;
  paidAt: string | null;
}

export interface PublicTariffCategory {
  id: string;
  name: string;
  emojiKey: string | null;
  emoji: string;
  tariffs: { id: string; name: string; description: string | null; durationDays: number; price: number; currency: string; trafficLimitBytes: number | null; trafficResetMode?: string; deviceLimit: number | null }[];
}

// ——— Промо-группы ———
export interface PromoGroup {
  id: string;
  name: string;
  code: string;
  squadUuid: string;
  trafficLimitBytes: string;
  deviceLimit: number | null;
  durationDays: number;
  maxActivations: number;
  isActive: boolean;
  activationsCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface PromoActivation {
  id: string;
  promoGroupId: string;
  clientId: string;
  createdAt: string;
  client: {
    id: string;
    email: string | null;
    telegramId: string | null;
    telegramUsername: string | null;
    createdAt: string;
    remnawaveUuid: string | null;
  };
}

export interface PromoGroupDetail extends PromoGroup {
  activations: PromoActivation[];
}

export type CreatePromoGroupPayload = {
  name: string;
  squadUuid: string;
  trafficLimitBytes: string | number;
  deviceLimit?: number | null;
  durationDays: number;
  maxActivations: number;
  isActive?: boolean;
};

export type UpdatePromoGroupPayload = Partial<CreatePromoGroupPayload>;

// ——— Промокоды (скидки / бесплатные дни) ———
export interface PromoCodeRecord {
  id: string;
  code: string;
  name: string;
  type: "DISCOUNT" | "FREE_DAYS";
  discountPercent: number | null;
  discountFixed: number | null;
  squadUuid: string | null;
  trafficLimitBytes: string | null;
  deviceLimit: number | null;
  durationDays: number | null;
  maxUses: number;
  maxUsesPerClient: number;
  isActive: boolean;
  expiresAt: string | null;
  usagesCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface PromoCodeUsage {
  id: string;
  promoCodeId: string;
  clientId: string;
  createdAt: string;
  client: {
    id: string;
    email: string | null;
    telegramId: string | null;
    telegramUsername: string | null;
    createdAt: string;
    remnawaveUuid: string | null;
  };
}

export interface PromoCodeDetail extends PromoCodeRecord {
  usages: PromoCodeUsage[];
}

export type CreatePromoCodePayload = {
  code: string;
  name: string;
  type: "DISCOUNT" | "FREE_DAYS";
  discountPercent?: number | null;
  discountFixed?: number | null;
  squadUuid?: string | null;
  trafficLimitBytes?: string | number | null;
  deviceLimit?: number | null;
  durationDays?: number | null;
  maxUses: number;
  maxUsesPerClient: number;
  isActive?: boolean;
  expiresAt?: string | null;
};

export type UpdatePromoCodePayload = Partial<CreatePromoCodePayload>;

export interface GeoMapNode {
  uuid: string;
  name: string;
  countryCode: string;
  lat: number;
  lng: number;
  isConnected: boolean;
  usersOnline: number;
  rxBytesPerSec: number;
  txBytesPerSec: number;
  trafficUsedBytes: number;
  trafficLimitBytes: number | null;
}

export interface GeoMapConnection {
  userId: string;
  username: string;
  lat: number;
  lng: number;
  ip: string;
  lastSeen: string;
  nodeUuid: string;
  trafficBytes: number;
  device: {
    platform: string;
    osVersion: string;
    deviceModel: string;
  } | null;
}

export interface GeoMapResponse {
  nodes: GeoMapNode[];
  connections: GeoMapConnection[];
  updatedAt: string;
}

/** Одна опция для продажи в кабинете (трафик / устройства / сервер) */
export type PublicSellOption =
  | { kind: "traffic"; id: string; name: string; trafficGb: number; price: number; currency: string }
  | { kind: "devices"; id: string; name: string; deviceCount: number; price: number; currency: string }
  | { kind: "servers"; id: string; name: string; squadUuid: string; trafficGb?: number; price: number; currency: string };

export interface PublicConfig {
  activeLanguages: string[];
  activeCurrencies: string[];
  defaultLanguage?: string;
  defaultCurrency?: string;
  serviceName: string;
  logo?: string | null;
  favicon?: string | null;
  remnaClientUrl?: string | null;
  publicAppUrl?: string | null;
  telegramBotUsername?: string | null;
  telegramBotId?: string | null;
  plategaMethods?: { id: number; label: string }[];
  yoomoneyEnabled?: boolean;
  yookassaEnabled?: boolean;
  cryptopayEnabled?: boolean;
  heleketEnabled?: boolean;
  trialEnabled?: boolean;
  trialDays?: number;
  themeAccent?: string;
  ticketsEnabled?: boolean;
  sellOptionsEnabled?: boolean;
  sellOptions?: PublicSellOption[];
  showProxyEnabled?: boolean;
  showSingboxEnabled?: boolean;
  googleAnalyticsId?: string | null;
  yandexMetrikaId?: string | null;
  skipEmailVerification?: boolean;
  useRemnaSubscriptionPage?: boolean;
  aiChatEnabled?: boolean;
  customBuildConfig?: {
    enabled: true;
    pricePerDay: number;
    pricePerDevice: number;
    trafficMode: "unlimited" | "per_gb";
    pricePerGb: number;
    squadUuid: string;
    currency: string;
    maxDays: number;
    maxDevices: number;
  } | null;
  yookassaRecurringEnabled?: boolean;
  googleLoginEnabled?: boolean;
  googleClientId?: string | null;
  appleLoginEnabled?: boolean;
  appleClientId?: string | null;
  landingEnabled?: boolean;
  landingConfig?: {
    heroTitle: string;
    heroSubtitle: string | null;
    heroCtaText: string;
    heroBadge: string | null;
    heroHint: string | null;
    showTariffs: boolean;
    contacts: string | null;
    offerLink: string | null;
    privacyLink: string | null;
    footerText: string | null;
    features: { label: string; sub: string }[] | null;
    benefitsTitle: string | null;
    benefitsSubtitle: string | null;
    benefits: { title: string; desc: string }[] | null;
    tariffsTitle: string | null;
    tariffsSubtitle: string | null;
    devicesTitle: string | null;
    devicesSubtitle: string | null;
    faqTitle: string | null;
    faq: { q: string; a: string }[] | null;
    readyToConnectEyebrow?: string | null;
    readyToConnectTitle?: string | null;
    readyToConnectDesc?: string | null;
  } | null;
}
